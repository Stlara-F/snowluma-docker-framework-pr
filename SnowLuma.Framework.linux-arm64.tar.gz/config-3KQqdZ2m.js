import { createRequire as __snowlumaCreateRequire } from "node:module";
__snowlumaCreateRequire(import.meta.url);
import { format } from "util";
import fs, { existsSync } from "node:fs";
import path from "node:path";
import { AsyncLocalStorage } from "async_hooks";
import fs$1 from "fs";
import path$1 from "path";
import { randomBytes } from "crypto";
import { readFile } from "node:fs/promises";
import http from "node:http";
import https from "node:https";
import crypto$1 from "node:crypto";
import { EventEmitter } from "node:events";
import { URL as URL$1, fileURLToPath } from "node:url";
import zlib from "node:zlib";
import net from "node:net";
import tls from "node:tls";
//#region ../common/src/log-file-transport.ts
var DEFAULT_DIR = "logs";
var DEFAULT_MAX_MB = 50;
var DEFAULT_RETAIN_DAYS = 7;
var FILE_PREFIX = "snowluma-";
var FILE_SUFFIX = ".log";
var FILE_RE = /^snowluma-(\d{4}-\d{2}-\d{2})(?:\.(\d+))?\.log$/;
var ANSI_RE = /\x1B\[[0-?]*[ -/]*[@-~]/g;
var CTRL_RE = /[\x00-\x08\x0B-\x1A\x1C-\x1F\x7F]/g;
function parsePositiveInt(v, dflt) {
	if (!v) return dflt;
	const n = Number.parseInt(v, 10);
	return Number.isFinite(n) && n > 0 ? n : dflt;
}
function todayString(d = /* @__PURE__ */ new Date()) {
	return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function dateOf(s) {
	const [y, m, d] = s.split("-").map((v) => Number.parseInt(v, 10));
	return new Date(y, m - 1, d);
}
function stripAnsi(line) {
	return line.replace(ANSI_RE, "").replace(CTRL_RE, "");
}
/**
* Owns one output directory: keeps at most one open WriteStream, handles
* daily rollover, per-file size cap, and retention cleanup. The shared
* top-level dir uses one of these; each per-UIN sub-dir gets its own.
*/
var FileWriter = class {
	dir;
	maxBytes;
	retainDays;
	disabled = false;
	file = null;
	constructor(dir, maxBytes, retainDays) {
		this.dir = dir;
		this.maxBytes = maxBytes;
		this.retainDays = retainDays;
		try {
			fs.mkdirSync(dir, { recursive: true });
		} catch (err) {
			this.disabled = true;
			console.error(`[logger] failed to create log dir ${dir}: ${err instanceof Error ? err.message : String(err)}`);
			return;
		}
		this.cleanup();
	}
	get isDisabled() {
		return this.disabled;
	}
	get currentPath() {
		return this.file?.path ?? null;
	}
	write(data, bytes) {
		if (this.disabled) return;
		const today = todayString();
		this.ensureForToday(today);
		if (!this.file) return;
		if (this.file.bytes + bytes > this.maxBytes && this.file.bytes > 0) {
			this.rotateBySize();
			if (!this.file) return;
		}
		this.file.stream.write(data);
		this.file.bytes += bytes;
	}
	close() {
		const f = this.file;
		this.file = null;
		if (!f) return Promise.resolve();
		return new Promise((resolve) => {
			try {
				f.stream.end(() => resolve());
			} catch {
				resolve();
			}
		});
	}
	ensureForToday(today) {
		if (this.file && this.file.date === today) return;
		if (this.file) {
			try {
				this.file.stream.end();
			} catch {}
			this.file = null;
			this.cleanup();
		}
		let idx = 0;
		while (fs.existsSync(this.pathFor(today, idx + 1))) idx++;
		this.file = this.openFile(today, idx);
	}
	rotateBySize() {
		if (!this.file) return;
		const date = this.file.date;
		try {
			this.file.stream.end();
		} catch {}
		let next = this.file.splitIndex + 1;
		while (fs.existsSync(this.pathFor(date, next))) next++;
		this.file = this.openFile(date, next);
	}
	openFile(date, splitIndex) {
		const p = this.pathFor(date, splitIndex);
		try {
			let bytes = 0;
			try {
				bytes = fs.statSync(p).size;
			} catch {}
			const stream = fs.createWriteStream(p, { flags: "a" });
			stream.on("error", (err) => {
				console.error(`[logger] file write error on ${p}: ${err.message}`);
			});
			return {
				stream,
				bytes,
				date,
				splitIndex,
				path: p
			};
		} catch (err) {
			console.error(`[logger] failed to open log file ${p}: ${err instanceof Error ? err.message : String(err)}`);
			return null;
		}
	}
	pathFor(date, splitIndex) {
		const tail = splitIndex > 0 ? `.${splitIndex}` : "";
		return path.join(this.dir, `${FILE_PREFIX}${date}${tail}${FILE_SUFFIX}`);
	}
	cleanup() {
		let entries;
		try {
			entries = fs.readdirSync(this.dir);
		} catch {
			return;
		}
		const retainMs = this.retainDays * 24 * 60 * 60 * 1e3;
		const cutoff = Date.now() - retainMs;
		for (const name of entries) {
			const m = FILE_RE.exec(name);
			if (!m) continue;
			const dateStr = m[1];
			if (dateOf(dateStr).getTime() < cutoff) try {
				fs.unlinkSync(path.join(this.dir, name));
			} catch {}
		}
	}
};
var FileTransport = class {
	dir;
	maxBytes;
	retainDays;
	enabled;
	perUinEnabled;
	shared = null;
	perUin = /* @__PURE__ */ new Map();
	constructor() {
		this.dir = process.env.SNOWLUMA_LOG_DIR || DEFAULT_DIR;
		this.maxBytes = parsePositiveInt(process.env.SNOWLUMA_LOG_MAX_MB, DEFAULT_MAX_MB) * 1024 * 1024;
		this.retainDays = parsePositiveInt(process.env.SNOWLUMA_LOG_RETAIN_DAYS, DEFAULT_RETAIN_DAYS);
		this.enabled = process.env.SNOWLUMA_LOG_FILE !== "0";
		this.perUinEnabled = process.env.SNOWLUMA_LOG_PER_UIN !== "0";
		if (this.enabled) {
			const w = new FileWriter(this.dir, this.maxBytes, this.retainDays);
			this.shared = w.isDisabled ? null : w;
		}
	}
	/** True when no file output will happen (env disable or init failure). */
	get isDisabled() {
		return !this.shared;
	}
	/** Current shared-file path (or null if disabled / not yet opened). */
	get currentPath() {
		return this.shared?.currentPath ?? null;
	}
	/** Path of the per-UIN file for the given UIN, if open. */
	perUinPath(uin) {
		return this.perUin.get(uin)?.currentPath ?? null;
	}
	write(line, uin) {
		if (!this.shared) return;
		const data = stripAnsi(line) + "\n";
		const bytes = Buffer.byteLength(data, "utf8");
		this.shared.write(data, bytes);
		if (uin !== void 0 && this.perUinEnabled) {
			let w = this.perUin.get(uin);
			if (!w) {
				w = new FileWriter(path.join(this.dir, String(uin)), this.maxBytes, this.retainDays);
				if (w.isDisabled) return;
				this.perUin.set(uin, w);
			}
			w.write(data, bytes);
		}
	}
	async close() {
		const closes = [];
		if (this.shared) closes.push(this.shared.close());
		for (const w of this.perUin.values()) closes.push(w.close());
		this.shared = null;
		this.perUin.clear();
		await Promise.all(closes);
	}
};
var singleton = null;
function getFileTransport() {
	if (!singleton) singleton = new FileTransport();
	return singleton;
}
//#endregion
//#region ../common/src/request-context.ts
var storage = new AsyncLocalStorage();
var counter = 0;
/**
* Allocate the next per-process request id (monotonic). Wraps via uint32 so
* it never overflows to a non-integer; `0` is skipped so "no id" stays
* unambiguous.
*/
function nextRequestId() {
	counter = counter + 1 >>> 0;
	if (counter === 0) counter = 1;
	return counter;
}
/**
* Run `fn` with `id` bound as the ambient request id for the entire async
* chain it spawns. Any logger call anywhere in that chain — across packages,
* across awaits — picks it up via {@link currentRequestId} with no signature
* threading. Used by the OneBot action handler to correlate a request's whole
* journey (entry → outbound packets → exit) under one `[req#N]` tag.
*/
function runWithRequestId(id, fn) {
	return storage.run({ id }, fn);
}
/** The request id bound to the current async context, or undefined outside one. */
function currentRequestId() {
	return storage.getStore()?.id;
}
//#endregion
//#region ../common/src/logger.ts
var UIN_SLOT_WIDTH = 12;
var LEVEL_WEIGHT = {
	trace: 5,
	debug: 10,
	info: 20,
	success: 25,
	warn: 30,
	error: 40
};
var LEVEL_LABEL = {
	trace: "TRACE",
	debug: "DEBUG",
	info: "INFO",
	success: "OK",
	warn: "WARN",
	error: "ERROR"
};
var COLOR_CODE = {
	trace: 90,
	debug: 90,
	info: 36,
	success: 32,
	warn: 33,
	error: 31
};
var COLOR_SCOPE = 35;
var COLOR_DIM = 2;
var COLOR_RESET = "\x1B[0m";
var MAX_LOG_ENTRIES = 1e3;
/** Trace ring cap — env-tunable since trace is the high-volume stream. */
function resolveTraceBufferMax() {
	const raw = Number.parseInt(process.env.SNOWLUMA_TRACE_BUFFER ?? "", 10);
	return Number.isFinite(raw) && raw >= 100 ? raw : 5e3;
}
var TRACE_BUFFER_MAX = resolveTraceBufferMax();
/**
* Fixed-capacity circular buffer. O(1) push + eviction (no array `.shift()`),
* so the high-throughput trace stream never pays an O(n) shift per overflow.
*/
var RingBuffer = class {
	cap;
	buf;
	start = 0;
	count = 0;
	constructor(cap) {
		this.cap = cap;
		this.buf = new Array(cap);
	}
	push(item) {
		const end = (this.start + this.count) % this.cap;
		this.buf[end] = item;
		if (this.count < this.cap) this.count += 1;
		else this.start = (this.start + 1) % this.cap;
	}
	/** Most recent `n` items, oldest→newest. */
	recent(n) {
		const take = Math.max(0, Math.min(Math.trunc(n), this.count));
		const out = new Array(take);
		const first = this.start + (this.count - take);
		for (let i = 0; i < take; i += 1) out[i] = this.buf[(first + i) % this.cap];
		return out;
	}
	toArray() {
		return this.recent(this.count);
	}
	get size() {
		return this.count;
	}
};
var logRing = new RingBuffer(MAX_LOG_ENTRIES);
var traceRing = new RingBuffer(TRACE_BUFFER_MAX);
var logSubscribers = /* @__PURE__ */ new Set();
var nextLogId = 1;
function resolveMinLevel() {
	const raw = (process.env.SNOWLUMA_LOG_LEVEL ?? "info").toLowerCase();
	if (raw === "trace" || raw === "debug" || raw === "info" || raw === "success" || raw === "warn" || raw === "error") return raw;
	return "info";
}
var currentLevel = resolveMinLevel();
function shouldLog(level) {
	return LEVEL_WEIGHT[level] >= LEVEL_WEIGHT[currentLevel];
}
var LOG_LEVELS = [
	"trace",
	"debug",
	"info",
	"success",
	"warn",
	"error"
];
function getLogLevel() {
	return currentLevel;
}
/**
* Change the console / subscriber level at runtime. Invalid input is
* a no-op (returns false). File transport is unaffected — it always
* sees every level so post-mortems remain useful.
*/
function setLogLevel(level) {
	const lower = String(level).toLowerCase();
	if (!LOG_LEVELS.includes(lower)) return false;
	currentLevel = lower;
	return true;
}
function useColor() {
	if (process.env.NO_COLOR === "1") return false;
	return Boolean(process.stdout.isTTY);
}
function ansi(code, text) {
	return `\x1b[${code}m${text}${COLOR_RESET}`;
}
function currentTime() {
	const d = /* @__PURE__ */ new Date();
	return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}:${String(d.getSeconds()).padStart(2, "0")}`;
}
function render(level, options, args, reqId) {
	const message = format(...args);
	const ts = currentTime();
	const label = LEVEL_LABEL[level].padEnd(5, " ");
	const uinTag = options.uin !== void 0 ? `[${options.uin}]` : "";
	const uinSlot = uinTag.padEnd(UIN_SLOT_WIDTH);
	const reqTag = reqId !== void 0 ? `[req#${reqId}]` : "";
	if (!useColor()) return `${ts} ${label} ${uinSlot} [${options.scope}] ${reqTag ? `${reqTag} ` : ""}${message}`;
	return `${ansi(COLOR_DIM, ts)} ${ansi(COLOR_CODE[level], label)} ${uinTag ? ansi(COLOR_DIM, uinTag) + " ".repeat(UIN_SLOT_WIDTH - uinTag.length) : " ".repeat(UIN_SLOT_WIDTH)} ${ansi(COLOR_SCOPE, `[${options.scope}]`)} ${reqTag ? `${ansi(COLOR_DIM, reqTag)} ` : ""}${message}`;
}
function emit(level, options, args) {
	const passesConsole = shouldLog(level);
	if (level === "trace" && !passesConsole) return;
	let realArgs = args;
	if (level === "trace" && args.length === 1 && typeof args[0] === "function") realArgs = args[0]();
	const reqId = currentRequestId();
	const message = format(...realArgs);
	const line = render(level, options, realArgs, reqId);
	const entry = {
		id: nextLogId++,
		time: (/* @__PURE__ */ new Date()).toISOString(),
		level,
		scope: options.scope,
		...options.uin !== void 0 ? { uin: options.uin } : {},
		...reqId !== void 0 ? { req: reqId } : {},
		message,
		line
	};
	if (passesConsole) {
		(level === "trace" ? traceRing : logRing).push(entry);
		for (const subscriber of logSubscribers) subscriber(entry);
		(level === "warn" || level === "error" ? process.stderr : process.stdout).write(line.replace(/[\x00-\x08\x0B-\x1A\x1C-\x1F\x7F]/g, "") + "\n");
	}
	if (level !== "trace") getFileTransport().write(line, options.uin);
}
/**
* Flush and close the underlying log file. Call from shutdown hooks
* (SIGINT / SIGTERM / uncaughtException) so the WriteStream's internal
* buffer makes it to disk. Returns a promise that resolves once the OS
* has finalized the write.
*/
function closeLogger() {
	return getFileTransport().close();
}
function getRecentLogs(limit = 300) {
	const n = Math.max(1, Math.trunc(limit));
	return (traceRing.size > 0 ? [...logRing.toArray(), ...traceRing.toArray()].sort((a, b) => a.id - b.id) : logRing.toArray()).slice(-n);
}
function subscribeLogs(callback) {
	logSubscribers.add(callback);
	return () => {
		logSubscribers.delete(callback);
	};
}
function makeLogger(opts) {
	return {
		trace: (...args) => emit("trace", opts, args),
		debug: (...args) => emit("debug", opts, args),
		info: (...args) => emit("info", opts, args),
		success: (...args) => emit("success", opts, args),
		warn: (...args) => emit("warn", opts, args),
		error: (...args) => emit("error", opts, args),
		child: (meta) => {
			const nextUin = typeof meta.uin === "number" ? meta.uin : opts.uin;
			return makeLogger({
				scope: opts.scope,
				uin: nextUin,
				meta: {
					...opts.meta ?? {},
					...meta
				}
			});
		}
	};
}
function createLogger(scope) {
	return makeLogger({ scope });
}
//#endregion
//#region ../common/src/runtime.ts
var CONFIG_DIR$2 = "config";
var RUNTIME_CONFIG_PATH = path$1.join(CONFIG_DIR$2, "runtime.json");
var DEFAULT_WEBUI_PORT = 5099;
var DEFAULT_WEBUI_HOST = "0.0.0.0";
/**
* Pure on-disk-object → typed config normalization (defaults + validation,
* no fs / no env). Exported for testing; `loadRuntimeConfig` wraps it.
*/
function normalizeRuntimeConfig(parsed) {
	const obj = isObject$2(parsed) ? parsed : {};
	return {
		webuiPort: normalizePort(obj.webuiPort ?? DEFAULT_WEBUI_PORT, DEFAULT_WEBUI_PORT),
		hookAutoLoad: normalizeBool(obj.hookAutoLoad, false),
		webuiHost: normalizeHost(obj.webuiHost),
		webuiTls: { enabled: isObject$2(obj.webuiTls) ? normalizeBool(obj.webuiTls.enabled, false) : false },
		trustProxy: typeof obj.trustProxy === "string" ? obj.trustProxy : ""
	};
}
/**
* Pure SNOWLUMA_* env → override patch (no fs). Env wins over runtime.json
* (a trusted launcher like SnowLumaDesktop pins these per-launch without
* rewriting the file). Absent vars produce no key.
*/
function resolveRuntimeEnvOverrides(env) {
	const out = {};
	const port = parsePortString(env.SNOWLUMA_WEBUI_PORT);
	if (port !== void 0) out.webuiPort = port;
	const host = env.SNOWLUMA_WEBUI_HOST;
	if (typeof host === "string" && host.trim()) out.webuiHost = host.trim();
	const tp = env.SNOWLUMA_WEBUI_TRUST_PROXY;
	if (typeof tp === "string") out.trustProxy = tp;
	return out;
}
function loadRuntimeConfig() {
	fs$1.mkdirSync(CONFIG_DIR$2, { recursive: true });
	const parsed = tryLoadRuntimeConfig();
	const normalized = normalizeRuntimeConfig(parsed ?? {});
	if (parsed === null || !sameRuntimeConfig(parsed, normalized)) saveRuntimeConfig(normalized);
	return {
		...normalized,
		...resolveRuntimeEnvOverrides(process.env)
	};
}
/**
* Read the persisted config (normalized, no env overrides, no write). For the
* settings panel's GET — shows what's actually saved/editable on disk.
*/
function readRuntimeConfig() {
	return normalizeRuntimeConfig(tryLoadRuntimeConfig() ?? {});
}
/**
* Persist a partial update. Merges onto the ON-DISK config (not the env-merged
* runtime view) so an env override (e.g. SNOWLUMA_WEBUI_PORT) is never baked
* into runtime.json. Returns the new persisted config (without env overrides).
*/
function updateRuntimeConfig(patch) {
	fs$1.mkdirSync(CONFIG_DIR$2, { recursive: true });
	const next = normalizeRuntimeConfig({
		...normalizeRuntimeConfig(tryLoadRuntimeConfig() ?? {}),
		...patch
	});
	saveRuntimeConfig(next);
	return next;
}
function tryLoadRuntimeConfig() {
	if (!fs$1.existsSync(RUNTIME_CONFIG_PATH)) return null;
	try {
		const parsed = JSON.parse(fs$1.readFileSync(RUNTIME_CONFIG_PATH, "utf8"));
		return isObject$2(parsed) ? parsed : null;
	} catch {
		return null;
	}
}
function saveRuntimeConfig(config) {
	fs$1.writeFileSync(RUNTIME_CONFIG_PATH, JSON.stringify(config, null, 2), "utf8");
}
/** True when the raw on-disk object already matches the normalized config
*  on every known field (so we can skip a needless rewrite). */
function sameRuntimeConfig(parsed, n) {
	const parsedTls = isObject$2(parsed.webuiTls) ? parsed.webuiTls.enabled : void 0;
	return parsed.webuiPort === n.webuiPort && parsed.hookAutoLoad === n.hookAutoLoad && parsed.webuiHost === n.webuiHost && parsedTls === n.webuiTls?.enabled && parsed.trustProxy === n.trustProxy;
}
function parsePortString(raw) {
	if (typeof raw !== "string" || !raw.trim()) return void 0;
	const n = Number(raw.trim());
	if (!Number.isFinite(n)) return void 0;
	const port = Math.trunc(n);
	if (port <= 0 || port > 65535) return void 0;
	return port;
}
function normalizeHost(value) {
	if (typeof value === "string" && value.trim()) return value.trim();
	return DEFAULT_WEBUI_HOST;
}
function normalizePort(value, fallback) {
	if (typeof value === "number" && Number.isFinite(value)) {
		const n = Math.trunc(value);
		if (n > 0 && n <= 65535) return n;
		return fallback;
	}
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) {
			const port = Math.trunc(n);
			if (port > 0 && port <= 65535) return port;
		}
	}
	return fallback;
}
function normalizeBool(value, fallback) {
	if (typeof value === "boolean") return value;
	if (typeof value === "number") return value !== 0;
	if (typeof value === "string") {
		const v = value.trim().toLowerCase();
		if (v === "true" || v === "1" || v === "yes" || v === "on") return true;
		if (v === "false" || v === "0" || v === "no" || v === "off" || v === "") return false;
	}
	return fallback;
}
function isObject$2(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
//#region ../onebot/src/config.ts
var log$3 = createLogger("OneBot.Config");
var CONFIG_DIR$1 = "config";
var DEFAULT_CONFIG_PATH = path$1.join(CONFIG_DIR$1, "onebot.json");
var DEFAULT_ACCESS_TOKEN_BYTES = 32;
var DEFAULT_STATUS_COMMAND = {
	enabled: true,
	swallow: false,
	cooldownSeconds: 5,
	trigger: "#sl"
};
/** Upper bound on the status-command reply cooldown — a year is effectively "off but sane". */
var STATUS_COMMAND_COOLDOWN_MAX = 31536e3;
function makeDefaultStatusCommand() {
	return { ...DEFAULT_STATUS_COMMAND };
}
function makeDefaultOneBotConfig() {
	return {
		networks: {
			httpServers: [{
				name: "http-default",
				host: "0.0.0.0",
				port: 3e3,
				path: "/",
				accessToken: generateAccessToken(),
				messageFormat: "array",
				reportSelfMessage: false
			}],
			httpClients: [],
			wsServers: [{
				name: "ws-default",
				host: "0.0.0.0",
				port: 3001,
				path: "/",
				role: "Universal",
				accessToken: generateAccessToken(),
				messageFormat: "array",
				reportSelfMessage: false
			}],
			wsClients: []
		},
		musicSignUrl: "",
		statusCommand: makeDefaultStatusCommand(),
		notifications: { channelIds: [] },
		rkey: { fallbackServers: [] }
	};
}
function generateAccessToken() {
	return randomBytes(DEFAULT_ACCESS_TOKEN_BYTES).toString("base64url");
}
function loadOneBotConfig(uin, options = {}) {
	ensureConfigDir$1();
	const perUinPath = path$1.join(CONFIG_DIR$1, `onebot_${uin}.json`);
	const globalRaw = tryLoadJson(DEFAULT_CONFIG_PATH);
	const perUinRaw = tryLoadJson(perUinPath);
	const legacy = !!perUinRaw && hasLegacyTopLevel(perUinRaw);
	const sources = [];
	if (globalRaw) sources.push(globalRaw);
	if (perUinRaw) sources.push(perUinRaw);
	const config = fromJson(sources, !perUinRaw && !globalRaw);
	if (options.persistDefaults && (!perUinRaw || legacy)) saveOneBotConfig(uin, config);
	return config;
}
function saveOneBotConfig(uin, config) {
	ensureConfigDir$1();
	saveJson(path$1.join(CONFIG_DIR$1, `onebot_${uin}.json`), toJsonObject(config));
}
function ensureConfigDir$1() {
	fs$1.mkdirSync(CONFIG_DIR$1, { recursive: true });
}
function toJsonObject(config) {
	const nets = config.networks;
	return {
		networks: {
			httpServers: nets.httpServers.map(httpServerToJson),
			httpClients: nets.httpClients.map(httpClientToJson),
			wsServers: nets.wsServers.map(wsServerToJson),
			wsClients: nets.wsClients.map(wsClientToJson)
		},
		musicSignUrl: config.musicSignUrl ?? "",
		statusCommand: {
			enabled: config.statusCommand.enabled,
			swallow: config.statusCommand.swallow,
			cooldownSeconds: config.statusCommand.cooldownSeconds,
			trigger: config.statusCommand.trigger
		},
		notifications: { channelIds: config.notifications?.channelIds ?? [] },
		rkey: { fallbackServers: config.rkey?.fallbackServers ?? [] }
	};
}
function applyBase(out, n) {
	out.name = n.name;
	if (n.enabled === false) out.enabled = false;
	if (n.accessToken) out.accessToken = n.accessToken;
	out.messageFormat = n.messageFormat;
	out.reportSelfMessage = n.reportSelfMessage;
}
function httpServerToJson(n) {
	const out = {};
	applyBase(out, n);
	out.host = n.host ?? "0.0.0.0";
	out.port = n.port;
	out.path = n.path ?? "/";
	return out;
}
function httpClientToJson(n) {
	const out = {};
	applyBase(out, n);
	out.url = n.url;
	if (typeof n.timeoutMs === "number" && n.timeoutMs > 0) out.timeoutMs = n.timeoutMs;
	return out;
}
function wsServerToJson(n) {
	const out = {};
	applyBase(out, n);
	out.host = n.host ?? "0.0.0.0";
	out.port = n.port;
	out.path = n.path ?? "/";
	out.role = n.role ?? "Universal";
	return out;
}
function wsClientToJson(n) {
	const out = {};
	applyBase(out, n);
	out.url = n.url;
	out.role = n.role ?? "Universal";
	out.reconnectIntervalMs = typeof n.reconnectIntervalMs === "number" && Number.isFinite(n.reconnectIntervalMs) ? Math.max(1e3, Math.trunc(n.reconnectIntervalMs)) : 5e3;
	return out;
}
function fromJson(sources, freshInstall) {
	let legacyFormat;
	let legacyReport;
	let musicSignUrl = "";
	for (const src of sources) {
		const mf = parseMessageFormat(src.messageFormat);
		if (mf) legacyFormat = mf;
		if (typeof src.reportSelfMessage === "boolean") legacyReport = src.reportSelfMessage;
		if (typeof src.musicSignUrl === "string") musicSignUrl = src.musicSignUrl;
	}
	const adapterDefaults = {
		messageFormat: legacyFormat ?? "array",
		reportSelfMessage: legacyReport ?? false
	};
	const httpServers = collectByName(sources, "httpServers", (raw) => parseHttpServer(raw, adapterDefaults));
	const httpClients = collectByName(sources, "httpClients", (raw) => parseHttpClient(raw, adapterDefaults), "httpPostEndpoints");
	const wsServers = collectByName(sources, "wsServers", (raw) => parseWsServer(raw, adapterDefaults));
	const wsClients = collectByName(sources, "wsClients", (raw) => parseWsClient(raw, adapterDefaults));
	if (freshInstall && httpServers.length === 0 && httpClients.length === 0 && wsServers.length === 0 && wsClients.length === 0) {
		const defaults = makeDefaultOneBotConfig().networks;
		httpServers.push(...defaults.httpServers);
		wsServers.push(...defaults.wsServers);
	}
	return {
		networks: {
			httpServers,
			httpClients,
			wsServers,
			wsClients
		},
		musicSignUrl,
		statusCommand: parseStatusCommand(sources),
		notifications: parseNotifications(sources),
		rkey: parseRKeyConfig(sources)
	};
}
/** Last-write-wins merge of `rkey.fallbackServers` across config sources. Only
*  http(s) URLs are kept; the list is deduped. Default empty (feature off). */
function parseRKeyConfig(sources) {
	let fallbackServers = [];
	for (const src of sources) {
		const raw = src.rkey;
		if (!isObject$1(raw)) continue;
		if (Array.isArray(raw.fallbackServers)) fallbackServers = normalizeRkeyServers(raw.fallbackServers);
	}
	return { fallbackServers };
}
function normalizeRkeyServers(value) {
	if (!Array.isArray(value)) return [];
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const item of value) {
		if (typeof item !== "string") continue;
		const v = item.trim();
		if (!v || !/^https?:\/\//i.test(v)) continue;
		if (seen.has(v)) continue;
		seen.add(v);
		out.push(v);
	}
	return out;
}
/** Last-write-wins merge of `notifications.channelIds` across config sources,
*  each id validated as a slug + deduped. Mirrors the channel-id rule in
*  packages/core/src/notifications/config.ts (CHANNEL_ID_RE) — duplicated
*  deliberately: core depends on onebot, so onebot cannot import from core. */
function parseNotifications(sources) {
	let channelIds = [];
	for (const src of sources) {
		const raw = src.notifications;
		if (!isObject$1(raw)) continue;
		if (Array.isArray(raw.channelIds)) channelIds = normalizeChannelIds(raw.channelIds);
	}
	return { channelIds };
}
function normalizeChannelIds(value) {
	if (!Array.isArray(value)) return [];
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const item of value) {
		if (typeof item !== "string") continue;
		const v = item.trim();
		if (!v || v.length > 64 || !/^[\w.-]+$/.test(v)) continue;
		if (seen.has(v)) continue;
		seen.add(v);
		out.push(v);
	}
	return out;
}
/** Last-write-wins merge of `statusCommand` across config sources, with
*  defaults filled and the cooldown clamped to a sane non-negative range. */
function parseStatusCommand(sources) {
	const out = makeDefaultStatusCommand();
	for (const src of sources) {
		const raw = src.statusCommand;
		if (!isObject$1(raw)) continue;
		if (typeof raw.enabled === "boolean") out.enabled = raw.enabled;
		if (typeof raw.swallow === "boolean") out.swallow = raw.swallow;
		if (raw.cooldownSeconds !== void 0) out.cooldownSeconds = Math.min(STATUS_COMMAND_COOLDOWN_MAX, asNumber$1(raw.cooldownSeconds, DEFAULT_STATUS_COMMAND.cooldownSeconds));
		if (typeof raw.trigger === "string" && raw.trigger.trim().length > 0 && !/[\r\n]/.test(raw.trigger)) out.trigger = raw.trigger.trim().slice(0, 32);
	}
	return out;
}
function collectByName(sources, kind, parse, legacyKey) {
	const byName = /* @__PURE__ */ new Map();
	const order = [];
	let counter = 0;
	const ingest = (rawArr) => {
		if (!Array.isArray(rawArr)) return;
		for (const raw of rawArr) {
			if (!isObject$1(raw)) continue;
			const parsed = parse(raw);
			if (!parsed) continue;
			const name = parsed.name && parsed.name.trim() ? parsed.name.trim() : pickAutoName(kind, byName, ++counter);
			parsed.name = name;
			if (!byName.has(name)) order.push(name);
			byName.set(name, parsed);
		}
	};
	for (const src of sources) {
		ingest(isObject$1(src.networks) ? src.networks[kind] : void 0);
		if (legacyKey) ingest(src[legacyKey]);
		ingest(src[kind]);
	}
	return order.map((n) => byName.get(n));
}
function pickAutoName(kind, used, counter) {
	const prefix = kind === "httpServers" ? "http" : kind === "httpClients" ? "httppost" : kind === "wsServers" ? "ws" : "wsclient";
	let candidate = `${prefix}-${counter}`;
	while (used.has(candidate)) {
		counter += 1;
		candidate = `${prefix}-${counter}`;
	}
	return candidate;
}
function parseBase(value, defaults) {
	return {
		name: asString$1(value.name),
		enabled: typeof value.enabled === "boolean" ? value.enabled : void 0,
		accessToken: asString$1(value.accessToken) || void 0,
		messageFormat: parseMessageFormat(value.messageFormat) ?? defaults.messageFormat,
		reportSelfMessage: typeof value.reportSelfMessage === "boolean" ? value.reportSelfMessage : defaults.reportSelfMessage
	};
}
function parseHttpServer(value, defaults) {
	const port = asNumber$1(value.port, 0);
	if (port <= 0) return null;
	return clean({
		...parseBase(value, defaults),
		host: asString$1(value.host, "0.0.0.0"),
		port,
		path: asString$1(value.path, "/")
	});
}
function parseHttpClient(value, defaults) {
	const url = asString$1(value.url);
	if (!url) return null;
	const timeout = asNumber$1(value.timeoutMs, 0);
	return clean({
		...parseBase(value, defaults),
		url,
		timeoutMs: timeout > 0 ? timeout : void 0
	});
}
function parseWsServer(value, defaults) {
	const port = asNumber$1(value.port, 0);
	if (port <= 0) return null;
	return clean({
		...parseBase(value, defaults),
		host: asString$1(value.host, "0.0.0.0"),
		port,
		path: asString$1(value.path, "/"),
		role: asRole(value.role, "Universal")
	});
}
function parseWsClient(value, defaults) {
	const url = asString$1(value.url);
	if (!url) return null;
	const reconnectIntervalMs = asNumber$1(value.reconnectIntervalMs, 5e3);
	return clean({
		...parseBase(value, defaults),
		url,
		role: asRole(value.role, "Universal"),
		reconnectIntervalMs: Math.max(1e3, reconnectIntervalMs)
	});
}
function hasLegacyTopLevel(raw) {
	return Array.isArray(raw.httpServers) || Array.isArray(raw.httpPostEndpoints) || Array.isArray(raw.wsServers) || Array.isArray(raw.wsClients) || typeof raw.messageFormat === "string" || typeof raw.reportSelfMessage === "boolean";
}
function parseMessageFormat(value) {
	if (value === "array" || value === "string") return value;
}
function clean(obj) {
	for (const key of Object.keys(obj)) if (obj[key] === void 0) delete obj[key];
	return obj;
}
function asRole(value, fallback) {
	const text = asString$1(value, fallback).toLowerCase();
	if (text === "api") return "Api";
	if (text === "event") return "Event";
	if (text === "universal") return "Universal";
	return fallback;
}
function asString$1(value, fallback = "") {
	if (typeof value === "string") return value;
	if (typeof value === "number" || typeof value === "boolean") return String(value);
	return fallback;
}
function asNumber$1(value, fallback = 0) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.max(0, Math.trunc(value));
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) return Math.max(0, Math.trunc(n));
	}
	return fallback;
}
function tryLoadJson(filePath) {
	if (!fs$1.existsSync(filePath)) return null;
	try {
		const raw = fs$1.readFileSync(filePath, "utf8");
		const parsed = JSON.parse(raw);
		return isObject$1(parsed) ? parsed : null;
	} catch (err) {
		log$3.warn("config file %s is corrupt and will be ignored: %s", filePath, err instanceof Error ? err.message : String(err));
		return null;
	}
}
function saveJson(filePath, json) {
	fs$1.mkdirSync(path$1.dirname(filePath), { recursive: true });
	fs$1.writeFileSync(filePath, JSON.stringify(json, null, 2), "utf8");
}
function isObject$1(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
//#region ../common/src/log-summary.ts
var MAX_FIELD = 40;
var MAX_TOTAL = 200;
function valueRepr(v) {
	if (v === null) return "null";
	if (v === void 0) return "undefined";
	switch (typeof v) {
		case "string": return v.length > MAX_FIELD ? `"${v.slice(0, MAX_FIELD)}..."` : `"${v}"`;
		case "number":
		case "boolean":
		case "bigint": return String(v);
		case "object":
			if (Array.isArray(v)) return `[len=${v.length}]`;
			return "{...}";
		default: return typeof v;
	}
}
/**
* Render a params object as a single line for logging. Skips deep
* traversal: nested objects collapse to `{...}`, arrays to `[len=N]`.
* Strings are quoted; long ones are truncated with an ellipsis.
*
* Output is capped at MAX_TOTAL chars; on overflow the tail is
* replaced with `...` so the next field doesn't get half-rendered.
*/
function summarizeParams(params) {
	if (params === null || params === void 0) return "{}";
	if (typeof params !== "object") {
		const s = String(params);
		return s.length > MAX_TOTAL ? `${s.slice(0, MAX_TOTAL)}...` : s;
	}
	if (Array.isArray(params)) return `[len=${params.length}]`;
	const out = [];
	let total = 0;
	for (const [k, v] of Object.entries(params)) {
		const entry = `${k}=${valueRepr(v)}`;
		if (total > 0 && total + entry.length + 1 > MAX_TOTAL) {
			out.push("...");
			break;
		}
		out.push(entry);
		total += entry.length + (out.length > 1 ? 1 : 0);
	}
	return out.join(" ");
}
var VERBOSE_STRING_MAX = 200;
var VERBOSE_TOTAL_MAX = 1500;
var REDACT_KEY = /^(.*[-_])?(token|password|passwd|secret|access[-_]?token)([-_].*)?$/i;
/**
* Deep, debug-grade render of a params object for the `trace` level: shows the
* full nested structure (message segments, nested objects) so a reproduction
* is legible — unlike {@link summarizeParams}, which collapses nested values.
*
* Three guards keep it safe and bounded:
*  - per-string cap (long values like base64 image data become `"…<N B>"`),
*  - total output budget (so a giant payload can't flood the buffer),
*  - key-based redaction (token / password / secret → `"***"`).
*/
function renderParamsVerbose(params) {
	const seen = /* @__PURE__ */ new WeakSet();
	let budget = VERBOSE_TOTAL_MAX;
	const walk = (value, key) => {
		if (budget <= 0) return "…";
		if (key !== void 0 && REDACT_KEY.test(key)) return "\"***\"";
		if (value === null) return "null";
		if (value === void 0) return "undefined";
		switch (typeof value) {
			case "string": {
				const truncated = value.length > VERBOSE_STRING_MAX ? `${value.slice(0, VERBOSE_STRING_MAX)}…<${value.length}B>` : value;
				const out = JSON.stringify(truncated);
				budget -= out.length;
				return out;
			}
			case "number":
			case "boolean":
			case "bigint": {
				const out = String(value);
				budget -= out.length;
				return out;
			}
			case "object": {
				if (seen.has(value)) return "\"[circular]\"";
				seen.add(value);
				const parts = [];
				if (Array.isArray(value)) {
					for (const item of value) {
						if (budget <= 0) {
							parts.push("…");
							break;
						}
						parts.push(walk(item));
					}
					return `[${parts.join(",")}]`;
				}
				for (const [k, v] of Object.entries(value)) {
					if (budget <= 0) {
						parts.push("…");
						break;
					}
					parts.push(`${k}:${walk(v, k)}`);
				}
				return `{${parts.join(",")}}`;
			}
			default: return typeof value;
		}
	};
	return walk(params);
}
//#endregion
//#region ../onebot/src/types.ts
var RETCODE = {
	ACTION_FAILED: 100,
	INTERNAL_ERROR: 1200,
	BAD_REQUEST: 1400,
	UNKNOWN_ACTION: 1404
};
function okResponse(data = null) {
	return {
		status: "ok",
		retcode: 0,
		data
	};
}
function failedResponse(retcode, wording) {
	return {
		status: "failed",
		retcode,
		data: null,
		wording
	};
}
//#endregion
//#region ../onebot/src/action-kit.ts
var ok = (value) => ({
	ok: true,
	value
});
var err = (field, reason) => ({
	ok: false,
	field,
	reason
});
/** Only an absent key produces MISSING — this is what lets a present `0` /
*  `''` / `false` be distinguished from "not provided". */
var MISSING = Symbol("missing");
var FieldImpl = class FieldImpl {
	core;
	doc;
	constructor(core, doc) {
		this.core = core;
		this.doc = doc;
	}
	coerce(raw, field) {
		if (raw === MISSING) {
			if (this.doc.required) return err(field, "is required");
			return ok(this.doc.default);
		}
		return this.core(raw, field);
	}
	optional() {
		return new FieldImpl(this.core, {
			...this.doc,
			required: false,
			default: void 0
		});
	}
	default(value) {
		return new FieldImpl(this.core, {
			...this.doc,
			required: false,
			default: value
		});
	}
	describe(text) {
		return new FieldImpl(this.core, {
			...this.doc,
			desc: text
		});
	}
	toJsonSchema() {
		const out = { ...this.doc.schema ?? {} };
		if (this.doc.desc) out.description = this.doc.desc;
		if (this.doc.default !== void 0) out.default = this.doc.default;
		return out;
	}
};
/** Accept a number or numeric string, truncate to integer (matches the legacy
*  `asNumber`), then apply bounds. Non-numeric / blank ⇒ Err. */
function intCore(typeName, opts) {
	return (raw, field) => {
		let n;
		if (typeof raw === "number" && Number.isFinite(raw)) n = Math.trunc(raw);
		else if (typeof raw === "string" && raw.trim() !== "" && Number.isFinite(Number(raw))) n = Math.trunc(Number(raw));
		else return err(field, `expected ${typeName}`);
		if (opts.nonZero && n === 0) return err(field, "must not be 0");
		if (opts.min !== void 0 && n < opts.min) return err(field, `must be >= ${opts.min}`);
		if (opts.max !== void 0 && n > opts.max) return err(field, `must be <= ${opts.max}`);
		return ok(n);
	};
}
function intSchema(opts) {
	const s = { type: "integer" };
	if (opts.min !== void 0) s.minimum = opts.min;
	if (opts.max !== void 0) s.maximum = opts.max;
	if (opts.nonZero) s.not = { const: 0 };
	return s;
}
function strSchema(opts) {
	const s = { type: "string" };
	if (opts.allowEmpty === false) s.minLength = 1;
	if (opts.maxLen !== void 0) s.maxLength = opts.maxLen;
	return s;
}
function arrayField(el, mustBeNonEmpty) {
	const core = (raw, field) => {
		if (!Array.isArray(raw)) return err(field, "expected an array");
		const out = [];
		for (let i = 0; i < raw.length; i++) {
			const r = el.coerce(raw[i], `${field}[${i}]`);
			if (!r.ok) return r;
			out.push(r.value);
		}
		if (mustBeNonEmpty && out.length === 0) return err(field, "must not be empty");
		return ok(out);
	};
	const base = new FieldImpl(core, {
		type: `${el.doc.type}[]`,
		required: true,
		schema: {
			type: "array",
			items: el.toJsonSchema(),
			...mustBeNonEmpty ? { minItems: 1 } : {}
		}
	});
	return Object.assign(base, { nonEmpty: () => arrayField(el, true) });
}
var f = {
	/** Positive integer (>0): group_id / user_id / message_id. */
	uint() {
		return new FieldImpl(intCore("a positive integer", { min: 1 }), {
			type: "uint",
			required: true,
			schema: intSchema({ min: 1 })
		});
	},
	/** Integer with optional bounds; allows 0 / negatives unless bounded.
	*  e.g. a duration where 0 is meaningful: `f.int({ min: 0 })`. */
	int(opts = {}) {
		return new FieldImpl(intCore("an integer", opts), {
			type: "int",
			required: true,
			schema: intSchema(opts)
		});
	},
	/** OneBot message id: a non-zero integer. NEGATIVES ARE VALID (ids are a
	*  signed int32 hash) — do NOT use `uint()` for message_id. */
	messageId() {
		return new FieldImpl(intCore("a message id", { nonZero: true }), {
			type: "messageId",
			required: true,
			schema: intSchema({ nonZero: true })
		});
	},
	/** Finite number (fractions allowed). */
	number() {
		return new FieldImpl((raw, field) => {
			if (typeof raw === "number" && Number.isFinite(raw)) return ok(raw);
			if (typeof raw === "string" && raw.trim() !== "" && Number.isFinite(Number(raw))) return ok(Number(raw));
			return err(field, "expected a number");
		}, {
			type: "number",
			required: true,
			schema: { type: "number" }
		});
	},
	/** String. Numbers/booleans stringify (matches legacy `asString`). Empty
	*  allowed by default; `{ allowEmpty: false }` rejects ''. */
	string(opts = {}) {
		return new FieldImpl((raw, field) => {
			let s;
			if (typeof raw === "string") s = raw;
			else if (typeof raw === "number" || typeof raw === "boolean") s = String(raw);
			else return err(field, "expected a string");
			if (opts.allowEmpty === false && s === "") return err(field, "must not be empty");
			if (opts.maxLen !== void 0 && s.length > opts.maxLen) return err(field, `must be <= ${opts.maxLen} chars`);
			return ok(s);
		}, {
			type: "string",
			required: true,
			schema: strSchema(opts)
		});
	},
	/** true/1/yes/on ⇒ true; false/0/no/off ⇒ false (matches legacy `asBoolean`). */
	bool() {
		return new FieldImpl((raw, field) => {
			if (typeof raw === "boolean") return ok(raw);
			if (typeof raw === "number") return ok(raw !== 0);
			if (typeof raw === "string") {
				const t = raw.trim().toLowerCase();
				if (t === "true" || t === "1" || t === "yes" || t === "on") return ok(true);
				if (t === "false" || t === "0" || t === "no" || t === "off") return ok(false);
			}
			return err(field, "expected a boolean");
		}, {
			type: "bool",
			required: true,
			schema: { type: "boolean" }
		});
	},
	/** OneBot message union: string | segment[] | object. A string that looks
	*  like a JSON array is parsed (matches legacy `asMessage`); otherwise the
	*  value passes through. Output stays `JsonValue` — downstream ctx.* accept it. */
	message() {
		return new FieldImpl((raw, _field) => {
			if (typeof raw === "string") {
				const t = raw.trim();
				if (t.startsWith("[") && t.endsWith("]")) try {
					const parsed = JSON.parse(t);
					if (Array.isArray(parsed)) return ok(parsed);
				} catch {}
			}
			return ok(raw);
		}, {
			type: "message",
			required: true,
			schema: { description: "OneBot message: string | segment[] | object" }
		});
	},
	/** Homogeneous array; `.nonEmpty()` rejects []. */
	array(el) {
		return arrayField(el, false);
	},
	/** Constrained literal set. */
	enum(...values) {
		return new FieldImpl((raw, field) => {
			if ((typeof raw === "string" || typeof raw === "number") && values.includes(raw)) return ok(raw);
			return err(field, `expected one of: ${values.join(", ")}`);
		}, {
			type: "enum",
			required: true,
			values,
			schema: { enum: [...values] }
		});
	},
	/** Escape hatch — pass the raw value (or undefined) through, validate nothing. */
	raw() {
		return new FieldImpl((raw) => ok(raw), {
			type: "raw",
			required: false,
			default: void 0,
			schema: {}
		});
	}
};
var present = (p, key) => p[key] !== void 0;
var groupOk = (p, g) => Array.isArray(g) ? g.every((k) => present(p, k)) : present(p, g);
var groupLabel = (g) => Array.isArray(g) ? `(${g.join("+")})` : g;
var RULES = {
	exactlyOneOf(...groups) {
		const doc = `exactly one of: ${groups.map(groupLabel).join(" | ")}`;
		return {
			doc,
			check: (p) => groups.filter((g) => groupOk(p, g)).length === 1 ? null : err("", doc)
		};
	},
	atLeastOneOf(...keys) {
		const doc = `at least one of: ${keys.join(", ")}`;
		return {
			doc,
			check: (p) => keys.some((k) => present(p, k)) ? null : err("", doc)
		};
	},
	requiredTogether(...keys) {
		const doc = `all or none of: ${keys.join(", ")}`;
		return {
			doc,
			check: (p) => {
				const n = keys.filter((k) => present(p, k)).length;
				return n === 0 || n === keys.length ? null : err("", doc);
			}
		};
	},
	mutuallyExclusive(...keys) {
		const doc = `at most one of: ${keys.join(", ")}`;
		return {
			doc,
			check: (p) => keys.filter((k) => present(p, k)).length <= 1 ? null : err("", doc)
		};
	},
	rule(doc, okFn) {
		return {
			doc,
			check: (p) => okFn(p) ? null : err("", doc)
		};
	}
};
var wording = (e) => e.field ? `${e.field}: ${e.reason}` : e.reason;
function defineAction(def) {
	const names = typeof def.name === "string" ? [def.name] : [...def.name];
	const rules = def.rules ? def.rules(RULES) : [];
	const parse = (raw) => {
		const out = {};
		for (const key of Object.keys(def.params)) {
			const field = def.params[key];
			const value = Object.prototype.hasOwnProperty.call(raw, key) ? raw[key] : MISSING;
			const r = field.coerce(value, key);
			if (!r.ok) return r;
			out[key] = r.value;
		}
		for (const rule of rules) {
			const e = rule.check(out);
			if (e) return e;
		}
		return ok(out);
	};
	const toHandler = (ctx) => async (params) => {
		const r = parse(params);
		if (!r.ok) return failedResponse(RETCODE.BAD_REQUEST, wording(r));
		return def.run(r.value, ctx, params);
	};
	return {
		names,
		params: def.params,
		parse,
		toHandler,
		describe: () => {
			const entries = Object.entries(def.params);
			const properties = {};
			const required = [];
			for (const [name, field] of entries) {
				properties[name] = field.toJsonSchema();
				if (field.doc.required) required.push(name);
			}
			const inputSchema = {
				type: "object",
				properties,
				...required.length ? { required } : {},
				additionalProperties: true
			};
			return {
				name: names[0],
				aliases: names.slice(1),
				summary: def.summary,
				returns: def.returns,
				returnsSchema: def.returnsSchema,
				readOnly: def.readOnly ?? false,
				params: entries.map(([name, field]) => ({
					name,
					...field.doc
				})),
				invariants: rules.map((rule) => rule.doc),
				inputSchema
			};
		},
		register: (h, ctx) => {
			const handler = toHandler(ctx);
			for (const name of names) h.registerAction(name, handler);
		}
	};
}
/** Pre-seeds `group_id` (uint, required). */
function groupAction(def) {
	const params = {
		group_id: f.uint().describe("群号"),
		...def.params ?? {}
	};
	return defineAction({
		...def,
		params
	});
}
/** Pre-seeds `group_id` + `user_id` (both uint, required). */
function groupUserAction(def) {
	const params = {
		group_id: f.uint().describe("群号"),
		user_id: f.uint().describe("QQ 号"),
		...def.params ?? {}
	};
	return defineAction({
		...def,
		params
	});
}
/** Register many specs onto an ApiHandler. Coexists with legacy
*  `h.registerAction(name, fn)` in the same `register(h, ctx)`. */
function registerActions(h, ctx, specs) {
	for (const spec of specs) spec.register(h, ctx);
}
//#endregion
//#region ../onebot/src/actions/extended.ts
var DOWNLOAD_FILE_MAX_BYTES = 1024 * 1024 * 1024;
var DOWNLOAD_FILE_TIMEOUT_MS = 6e4;
async function fetchDownloadFile(url, headers, maxBytes, timeoutMs) {
	const response = await fetch(url, {
		headers,
		signal: AbortSignal.timeout(timeoutMs)
	});
	if (!response.ok) throw new Error(`download failed: HTTP ${response.status}`);
	const declared = Number(response.headers.get("content-length") ?? "0");
	if (Number.isFinite(declared) && declared > maxBytes) throw new Error(`download too large: ${declared} > ${maxBytes}`);
	const reader = response.body?.getReader();
	if (!reader) {
		const bytes = Buffer.from(await response.arrayBuffer());
		if (bytes.length > maxBytes) throw new Error(`download too large: ${bytes.length} > ${maxBytes}`);
		return bytes;
	}
	const chunks = [];
	let total = 0;
	try {
		while (true) {
			const { done, value } = await reader.read();
			if (done) break;
			if (!value) continue;
			total += value.byteLength;
			if (total > maxBytes) {
				await reader.cancel().catch(() => {});
				throw new Error(`download too large: > ${maxBytes}`);
			}
			chunks.push(value);
		}
	} finally {
		reader.releaseLock();
	}
	return Buffer.concat(chunks, total);
}
async function saveDownloadBuffer(buf, preferredName) {
	const fs = await import("fs");
	const pathMod = await import("path");
	const cryptoMod = await import("crypto");
	const tempDir = pathMod.resolve("data", "downloads");
	if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });
	const rawName = preferredName || cryptoMod.createHash("md5").update(buf).digest("hex");
	const safeName = pathMod.basename(rawName);
	if (!safeName || safeName === "." || safeName === ".." || /[\\/]/.test(safeName)) throw new Error("invalid file name");
	const resolved = pathMod.resolve(tempDir, safeName);
	const rel = pathMod.relative(tempDir, resolved);
	if (rel.startsWith("..") || pathMod.isAbsolute(rel)) throw new Error("invalid file name");
	await fs.promises.writeFile(resolved, buf);
	return resolved;
}
function readForwardPreviewMeta(params) {
	const source = asString(params.source) || void 0;
	const summary = asString(params.summary) || void 0;
	const prompt = asString(params.prompt) || void 0;
	let news;
	if (Array.isArray(params.news)) {
		const collected = [];
		for (const item of params.news) if (typeof item === "string") collected.push({ text: item });
		else if (item && typeof item === "object" && !Array.isArray(item)) {
			const text = asString(item.text);
			if (text) collected.push({ text });
		}
		if (collected.length > 0) news = collected;
	}
	if (!source && !summary && !prompt && !news) return void 0;
	return {
		source,
		summary,
		prompt,
		news
	};
}
async function groupTodoRun(p, ctx, op) {
	const meta = ctx.getMessageMeta(p.message_id);
	if (!meta) return failedResponse(RETCODE.ACTION_FAILED, "message not found");
	if (!meta.isGroup || meta.targetId !== p.group_id) return failedResponse(RETCODE.ACTION_FAILED, "message does not belong to this group");
	try {
		await op(p.group_id, BigInt(meta.sequence));
		return okResponse();
	} catch (err) {
		return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
	}
}
/** FlashTransferApi 返回的 FlashFileInfo → OneBot JSON 响应（plain object，JsonObject 兼容）。
*  字段名对齐 NapCat（get_flash_file_list 用 size，非 file_size），便于客户端 drop-in 迁移。 */
function flashFileInfoToJson(f) {
	return {
		fileset_id: f.filesetUuid,
		file_name: f.fileName,
		orig_name: f.origName,
		size: f.fileSize,
		share_url: f.shareUrl,
		file_id: f.fileId,
		download_url: f.downloadUrl
	};
}
var actions$9 = [
	defineAction({
		name: "send_like",
		summary: "点赞",
		params: {
			user_id: f.uint(),
			times: f.int({ min: 0 }).default(1)
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.interaction.sendLike(p.user_id, p.times);
			return okResponse();
		}
	}),
	defineAction({
		name: "friend_poke",
		summary: "好友拍一拍",
		params: {
			user_id: f.uint(),
			target_id: f.uint().optional()
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.interaction.sendPoke(false, p.user_id, p.target_id);
			return okResponse();
		}
	}),
	groupUserAction({
		name: "group_poke",
		summary: "群拍一拍",
		run: async (p, ctx) => {
			await ctx.bridge.apis.interaction.sendPoke(true, p.group_id, p.user_id);
			return okResponse();
		}
	}),
	defineAction({
		name: "send_poke",
		summary: "拍一拍（群聊/私聊自动路由）",
		params: {
			user_id: f.uint(),
			group_id: f.uint().optional()
		},
		run: async (p, ctx) => {
			if (p.group_id) await ctx.bridge.apis.interaction.sendPoke(true, p.group_id, p.user_id);
			else await ctx.bridge.apis.interaction.sendPoke(false, p.user_id);
			return okResponse();
		}
	}),
	defineAction({
		name: "set_essence_msg",
		summary: "设置精华消息",
		params: { message_id: f.messageId() },
		run: async (p, ctx) => {
			await ctx.setEssenceMsg(p.message_id);
			return okResponse();
		}
	}),
	defineAction({
		name: "delete_essence_msg",
		summary: "移除精华消息",
		params: { message_id: f.messageId() },
		run: async (p, ctx) => {
			await ctx.deleteEssenceMsg(p.message_id);
			return okResponse();
		}
	}),
	groupAction({
		name: "get_essence_msg_list",
		summary: "获取精华消息列表",
		readOnly: true,
		run: async (p, ctx) => {
			try {
				return okResponse((await ctx.bridge.apis.web.getEssenceAll(p.group_id)).flatMap((res) => res.data?.msg_list || []));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, `获取精华消息失败: ${e}`);
			}
		}
	}),
	defineAction({
		name: "set_group_reaction",
		summary: "群聊表情回应",
		params: {
			group_id: f.uint().optional(),
			message_id: f.messageId(),
			code: f.string({ allowEmpty: false }),
			is_set: f.bool().default(true)
		},
		run: async (p, ctx) => {
			const meta = ctx.getMessageMeta(p.message_id);
			if (!meta || !meta.isGroup) return failedResponse(RETCODE.ACTION_FAILED, "message not found or not a group message");
			if (p.group_id && p.group_id !== meta.targetId) return failedResponse(RETCODE.BAD_REQUEST, "group_id does not match message session");
			await ctx.bridge.apis.interaction.setReaction(meta.targetId, meta.sequence, p.code, p.is_set);
			return okResponse();
		}
	}),
	defineAction({
		name: "delete_custom_face",
		summary: "删除收藏表情",
		params: { emoji_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.profile.deleteCustomFace(p.emoji_id);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "add_custom_face",
		summary: "添加收藏表情",
		params: { file: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				return okResponse({ emoji_id: await ctx.bridge.apis.profile.addCustomFace(p.file) });
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "modify_custom_face",
		summary: "修改收藏表情备注",
		params: {
			emoji_id: f.string({ allowEmpty: false }),
			desc: f.string().default("")
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.profile.modifyCustomFace(p.emoji_id, p.desc);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "move_custom_face_to_front",
		summary: "收藏表情移到最前",
		params: { emoji_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.profile.moveCustomFaceToFront(p.emoji_id);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	groupAction({
		name: "get_group_msg_history",
		summary: "获取群消息历史",
		readOnly: true,
		returns: "{ messages }：群消息事件对象数组（每项为 OneBot 消息事件，内部字段不固定）。",
		returnsSchema: {
			type: "object",
			properties: { messages: {
				type: "array",
				description: "消息事件对象数组",
				items: { type: "object" }
			} },
			required: ["messages"]
		},
		params: {
			message_id: f.int().default(0),
			count: f.int({ min: 0 }).default(20)
		},
		run: async (p, ctx) => {
			return okResponse({ messages: await ctx.getGroupMsgHistory(p.group_id, p.message_id, p.count) });
		}
	}),
	defineAction({
		name: "get_friend_msg_history",
		summary: "获取好友消息历史",
		readOnly: true,
		returns: "{ messages }：好友消息事件对象数组（每项为 OneBot 消息事件，内部字段不固定）。",
		returnsSchema: {
			type: "object",
			properties: { messages: {
				type: "array",
				description: "消息事件对象数组",
				items: { type: "object" }
			} },
			required: ["messages"]
		},
		params: {
			user_id: f.uint(),
			message_id: f.int().default(0),
			count: f.int({ min: 0 }).default(20)
		},
		run: async (p, ctx) => {
			return okResponse({ messages: await ctx.getFriendMsgHistory(p.user_id, p.message_id, p.count) });
		}
	}),
	defineAction({
		name: "mark_group_msg_as_read",
		summary: "标记群消息已读",
		params: {
			message_id: f.messageId(),
			group_id: f.uint().optional()
		},
		run: async (p, ctx) => {
			const meta = ctx.getMessageMeta(p.message_id);
			if (!meta || !meta.isGroup) return failedResponse(RETCODE.ACTION_FAILED, "message not found or not a group message");
			if (p.group_id && p.group_id !== meta.targetId) return failedResponse(RETCODE.BAD_REQUEST, "group_id does not match message session");
			await ctx.bridge.apis.message.markGroupRead(meta.targetId, meta.sequence);
			return okResponse();
		}
	}),
	defineAction({
		name: "mark_private_msg_as_read",
		summary: "标记私聊消息已读",
		params: {
			message_id: f.messageId(),
			user_id: f.uint().optional()
		},
		run: async (p, ctx) => {
			const meta = ctx.getMessageMeta(p.message_id);
			if (!meta || meta.isGroup) return failedResponse(RETCODE.ACTION_FAILED, "message not found or not a private message");
			if (p.user_id && p.user_id !== meta.targetId) return failedResponse(RETCODE.BAD_REQUEST, "user_id does not match message session");
			await ctx.bridge.apis.message.markPrivateRead(meta.targetId, meta.sequence);
			return okResponse();
		}
	}),
	defineAction({
		name: "mark_msg_as_read",
		summary: "标记消息已读（群聊/私聊自动路由）",
		params: {
			message_id: f.messageId(),
			target_id: f.uint().optional()
		},
		run: async (p, ctx) => {
			const meta = ctx.getMessageMeta(p.message_id);
			if (!meta) return failedResponse(RETCODE.ACTION_FAILED, "message not found");
			if (p.target_id && p.target_id !== meta.targetId) return failedResponse(RETCODE.BAD_REQUEST, "target_id does not match message session");
			if (meta.isGroup) await ctx.bridge.apis.message.markGroupRead(meta.targetId, meta.sequence);
			else await ctx.bridge.apis.message.markPrivateRead(meta.targetId, meta.sequence);
			return okResponse();
		}
	}),
	groupAction({
		name: "_send_group_notice",
		summary: "发送群公告",
		params: {
			content: f.string({ allowEmpty: false }),
			image: f.string().default(""),
			pinned: f.raw(),
			type: f.raw(),
			confirm_required: f.raw()
		},
		run: async (p, ctx) => {
			try {
				const options = {
					image: p.image || void 0,
					pinned: p.pinned !== void 0 ? Number(p.pinned) : 0,
					type: p.type !== void 0 ? Number(p.type) : 1,
					confirm_required: p.confirm_required !== void 0 ? Number(p.confirm_required) : 1
				};
				await ctx.bridge.apis.web.sendNotice(p.group_id, p.content, options);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	groupAction({
		name: "_get_group_notice",
		summary: "获取群公告",
		readOnly: true,
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.web.getNotice(p.group_id));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "upload_forward_msg",
		summary: "上传转发消息",
		params: {
			messages: f.message().optional(),
			message: f.message().optional(),
			group_id: f.uint().optional()
		},
		run: async (p, ctx) => {
			const messages = p.messages ?? p.message;
			const groupId = p.group_id ?? 0;
			if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
			const result = await ctx.sendForwardMsg(messages, groupId > 0 ? groupId : void 0);
			const data = {
				res_id: result.forwardId,
				forward_id: result.forwardId,
				message_id: 0
			};
			if (groupId > 0) data.group_id = groupId;
			return okResponse(data);
		}
	}),
	defineAction({
		name: "upload_foward_msg",
		summary: "上传转发消息（别名拼写）",
		params: {
			messages: f.message().optional(),
			message: f.message().optional(),
			group_id: f.uint().optional()
		},
		run: async (p, ctx) => {
			const messages = p.messages ?? p.message;
			const groupId = p.group_id ?? 0;
			if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
			const result = await ctx.sendForwardMsg(messages, groupId > 0 ? groupId : void 0);
			return okResponse({
				res_id: result.forwardId,
				forward_id: result.forwardId,
				message_id: 0
			});
		}
	}),
	defineAction({
		name: "get_image",
		summary: "获取图片信息",
		readOnly: true,
		params: {
			file: f.string().default(""),
			file_id: f.string().default("")
		},
		run: async (p, ctx) => {
			const file = p.file || p.file_id;
			if (!file) return failedResponse(RETCODE.BAD_REQUEST, "file is required");
			const info = await ctx.getImageInfo(file);
			if (info) return okResponse(info);
			return failedResponse(RETCODE.ACTION_FAILED, "image not found in cache");
		}
	}),
	defineAction({
		name: "get_record",
		summary: "获取语音信息",
		readOnly: true,
		params: {
			file: f.string().default(""),
			file_id: f.string().default("")
		},
		run: async (p, ctx) => {
			const file = p.file || p.file_id;
			if (!file) return failedResponse(RETCODE.BAD_REQUEST, "file is required");
			const info = await ctx.getRecordInfo(file);
			if (info) return okResponse(info);
			return failedResponse(RETCODE.ACTION_FAILED, "record not found in cache");
		}
	}),
	defineAction({
		name: [
			"fetch_ptt_text",
			"get_ptt_text",
			"get_record_text"
		],
		summary: "获取语音转文字结果",
		readOnly: true,
		returns: "{ text }：语音识别出的文本。",
		returnsSchema: {
			type: "object",
			properties: { text: {
				type: "string",
				description: "语音转写文本"
			} },
			required: ["text"]
		},
		params: { message_id: f.string().default("") },
		run: async (_p, ctx, raw) => {
			const messageId = asNumber(raw.message_id);
			if (!messageId) return failedResponse(RETCODE.BAD_REQUEST, "message_id is required");
			try {
				return okResponse(await ctx.fetchPttText(messageId));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : "获取语音转文字结果失败");
			}
		}
	}),
	defineAction({
		name: "get_cookies",
		summary: "获取 Cookies",
		readOnly: true,
		returns: "{ cookies }：指定域名的 Cookie 字符串。",
		returnsSchema: {
			type: "object",
			properties: { cookies: {
				type: "string",
				description: "该域名的 Cookie 字符串"
			} },
			required: ["cookies"]
		},
		params: { domain: f.string().default("qun.qq.com") },
		run: async (p, ctx) => {
			try {
				return okResponse({ cookies: await ctx.bridge.apis.web.getCookiesStr(p.domain || "qun.qq.com") });
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_csrf_token",
		summary: "获取 CSRF 令牌",
		readOnly: true,
		returns: "{ token }：CSRF 令牌（bkn，数值）。",
		returnsSchema: {
			type: "object",
			properties: { token: {
				type: "integer",
				description: "CSRF 令牌（bkn）"
			} },
			required: ["token"]
		},
		params: {},
		run: async (_p, ctx) => {
			try {
				return okResponse({ token: await ctx.bridge.apis.web.getCsrfToken() });
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_credentials",
		summary: "获取凭证",
		readOnly: true,
		returns: "{ cookies, token, csrf_token }：Cookie 字符串与 CSRF 令牌（token 与 csrf_token 同值）。",
		returnsSchema: {
			type: "object",
			properties: {
				cookies: {
					type: "string",
					description: "该域名的 Cookie 字符串"
				},
				token: {
					type: "integer",
					description: "CSRF 令牌（bkn）"
				},
				csrf_token: {
					type: "integer",
					description: "CSRF 令牌（同 token）"
				}
			},
			required: [
				"cookies",
				"token",
				"csrf_token"
			]
		},
		params: { domain: f.string().default("qun.qq.com") },
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.web.getCredentials(p.domain || "qun.qq.com"));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "set_restart",
		summary: "重启（不支持）",
		params: {},
		run: async () => {
			return failedResponse(RETCODE.ACTION_FAILED, "not supported");
		}
	}),
	defineAction({
		name: "clean_cache",
		summary: "清理缓存",
		params: {},
		run: async () => {
			return okResponse();
		}
	}),
	defineAction({
		name: "set_friend_remark",
		summary: "设置好友备注",
		params: {
			user_id: f.uint(),
			remark: f.string()
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.friend.setRemark(p.user_id, p.remark);
			return okResponse();
		}
	}),
	defineAction({
		name: "set_group_remark",
		summary: "设置群备注",
		params: {
			group_id: f.uint(),
			remark: f.string()
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.setRemark(p.group_id, p.remark);
			return okResponse();
		}
	}),
	defineAction({
		name: "set_msg_emoji_like",
		summary: "设置消息表情回应",
		params: {
			message_id: f.messageId(),
			emoji_id: f.string({ allowEmpty: false }),
			set: f.bool().default(true)
		},
		run: async (p, ctx) => {
			await ctx.setMsgEmojiLike(p.message_id, p.emoji_id, p.set);
			return okResponse();
		}
	}),
	defineAction({
		name: "_mark_all_as_read",
		summary: "标记全部已读（no-op，待 RE 全读 cmd）",
		params: {},
		run: async () => {
			return okResponse();
		}
	}),
	groupAction({
		name: "get_group_file_system_info",
		summary: "获取群文件系统信息",
		readOnly: true,
		returns: "{ file_count, limit_count, used_space, total_space }：群文件数量与容量信息（used_space 恒 0，total_space 为固定 10GiB 常量）。",
		returnsSchema: {
			type: "object",
			properties: {
				file_count: {
					type: "integer",
					description: "当前文件数"
				},
				limit_count: {
					type: "integer",
					description: "最大文件数"
				},
				used_space: {
					type: "integer",
					description: "已用空间（占位，恒 0）"
				},
				total_space: {
					type: "integer",
					description: "总空间（占位，恒 10GiB）"
				}
			},
			required: [
				"file_count",
				"limit_count",
				"used_space",
				"total_space"
			]
		},
		run: async (p, ctx) => {
			const info = await ctx.bridge.apis.groupFile.getCount(p.group_id);
			return okResponse({
				file_count: info.fileCount,
				limit_count: info.maxCount,
				used_space: 0,
				total_space: 10737418240
			});
		}
	}),
	defineAction({
		name: "check_url_safely",
		summary: "检查链接安全性",
		readOnly: true,
		returns: "{ level }：安全等级（占位实现，恒为 1）。",
		returnsSchema: {
			type: "object",
			properties: { level: {
				type: "integer",
				description: "安全等级（占位，恒 1）"
			} },
			required: ["level"]
		},
		params: {},
		run: async () => {
			return okResponse({ level: 1 });
		}
	}),
	defineAction({
		name: "set_qq_profile",
		summary: "设置 QQ 资料",
		params: {
			nickname: f.string().optional(),
			personal_note: f.string().optional()
		},
		run: async (p, ctx) => {
			const nickname = p.nickname;
			const personalNote = p.personal_note;
			try {
				await ctx.bridge.apis.profile.setProfile(nickname, personalNote);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "set_online_status",
		summary: "设置在线状态",
		params: {
			status: f.int({ nonZero: true }),
			ext_status: f.int({ min: 0 }).default(0),
			battery_status: f.int({ min: 0 }).default(100)
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.profile.setOnlineStatus(p.status, p.ext_status, p.battery_status);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "set_diy_online_status",
		summary: "设置自定义在线状态",
		params: {
			face_id: f.uint(),
			face_type: f.int({ min: 0 }).default(1),
			wording: f.string().default("")
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.profile.setDiyOnlineStatus(p.face_id, p.wording, p.face_type);
				return okResponse();
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	defineAction({
		name: "get_group_ignored_notifies",
		summary: "获取被过滤的入群请求",
		readOnly: true,
		returns: "被过滤的入群请求数组，每项含群号、申请人、邀请人、留言与处理标记。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: {
					group_id: {
						type: "integer",
						description: "群号"
					},
					group_name: {
						type: "string",
						description: "群名称"
					},
					request_id: {
						type: "integer",
						description: "请求序列号"
					},
					requester_uin: {
						type: "integer",
						description: "申请人 QQ 号"
					},
					requester_nick: {
						type: "string",
						description: "申请人昵称"
					},
					message: {
						type: "string",
						description: "验证留言"
					},
					checked: {
						type: "boolean",
						description: "是否已处理"
					},
					actor: {
						type: "integer",
						description: "处理人 QQ 号"
					},
					invitor_uin: {
						type: "integer",
						description: "邀请人 QQ 号"
					},
					invitor_nick: {
						type: "string",
						description: "邀请人昵称"
					},
					flag: {
						type: "string",
						description: "处理用 flag（eventType:groupId:targetUid:filtered）"
					}
				},
				required: [
					"group_id",
					"group_name",
					"request_id",
					"requester_uin",
					"requester_nick",
					"message",
					"checked",
					"actor",
					"invitor_uin",
					"invitor_nick",
					"flag"
				]
			}
		},
		params: {},
		run: async (_p, ctx) => {
			return okResponse((await fetchFilteredGroupRequests(ctx)).map((r) => ({
				group_id: r.groupId,
				group_name: r.groupName,
				request_id: r.sequence,
				requester_uin: r.targetUin,
				requester_nick: r.targetName,
				message: r.comment,
				checked: r.state !== 1,
				actor: r.operatorUin,
				invitor_uin: r.invitorUin,
				invitor_nick: r.invitorName,
				flag: `${r.eventType}:${r.groupId}:${r.targetUid}:filtered`
			})));
		}
	}),
	defineAction({
		name: "get_group_ignore_add_request",
		summary: "获取被忽略的入群请求（NapCat）",
		readOnly: true,
		returns: "被忽略的入群请求数组（NapCat 字段命名），每项含请求序列、邀请人、群信息与处理标记。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: {
					request_id: {
						type: "integer",
						description: "请求序列号"
					},
					invitor_uin: {
						type: "integer",
						description: "邀请人 QQ 号"
					},
					invitor_nick: {
						type: "string",
						description: "邀请人昵称"
					},
					group_id: {
						type: "integer",
						description: "群号"
					},
					message: {
						type: "string",
						description: "验证留言"
					},
					group_name: {
						type: "string",
						description: "群名称"
					},
					checked: {
						type: "boolean",
						description: "是否已处理"
					},
					actor: {
						type: "integer",
						description: "处理人 QQ 号"
					},
					requester_nick: {
						type: "string",
						description: "申请人昵称"
					}
				},
				required: [
					"request_id",
					"invitor_uin",
					"invitor_nick",
					"group_id",
					"message",
					"group_name",
					"checked",
					"actor",
					"requester_nick"
				]
			}
		},
		params: {},
		run: async (_p, ctx) => {
			return okResponse((await fetchFilteredGroupRequests(ctx)).map((r) => ({
				request_id: r.sequence,
				invitor_uin: r.invitorUin,
				invitor_nick: r.invitorName,
				group_id: r.groupId,
				message: r.comment,
				group_name: r.groupName,
				checked: r.state !== 1,
				actor: r.operatorUin,
				requester_nick: r.targetName
			})));
		}
	}),
	groupAction({
		name: "get_group_shut_list",
		summary: "获取群禁言列表",
		readOnly: true,
		returns: "仍在禁言中的成员数组，每项含 QQ 号、昵称与禁言到期时间戳（秒）。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: {
					user_id: {
						type: "integer",
						description: "成员 QQ 号"
					},
					nickname: {
						type: "string",
						description: "成员昵称"
					},
					shut_up_time: {
						type: "integer",
						description: "禁言到期时间戳（秒）"
					}
				},
				required: [
					"user_id",
					"nickname",
					"shut_up_time"
				]
			}
		},
		run: async (p, ctx) => {
			const members = await ctx.bridge.apis.contacts.fetchGroupMemberList(p.group_id);
			const nowSec = Math.floor(Date.now() / 1e3);
			return okResponse(members.filter((m) => (m.shutUpTime ?? 0) > nowSec).map((m) => ({
				user_id: m.uin,
				nickname: m.nickname,
				shut_up_time: m.shutUpTime
			})));
		}
	}),
	groupAction({
		name: "get_group_signed_list",
		summary: "获取群今日打卡列表",
		readOnly: true,
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.web.getSignedList(p.group_id));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	}),
	defineAction({
		name: "forward_friend_single_msg",
		summary: "转发单条消息给好友",
		params: {
			message_id: f.messageId(),
			user_id: f.uint()
		},
		run: async (p, ctx) => {
			try {
				return okResponse({ message_id: (await ctx.forwardSingleMsg(p.message_id, { userId: p.user_id })).messageId });
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	defineAction({
		name: "forward_group_single_msg",
		summary: "转发单条消息到群",
		params: {
			message_id: f.messageId(),
			group_id: f.uint()
		},
		run: async (p, ctx) => {
			try {
				return okResponse({ message_id: (await ctx.forwardSingleMsg(p.message_id, { groupId: p.group_id })).messageId });
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	defineAction({
		name: "get_profile_like",
		summary: "获取资料点赞",
		readOnly: true,
		returns: "点赞资料：uid、最近点赞时间、收藏（favoriteInfo）与点赞（voteInfo）统计。",
		returnsSchema: {
			type: "object",
			properties: {
				uid: {
					type: "string",
					description: "用户 uid"
				},
				time: {
					type: "integer",
					description: "最近点赞时间戳"
				},
				favoriteInfo: {
					type: "object",
					description: "收藏统计",
					properties: {
						total_count: {
							type: "integer",
							description: "收藏总数"
						},
						last_time: {
							type: "integer",
							description: "最近收藏时间戳"
						},
						today_count: {
							type: "integer",
							description: "今日收藏数"
						},
						userInfos: {
							type: "array",
							description: "用户列表（恒空）"
						}
					}
				},
				voteInfo: {
					type: "object",
					description: "点赞统计",
					properties: {
						total_count: {
							type: "integer",
							description: "点赞总数"
						},
						new_count: {
							type: "integer",
							description: "新增点赞数"
						},
						new_nearby_count: {
							type: "integer",
							description: "附近的人新增点赞数"
						},
						last_visit_time: {
							type: "integer",
							description: "最近访问时间戳"
						},
						userInfos: {
							type: "array",
							description: "用户列表（恒空）"
						}
					}
				}
			},
			required: [
				"uid",
				"time",
				"favoriteInfo",
				"voteInfo"
			]
		},
		params: {
			user_id: f.int({ min: 0 }).default(0),
			start: f.int({ min: 0 }).default(0),
			count: f.int({ min: 0 }).default(10)
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.profile.getLike(p.user_id, p.start, p.count));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "fetch_custom_face",
		summary: "获取自定义表情",
		readOnly: true,
		returns: "字符串数组：return_type=url 时为图片 URL，return_type=id 时为 emoji_id。",
		returnsSchema: {
			type: "array",
			items: {
				type: "string",
				description: "图片 URL 或 emoji_id（取决于 return_type）"
			}
		},
		params: {
			count: f.int({ min: 0 }).default(10),
			return_type: f.string().default("url")
		},
		run: async (p, ctx) => {
			try {
				const urls = await ctx.bridge.apis.profile.fetchCustomFace(p.count);
				if (p.return_type === "id") return okResponse(urls.map((url) => {
					const m = /\/qq_expression\/[^/]+\/([^/]+)\//.exec(url);
					return m ? m[1] : "";
				}).filter(Boolean));
				return okResponse(urls);
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_emoji_likes",
		summary: "获取表情回应用户",
		readOnly: true,
		returns: "{ emoji_like_list }：回应该表情的用户列表（nick_name 恒为空串）。",
		returnsSchema: {
			type: "object",
			properties: { emoji_like_list: {
				type: "array",
				description: "回应用户列表",
				items: {
					type: "object",
					properties: {
						user_id: {
							type: "string",
							description: "用户 QQ 号（字符串）"
						},
						nick_name: {
							type: "string",
							description: "昵称（当前实现恒为空串）"
						}
					},
					required: ["user_id", "nick_name"]
				}
			} },
			required: ["emoji_like_list"]
		},
		params: {
			message_id: f.messageId(),
			emoji_id: f.string({ allowEmpty: false })
		},
		run: async (p, ctx) => {
			try {
				return okResponse({ emoji_like_list: (await ctx.fetchEmojiLikeUsers(p.message_id, p.emoji_id, 1e3)).users.map((u) => ({
					user_id: String(u.uin),
					nick_name: ""
				})) });
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "fetch_emoji_like",
		summary: "获取表情回应用户（NapCat 分页）",
		readOnly: true,
		returns: "分页的表情回应用户列表（NapCat 形状），含分页游标 cookie 与首/末页标记。",
		returnsSchema: {
			type: "object",
			properties: {
				result: {
					type: "integer",
					description: "结果码（恒 0）"
				},
				errMsg: {
					type: "string",
					description: "错误信息（恒空串）"
				},
				emojiLikesList: {
					type: "array",
					description: "回应用户列表",
					items: {
						type: "object",
						properties: {
							tinyId: {
								type: "string",
								description: "用户 QQ 号（字符串）"
							},
							nickName: {
								type: "string",
								description: "昵称（恒空串）"
							},
							headUrl: {
								type: "string",
								description: "头像 URL（恒空串）"
							}
						},
						required: [
							"tinyId",
							"nickName",
							"headUrl"
						]
					}
				},
				cookie: {
					type: "string",
					description: "下一页游标（末页为空串）"
				},
				isLastPage: {
					type: "boolean",
					description: "是否末页"
				},
				isFirstPage: {
					type: "boolean",
					description: "是否首页"
				}
			},
			required: [
				"result",
				"errMsg",
				"emojiLikesList",
				"cookie",
				"isLastPage",
				"isFirstPage"
			]
		},
		params: {
			message_id: f.messageId(),
			emojiId: f.string({ allowEmpty: false }),
			count: f.int({ min: 0 }).default(10),
			cookie: f.string().default("")
		},
		run: async (p, ctx) => {
			try {
				const offset = p.cookie ? Number.parseInt(p.cookie, 10) || 0 : 0;
				const result = await ctx.fetchEmojiLikeUsers(p.message_id, p.emojiId, p.count, offset);
				const nextOffset = offset + result.users.length;
				const isLastPage = nextOffset >= result.cachedCount;
				return okResponse({
					result: 0,
					errMsg: "",
					emojiLikesList: result.users.map((u) => ({
						tinyId: String(u.uin),
						nickName: "",
						headUrl: ""
					})),
					cookie: isLastPage ? "" : String(nextOffset),
					isLastPage,
					isFirstPage: offset === 0
				});
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_friends_with_category",
		summary: "获取分组好友列表",
		readOnly: true,
		params: {},
		run: async (_p, ctx) => {
			if (ctx.getFriendList) return okResponse(await ctx.getFriendList());
			return okResponse([]);
		}
	}),
	defineAction({
		name: "get_recent_contact",
		summary: "获取最近会话（占位）",
		readOnly: true,
		returns: "占位实现，恒返回空数组。",
		returnsSchema: {
			type: "array",
			description: "最近会话列表（占位，恒空）"
		},
		params: { count: f.int({ min: 0 }).default(10) },
		run: async () => {
			return okResponse([]);
		}
	}),
	defineAction({
		name: "get_online_clients",
		summary: "获取在线客户端（占位，OneBot v11 形状）",
		readOnly: true,
		returns: "{ clients }：在线设备列表（占位，clients 恒为空数组）。",
		returnsSchema: {
			type: "object",
			properties: { clients: {
				type: "array",
				description: "在线设备列表（占位，恒空）"
			} },
			required: ["clients"]
		},
		params: {},
		run: async () => {
			return okResponse({ clients: [] });
		}
	}),
	defineAction({
		name: "_get_model_show",
		summary: "获取机型展示（兼容 mock）",
		readOnly: true,
		returns: "数组，每项含 variants（回显请求的机型名与 need_pay 标记）。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: { variants: {
					type: "object",
					properties: {
						model_show: {
							type: "string",
							description: "机型展示名（回显请求的 model，缺省 snowluma）"
						},
						need_pay: {
							type: "boolean",
							description: "是否需付费（恒 false）"
						}
					},
					required: ["model_show", "need_pay"]
				} },
				required: ["variants"]
			}
		},
		params: { model: f.string().default("") },
		run: async (p) => {
			return okResponse([{ variants: {
				model_show: p.model || "snowluma",
				need_pay: false
			} }]);
		}
	}),
	defineAction({
		name: "_set_model_show",
		summary: "设置机型展示（占位）",
		params: {},
		run: async () => {
			return okResponse();
		}
	}),
	groupAction({
		name: "get_group_at_all_remain",
		summary: "获取群 @全体成员 剩余次数",
		readOnly: true,
		returns: "{ can_at_all, remain_at_all_count_for_group, remain_at_all_count_for_uin }：@全体可用性与剩余次数。",
		returnsSchema: {
			type: "object",
			properties: {
				can_at_all: {
					type: "boolean",
					description: "当前是否可 @全体成员"
				},
				remain_at_all_count_for_group: {
					type: "integer",
					description: "本群今日剩余 @全体次数"
				},
				remain_at_all_count_for_uin: {
					type: "integer",
					description: "本账号今日剩余 @全体次数"
				}
			},
			required: [
				"can_at_all",
				"remain_at_all_count_for_group",
				"remain_at_all_count_for_uin"
			]
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.groupAdmin.getAtAllRemain(p.group_id));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_unidirectional_friend_list",
		summary: "获取单向好友列表",
		readOnly: true,
		params: {},
		run: async (_p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.profile.getUnidirectionalFriendList());
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_clientkey",
		summary: "获取 clientkey",
		readOnly: true,
		returns: "{ clientKey, expireTime, keyIndex }：clientkey 及其过期时间与索引。",
		returnsSchema: {
			type: "object",
			properties: {
				clientKey: {
					type: "string",
					description: "clientkey"
				},
				expireTime: {
					type: "string",
					description: "过期时间"
				},
				keyIndex: {
					type: "string",
					description: "key 索引"
				}
			},
			required: [
				"clientKey",
				"expireTime",
				"keyIndex"
			]
		},
		params: {},
		run: async (_p, ctx) => {
			const clientKeyInfo = await ctx.bridge.apis.web.forceFetchClientKey();
			if (!clientKeyInfo.clientKey) return failedResponse(RETCODE.ACTION_FAILED, "get clientkey error");
			return okResponse({ ...clientKeyInfo });
		}
	}),
	defineAction({
		name: "share_peer",
		summary: "分享用户/群 Ark 卡片",
		readOnly: true,
		returns: "{ arkMsg }：服务端生成的推荐联系人 Ark 卡片 JSON 字符串。",
		returnsSchema: {
			type: "object",
			properties: { arkMsg: {
				type: "string",
				description: "Ark 卡片 JSON 字符串"
			} },
			required: ["arkMsg"]
		},
		params: {
			user_id: f.uint().optional(),
			group_id: f.uint().optional(),
			phone_number: f.string().default("")
		},
		run: async (p, ctx) => {
			try {
				if (p.group_id) return okResponse({ arkMsg: await ctx.bridge.apis.contacts.getGroupRecommendArk(p.group_id) });
				if (p.user_id) return okResponse({ arkMsg: await ctx.bridge.apis.contacts.getBuddyRecommendArk(p.user_id, p.phone_number) });
				return failedResponse(RETCODE.BAD_REQUEST, "user_id or group_id is required");
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	}),
	defineAction({
		name: "send_ark_share",
		summary: "分享用户/群 Ark 卡片（NapCat 标准名）",
		readOnly: true,
		returns: "{ arkMsg }：服务端生成的推荐联系人 Ark 卡片 JSON 字符串。",
		returnsSchema: {
			type: "object",
			properties: { arkMsg: {
				type: "string",
				description: "Ark 卡片 JSON 字符串"
			} },
			required: ["arkMsg"]
		},
		params: {
			user_id: f.uint().optional(),
			group_id: f.uint().optional(),
			phone_number: f.string().default("")
		},
		run: async (p, ctx) => {
			try {
				if (p.group_id) return okResponse({ arkMsg: await ctx.bridge.apis.contacts.getGroupRecommendArk(p.group_id) });
				if (p.user_id) return okResponse({ arkMsg: await ctx.bridge.apis.contacts.getBuddyRecommendArk(p.user_id, p.phone_number) });
				return failedResponse(RETCODE.BAD_REQUEST, "user_id or group_id is required");
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	}),
	defineAction({
		name: "share_group_ex",
		summary: "分享群 Ark 卡片",
		readOnly: true,
		returns: "服务端生成的群推荐 Ark 卡片 JSON 字符串。",
		returnsSchema: {
			type: "string",
			description: "群 Ark 卡片 JSON 字符串"
		},
		params: { group_id: f.uint() },
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.contacts.getGroupRecommendArk(p.group_id));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	}),
	defineAction({
		name: "send_group_ark_share",
		summary: "分享群 Ark 卡片（NapCat 标准名）",
		readOnly: true,
		returns: "服务端生成的群推荐 Ark 卡片 JSON 字符串。",
		returnsSchema: {
			type: "string",
			description: "群 Ark 卡片 JSON 字符串"
		},
		params: { group_id: f.uint() },
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.contacts.getGroupRecommendArk(p.group_id));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	}),
	defineAction({
		name: "get_doubt_friends_add_request",
		summary: "获取可疑好友申请",
		readOnly: true,
		returns: "可疑好友申请数组，每项含 uid（作为处理用 flag）、昵称、来源、留言与申请时间。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: {
					uid: {
						type: "string",
						description: "申请人 uid（回传作 set_doubt_friends_add_request 的 flag）"
					},
					nick: {
						type: "string",
						description: "申请人昵称"
					},
					source: {
						type: "string",
						description: "申请来源"
					},
					msg: {
						type: "string",
						description: "验证留言"
					},
					reqTime: {
						type: "integer",
						description: "申请时间戳"
					}
				},
				required: [
					"uid",
					"nick",
					"source",
					"msg",
					"reqTime"
				]
			}
		},
		params: { count: f.int({ min: 0 }).default(50) },
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.friend.getDoubtRequests(p.count));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	}),
	defineAction({
		name: "set_doubt_friends_add_request",
		summary: "处理可疑好友申请",
		params: {
			flag: f.string({ allowEmpty: false }),
			approve: f.bool().default(true)
		},
		run: async (p, ctx) => {
			try {
				if (p.approve) await ctx.bridge.apis.friend.approveDoubtRequest(p.flag);
				else await ctx.bridge.apis.friend.rejectDoubtRequest(p.flag);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	}),
	groupAction({
		name: "set_group_robot_add_option",
		summary: "设置群机器人加群选项",
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.groupAdmin.setRobotAddOption(p.group_id, p.robot_member_switch, p.robot_member_examine);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		},
		params: {
			robot_member_switch: f.int({ min: 0 }).optional(),
			robot_member_examine: f.int({ min: 0 }).optional()
		}
	}),
	defineAction({
		name: "get_collection_list",
		summary: "获取收藏列表（占位）",
		readOnly: true,
		returns: "占位实现，恒返回空数组。",
		returnsSchema: {
			type: "array",
			description: "收藏列表（占位，恒空）"
		},
		params: {},
		run: async () => {
			return okResponse([]);
		}
	}),
	defineAction({
		name: "create_collection",
		summary: "创建收藏（未实现）",
		params: {},
		run: async () => {
			return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
		}
	}),
	defineAction({
		name: ".get_word_slices",
		summary: "分词（未实现）",
		readOnly: true,
		params: {},
		run: async () => {
			return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
		}
	}),
	defineAction({
		name: "set_qq_avatar",
		summary: "设置 QQ 头像",
		params: { file: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.profile.setAvatar(p.file);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "set_input_status",
		summary: "设置输入状态",
		params: {
			user_id: f.uint(),
			event_type: f.int().default(0)
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.profile.setInputStatus(p.user_id, p.event_type);
				return okResponse({});
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_group_info_ex",
		summary: "获取群信息（扩展）",
		readOnly: true,
		params: { group_id: f.uint() },
		run: async (p, ctx) => {
			if (ctx.getGroupInfo) return okResponse(await ctx.getGroupInfo(p.group_id));
			return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		}
	}),
	defineAction({
		name: "get_group_detail_info",
		summary: "获取群详细信息",
		readOnly: true,
		params: { group_id: f.uint() },
		run: async (p, ctx) => {
			if (ctx.getGroupInfo) return okResponse(await ctx.getGroupInfo(p.group_id));
			return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
		}
	}),
	defineAction({
		name: "trans_group_file",
		summary: "转存群文件（未实现）",
		params: {},
		run: async () => {
			return failedResponse(RETCODE.ACTION_FAILED, "not yet implemented");
		}
	}),
	defineAction({
		name: "get_file",
		summary: "获取文件信息（仅图片/语音缓存；群文件请用 get_group_file_url）",
		readOnly: true,
		params: {
			file_id: f.string().default(""),
			file: f.string().default("")
		},
		run: async (p, ctx) => {
			const fileId = p.file || p.file_id;
			if (!fileId) return failedResponse(RETCODE.BAD_REQUEST, "file_id is required");
			const image = await ctx.getImageInfo(fileId);
			if (image) return okResponse(image);
			const record = await ctx.getRecordInfo(fileId);
			if (record) return okResponse(record);
			return failedResponse(RETCODE.ACTION_FAILED, "file_id not found in the image/voice cache. get_file only resolves cached image/voice ids; for group/normal files use get_group_file_url or get_private_file_url");
		}
	}),
	defineAction({
		name: "bot_exit",
		summary: "退出机器人",
		params: {},
		run: async () => {
			setTimeout(() => process.exit(0), 50);
			return okResponse();
		}
	}),
	defineAction({
		name: "nc_get_packet_status",
		summary: "获取 packet 状态（占位）",
		readOnly: true,
		returns: "占位实现，恒返回 null。",
		returnsSchema: {
			type: "null",
			description: "packet 状态（占位，恒 null）"
		},
		params: {},
		run: async () => {
			return okResponse(null);
		}
	}),
	groupAction({
		name: "delete_group_folder",
		summary: "删除群文件夹",
		params: { folder_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupFile.deleteFolder(p.group_id, p.folder_id);
			return okResponse();
		}
	}),
	defineAction({
		name: "nc_get_user_status",
		summary: "获取用户在线/扩展状态",
		readOnly: true,
		returns: "{ status, ext_status }：用户在线状态码与扩展状态码。",
		returnsSchema: {
			type: "object",
			properties: {
				status: {
					type: "integer",
					description: "在线状态码"
				},
				ext_status: {
					type: "integer",
					description: "扩展状态码"
				}
			},
			required: ["status", "ext_status"]
		},
		params: { user_id: f.uint() },
		run: async (p, ctx) => {
			const status = await ctx.bridge.apis.extras.getStrangerStatus(p.user_id);
			if (!status) return failedResponse(RETCODE.ACTION_FAILED, "failed to fetch user status");
			return okResponse({ ...status });
		}
	}),
	groupAction({
		name: "get_ai_characters",
		summary: "获取 AI 语音角色",
		readOnly: true,
		returns: "按分类分组的 AI 语音角色列表，每组含分类名与角色（id、名称、试听 URL）。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: {
					type: {
						type: "string",
						description: "角色分类名"
					},
					characters: {
						type: "array",
						description: "该分类下的角色列表",
						items: {
							type: "object",
							properties: {
								character_id: {
									type: "string",
									description: "角色 ID"
								},
								character_name: {
									type: "string",
									description: "角色显示名"
								},
								preview_url: {
									type: "string",
									description: "试听音频 URL"
								}
							},
							required: [
								"character_id",
								"character_name",
								"preview_url"
							]
						}
					}
				},
				required: ["type", "characters"]
			}
		},
		params: { chat_type: f.int({ min: 0 }).default(1) },
		run: async (p, ctx) => {
			try {
				return okResponse((await ctx.bridge.apis.extras.fetchAiVoiceList(p.group_id, p.chat_type)).map((cat) => ({
					type: cat.category,
					characters: cat.voices.map((v) => ({
						character_id: v.voiceId,
						character_name: v.voiceDisplayName,
						preview_url: v.voiceExampleUrl
					}))
				})));
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	groupAction({
		name: "get_ai_record",
		summary: "生成 AI 语音",
		params: {
			character: f.string({ allowEmpty: false }),
			text: f.string({ allowEmpty: false }),
			chat_type: f.int({ min: 0 }).default(1)
		},
		run: async (p, ctx) => {
			try {
				const node = await ctx.bridge.apis.extras.fetchAiVoice(p.group_id, p.character, p.text, p.chat_type);
				return okResponse(await ctx.bridge.apis.groupFile.getPttUrl(p.group_id, node));
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	groupAction({
		name: "send_group_ai_record",
		summary: "发送 AI 语音到群",
		params: {
			character: f.string({ allowEmpty: false }),
			text: f.string({ allowEmpty: false }),
			chat_type: f.int({ min: 0 }).default(1)
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.extras.fetchAiVoice(p.group_id, p.character, p.text, p.chat_type);
				return okResponse({ message_id: 0 });
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	defineAction({
		name: "request_decrypt_key",
		summary: "请求数据库解密密钥",
		params: { db_path: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				const buffer = Buffer.alloc(128);
				const fileHandle = await readFile(p.db_path);
				if (fileHandle.length < 175) return failedResponse(RETCODE.ACTION_FAILED, "Database file too short");
				fileHandle.copy(buffer, 0, 47, 175);
				const dbSalt = buffer.toString("utf8");
				if (!/^[0-9a-fA-F]{128}$/.test(dbSalt)) return failedResponse(RETCODE.ACTION_FAILED, "Invalid db_salt: not a valid 128-character hex string");
				return okResponse({ db_key: await ctx.bridge.apis.misc.getDecryptKey(dbSalt.toLowerCase()) });
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	defineAction({
		name: ["get_rkey", "nc_get_rkey"],
		summary: "获取下载 rkey",
		readOnly: true,
		params: {},
		run: async (_p, ctx) => ctx.getDownloadRKeys ? okResponse(await ctx.getDownloadRKeys()) : failedResponse(RETCODE.ACTION_FAILED, "not implemented")
	}),
	defineAction({
		name: "get_rkey_server",
		summary: "获取 rkey 服务器信息",
		readOnly: true,
		returns: "{ expired_time, name, private_rkey?, group_rkey? }：rkey 过期时间与（存在时的）私聊/群聊 rkey。",
		returnsSchema: {
			type: "object",
			properties: {
				expired_time: {
					type: "integer",
					description: "过期时间戳（秒）"
				},
				name: {
					type: "string",
					description: "服务器名（恒 SnowLuma）"
				},
				private_rkey: {
					type: "string",
					description: "私聊 rkey（存在时返回）"
				},
				group_rkey: {
					type: "string",
					description: "群聊 rkey（存在时返回）"
				}
			},
			required: ["expired_time", "name"]
		},
		params: {},
		run: async (_p, ctx) => {
			if (!ctx.getDownloadRKeys) return failedResponse(RETCODE.ACTION_FAILED, "not implemented");
			const rkeys = await ctx.getDownloadRKeys();
			const pick = (type) => rkeys.find((r) => r.type === type);
			const priv = pick(10);
			const group = pick(20);
			if (!priv?.rkey && !group?.rkey) return failedResponse(RETCODE.ACTION_FAILED, "no download rkey available");
			const ttls = [priv?.ttl, group?.ttl].filter((t) => typeof t === "number" && t > 0);
			const minTtl = ttls.length ? Math.min(...ttls) : 0;
			const data = {
				expired_time: Math.floor(Date.now() / 1e3) + minTtl,
				name: "SnowLuma"
			};
			if (priv?.rkey) data.private_rkey = priv.rkey;
			if (group?.rkey) data.group_rkey = group.rkey;
			return okResponse(data);
		}
	}),
	defineAction({
		name: ["ocr_image", ".ocr_image"],
		summary: "OCR 图片（服务端，需图片 URL 或已缓存的图片 file_id）",
		readOnly: true,
		returns: "{ texts, language }：识别文本数组（含置信度与坐标）与识别语言。",
		returnsSchema: {
			type: "object",
			properties: {
				texts: {
					type: "array",
					description: "识别出的文本块",
					items: {
						type: "object",
						properties: {
							text: {
								type: "string",
								description: "文本内容"
							},
							confidence: {
								type: "number",
								description: "置信度"
							},
							coordinates: {
								type: "array",
								description: "文本框顶点坐标",
								items: {
									type: "object",
									properties: {
										x: {
											type: "number",
											description: "X 坐标"
										},
										y: {
											type: "number",
											description: "Y 坐标"
										}
									},
									required: ["x", "y"]
								}
							}
						},
						required: [
							"text",
							"confidence",
							"coordinates"
						]
					}
				},
				language: {
					type: "string",
					description: "识别语言"
				}
			},
			required: ["texts", "language"]
		},
		params: { image: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			let url = /^https?:\/\//i.test(p.image) ? p.image : "";
			if (!url) {
				const info = await ctx.getImageInfo(p.image);
				const resolved = info && typeof info.url === "string" ? info.url : "";
				if (resolved) url = resolved;
			}
			if (!url) return failedResponse(RETCODE.ACTION_FAILED, "ocr_image needs an http(s) image url or a cached image file_id; base64/local-file input is not supported");
			return okResponse(await ctx.bridge.apis.misc.ocrImage(url));
		}
	}),
	groupAction({
		name: "_del_group_notice",
		summary: "删除群公告（fid 或 notice_id 二选一）",
		params: {
			fid: f.string().optional(),
			notice_id: f.string().optional()
		},
		run: async (p, ctx) => {
			const fid = p.fid || p.notice_id;
			if (!fid) return failedResponse(RETCODE.BAD_REQUEST, "group_id and fid/notice_id are required");
			try {
				return await ctx.bridge.apis.web.deleteNotice(p.group_id, fid) ? okResponse() : failedResponse(RETCODE.ACTION_FAILED, "delete failed");
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "send_forward_msg",
		summary: "发送合并转发（按 message_type/群号自动路由）",
		returns: "{ message_id, res_id, forward_id }",
		params: {
			messages: f.message().optional(),
			message: f.message().optional()
		},
		run: async (p, ctx, raw) => {
			const messageType = asString(raw.message_type);
			const groupId = asNumber(raw.group_id);
			const userId = asNumber(raw.user_id);
			const messages = p.messages ?? p.message;
			const meta = readForwardPreviewMeta(raw);
			if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
			if ((messageType === "group" || groupId > 0) && ctx.sendGroupForwardMsg) {
				if (!groupId) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
				const result = await ctx.sendGroupForwardMsg(groupId, messages, meta);
				return okResponse({
					message_id: result.messageId,
					res_id: result.forwardId,
					forward_id: result.forwardId
				});
			}
			if ((messageType === "private" || userId > 0) && ctx.sendPrivateForwardMsg) {
				if (!userId) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
				const result = await ctx.sendPrivateForwardMsg(userId, messages, meta);
				return okResponse({
					message_id: result.messageId,
					res_id: result.forwardId,
					forward_id: result.forwardId
				});
			}
			const result = await ctx.sendForwardMsg(messages);
			return okResponse({
				message_id: 0,
				res_id: result.forwardId,
				forward_id: result.forwardId
			});
		}
	}),
	groupAction({
		name: "send_group_forward_msg",
		summary: "发送群合并转发",
		returns: "{ message_id, res_id, forward_id }",
		params: {
			messages: f.message().optional(),
			message: f.message().optional()
		},
		run: async (p, ctx, raw) => {
			const messages = p.messages ?? p.message;
			if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
			const result = await ctx.sendGroupForwardMsg(p.group_id, messages, readForwardPreviewMeta(raw));
			return okResponse({
				message_id: result.messageId,
				res_id: result.forwardId,
				forward_id: result.forwardId
			});
		}
	}),
	defineAction({
		name: "send_private_forward_msg",
		summary: "发送私聊合并转发",
		returns: "{ message_id, res_id, forward_id }",
		params: {
			user_id: f.uint(),
			messages: f.message().optional(),
			message: f.message().optional()
		},
		run: async (p, ctx, raw) => {
			const messages = p.messages ?? p.message;
			if (messages === void 0) return failedResponse(RETCODE.BAD_REQUEST, "message/messages is required");
			const result = await ctx.sendPrivateForwardMsg(p.user_id, messages, readForwardPreviewMeta(raw));
			return okResponse({
				message_id: result.messageId,
				res_id: result.forwardId,
				forward_id: result.forwardId
			});
		}
	}),
	defineAction({
		name: "get_forward_msg",
		summary: "获取合并转发消息（id 或 message_id）",
		readOnly: true,
		returns: "{ messages }：转发内的消息节点数组（每项为 OneBot 消息事件，内部字段不固定）。",
		returnsSchema: {
			type: "object",
			properties: { messages: {
				type: "array",
				description: "转发消息节点数组",
				items: { type: "object" }
			} },
			required: ["messages"]
		},
		params: { id: f.string().optional() },
		run: async (p, ctx, raw) => {
			let id = p.id || "";
			if (!id) {
				const rawMessageId = raw.message_id;
				const numericMessageId = asNumber(rawMessageId);
				if (numericMessageId > 0) {
					const event = ctx.getMessage(numericMessageId);
					const segments = Array.isArray(event?.message) ? event.message : [];
					for (const seg of segments) {
						if (typeof seg !== "object" || seg === null || Array.isArray(seg)) continue;
						const so = seg;
						if (String(so.type ?? "") !== "forward") continue;
						const data = typeof so.data === "object" && so.data !== null && !Array.isArray(so.data) ? so.data : null;
						const candidate = asString(data?.id) || asString(data?.res_id) || asString(data?.forward_id);
						if (candidate) {
							id = candidate;
							break;
						}
					}
				}
				if (!id) id = asString(rawMessageId);
			}
			if (!id) return failedResponse(RETCODE.BAD_REQUEST, "id or message_id is required");
			return okResponse({ messages: await ctx.getForwardMsg(id) });
		}
	}),
	defineAction({
		name: "download_file",
		summary: "下载文件（url 或 base64）到 data/downloads",
		returns: "{ file }",
		params: {
			url: f.string().default(""),
			base64: f.string().default(""),
			name: f.string().default("")
		},
		run: async (p, _ctx, raw) => {
			const url = p.url;
			const base64 = p.base64;
			const name = p.name;
			if (!url && !base64) return failedResponse(RETCODE.BAD_REQUEST, "url or base64 is required");
			let buf;
			if (base64) {
				if (Math.floor(base64.length * 3 / 4) > DOWNLOAD_FILE_MAX_BYTES) return failedResponse(RETCODE.BAD_REQUEST, `base64 payload too large: > ${DOWNLOAD_FILE_MAX_BYTES} bytes`);
				buf = Buffer.from(base64, "base64");
				if (buf.length > DOWNLOAD_FILE_MAX_BYTES) return failedResponse(RETCODE.BAD_REQUEST, `base64 payload too large: ${buf.length} > ${DOWNLOAD_FILE_MAX_BYTES} bytes`);
			} else try {
				buf = await fetchDownloadFile(url, parseDownloadHeaders(raw.headers), DOWNLOAD_FILE_MAX_BYTES, DOWNLOAD_FILE_TIMEOUT_MS);
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
			try {
				return okResponse({ file: await saveDownloadBuffer(buf, name) });
			} catch (err) {
				return failedResponse(RETCODE.BAD_REQUEST, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	defineAction({
		name: "translate_en2zh",
		summary: "英译中",
		readOnly: true,
		returns: "{ words }：与输入等长的中文译文字符串数组。",
		returnsSchema: {
			type: "object",
			properties: { words: {
				type: "array",
				description: "译文数组",
				items: { type: "string" }
			} },
			required: ["words"]
		},
		params: { words: f.raw() },
		run: async (p, ctx) => {
			const rawWords = p.words;
			if (!Array.isArray(rawWords)) return failedResponse(RETCODE.BAD_REQUEST, "invalid words array");
			const words = rawWords.map((w) => String(w));
			try {
				return okResponse({ words: await ctx.bridge.apis.misc.translateEn2Zh(words) });
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "set_self_longnick",
		summary: "设置个性签名（longNick/long_nick，严格 string）",
		params: {
			longNick: f.raw(),
			long_nick: f.raw()
		},
		run: async (p, ctx) => {
			const longNick = p.longNick || p.long_nick;
			if (typeof longNick !== "string") return failedResponse(RETCODE.BAD_REQUEST, "invalid longNick");
			try {
				await ctx.bridge.apis.profile.setSelfLongNick(longNick);
				return okResponse({});
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_mini_app_ark",
		summary: "获取小程序卡片 ark",
		readOnly: true,
		params: {},
		run: async (_p, ctx, raw) => {
			const type = raw.type || "bili";
			const title = raw.title || "";
			const desc = raw.desc || "";
			const picUrl = raw.picUrl || raw.pic_url || "";
			const jumpUrl = raw.jumpUrl || raw.jump_url || "";
			try {
				return okResponse(await ctx.bridge.apis.misc.getMiniAppArk(String(type), String(title), String(desc), String(picUrl), String(jumpUrl)));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	groupAction({
		name: "click_inline_keyboard_button",
		summary: "点击内联键盘按钮",
		params: {
			bot_appid: f.uint(),
			msg_seq: f.uint()
		},
		run: async (p, ctx, raw) => {
			const buttonId = raw.button_id;
			const callbackData = raw.callback_data || "";
			if (!buttonId) return failedResponse(RETCODE.BAD_REQUEST, "missing required parameters");
			try {
				return okResponse(await ctx.bridge.apis.misc.clickInlineKeyboardButton(p.group_id, p.bot_appid, String(buttonId), String(callbackData), p.msg_seq));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	groupAction({
		name: ["set_group_sign", "send_group_sign"],
		summary: "群签到",
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.misc.sendGroupSign(p.group_id);
				return okResponse({});
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: ["send_packet", ".send_packet"],
		summary: "发送原始 SSO 包（cmd + hex data）",
		params: {
			cmd: f.string({ allowEmpty: false }),
			data: f.string().default(""),
			rsp: f.bool().default(true)
		},
		run: async (p, ctx) => {
			if (!/^[0-9a-fA-F]*$/.test(p.data) || p.data.length % 2 !== 0) return failedResponse(RETCODE.BAD_REQUEST, "data must be a hex string of even length");
			try {
				const body = hexToBytes(p.data);
				const result = await ctx.bridge.sendRawPacket(p.cmd, body);
				if (!result.success) return failedResponse(RETCODE.ACTION_FAILED, result.errorMessage || "send failed");
				if (!p.rsp) return okResponse(null);
				return okResponse(result.responseData ? bytesToHex(result.responseData) : "");
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	groupAction({
		name: "set_group_todo",
		summary: "设置群待办",
		params: { message_id: f.messageId() },
		run: (p, ctx) => groupTodoRun(p, ctx, (g, s) => ctx.bridge.apis.extras.setGroupTodo(g, s))
	}),
	groupAction({
		name: "complete_group_todo",
		summary: "完成群待办",
		params: { message_id: f.messageId() },
		run: (p, ctx) => groupTodoRun(p, ctx, (g, s) => ctx.bridge.apis.extras.completeGroupTodo(g, s))
	}),
	groupAction({
		name: "cancel_group_todo",
		summary: "取消群待办",
		params: { message_id: f.messageId() },
		run: (p, ctx) => groupTodoRun(p, ctx, (g, s) => ctx.bridge.apis.extras.cancelGroupTodo(g, s))
	}),
	defineAction({
		name: "create_flash_task",
		summary: "创建闪传任务",
		params: {
			files: f.raw(),
			name: f.string().optional(),
			thumb_path: f.string().optional()
		},
		run: async (p, ctx) => {
			const rawFiles = p.files;
			let fileList;
			if (typeof rawFiles === "string") {
				if (rawFiles === "") return failedResponse(RETCODE.BAD_REQUEST, "files must not be empty");
				fileList = [rawFiles];
			} else if (Array.isArray(rawFiles) && rawFiles.every((x) => typeof x === "string" && x !== "")) {
				if (rawFiles.length === 0) return failedResponse(RETCODE.BAD_REQUEST, "files must not be empty");
				fileList = rawFiles;
			} else return failedResponse(RETCODE.BAD_REQUEST, "files must be a string or string array");
			try {
				const result = await ctx.bridge.apis.flashTransfer.createFlashTask(fileList, p.name, p.thumb_path);
				return okResponse({
					fileset_id: result.filesetId,
					task_id: result.filesetId
				});
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_fileset_info",
		summary: "获取文件集信息",
		params: { fileset_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				const list = await ctx.bridge.apis.flashTransfer.getFilesetInfo(p.fileset_id);
				return okResponse({
					fileset_id: p.fileset_id,
					file_list: list.map(flashFileInfoToJson)
				});
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_flash_file_list",
		summary: "获取闪传文件列表",
		params: { fileset_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				return okResponse((await ctx.bridge.apis.flashTransfer.getFlashFileList(p.fileset_id)).map(flashFileInfoToJson));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "list_filesets",
		summary: "列出当前账号的所有闪传文件集",
		params: {},
		run: async (_p, ctx) => {
			try {
				return okResponse((await ctx.bridge.apis.flashTransfer.listFilesets()).map(flashFileInfoToJson));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_flash_file_url",
		summary: "获取闪传文件链接",
		params: {
			fileset_id: f.string({ allowEmpty: false }),
			file_name: f.string().optional(),
			file_index: f.number().optional()
		},
		run: async (p, ctx) => {
			try {
				return okResponse({ url: await ctx.bridge.apis.flashTransfer.getFlashFileUrl(p.fileset_id, p.file_index) });
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "get_share_link",
		summary: "获取文件分享链接",
		params: { fileset_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.flashTransfer.getShareLink(p.fileset_id));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "delete_flash_file",
		summary: "删除闪传文件",
		params: { fileset_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.flashTransfer.deleteFlashFile(p.fileset_id);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "rename_flash_file",
		summary: "重命名闪传文件",
		params: {
			fileset_id: f.string({ allowEmpty: false }),
			new_name: f.string({ allowEmpty: false })
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.flashTransfer.renameFlashFile(p.fileset_id, p.new_name);
				return okResponse();
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, String(e));
			}
		}
	}),
	defineAction({
		name: "download_fileset",
		summary: "解析闪传文件下载直链（不下载，由调用方实现下载）",
		returns: "{ url, file_name, file_size }",
		params: {
			fileset_id: f.string({ allowEmpty: false }),
			file_name: f.string().optional(),
			file_index: f.number().optional()
		},
		run: async (p, ctx) => {
			try {
				const target = await ctx.bridge.apis.flashTransfer.downloadFileset(p.fileset_id, {
					fileName: p.file_name,
					fileIndex: p.file_index
				});
				return okResponse({
					url: target.url,
					file_name: target.fileName,
					file_size: target.fileSize
				});
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	}),
	defineAction({
		name: "send_flash_msg",
		summary: "发送闪传消息（私聊或群聊，引用 fileset_id 让对端下载）",
		returns: "{ message_id }",
		params: {
			fileset_id: f.string({ allowEmpty: false }),
			user_id: f.uint().optional(),
			group_id: f.uint().optional()
		},
		run: async (p, ctx) => {
			if (!p.user_id && !p.group_id) return failedResponse(RETCODE.BAD_REQUEST, "user_id or group_id is required");
			try {
				await ctx.bridge.apis.flashTransfer.sendFlashMsg(p.fileset_id, {
					userId: p.user_id,
					groupId: p.group_id
				});
				return okResponse({ message_id: 0 });
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	}),
	defineAction({
		name: "get_fileset_id",
		summary: "从分享码/链接获取 fileset_id",
		readOnly: true,
		returns: "{ fileset_id }：解析出的文件集 ID。",
		returnsSchema: {
			type: "object",
			properties: { fileset_id: {
				type: "string",
				description: "文件集 ID"
			} },
			required: ["fileset_id"]
		},
		params: { share_code: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				return okResponse({ fileset_id: await ctx.bridge.apis.flashTransfer.getFilesetIdByCode(p.share_code) });
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, e instanceof Error ? e.message : String(e));
			}
		}
	})
];
async function fetchFilteredGroupRequests(ctx) {
	try {
		return await ctx.bridge.apis.contacts.fetchGroupRequests(true);
	} catch {
		return [];
	}
}
function register$9(h, ctx) {
	registerActions(h, ctx, actions$9);
	h.registerAction(".handle_quick_operation", async (params) => {
		const context = params.context;
		const operation = params.operation;
		if (!context || !operation) return failedResponse(RETCODE.BAD_REQUEST, "context and operation are required");
		const { executeQuickOperation } = await import("./index.mjs").then((n) => n.t);
		await executeQuickOperation(context, operation, h);
		return okResponse();
	});
}
function hexToBytes(hex) {
	const out = new Uint8Array(hex.length / 2);
	for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
	return out;
}
function bytesToHex(buf) {
	return (buf instanceof Buffer ? buf : Buffer.from(buf)).toString("hex");
}
function parseDownloadHeaders(headers) {
	const result = {};
	if (!headers) return result;
	const headerList = [];
	if (typeof headers === "string") headerList.push(...headers.split(/\r?\n/).filter(Boolean));
	else if (Array.isArray(headers)) {
		for (const h of headers) if (typeof h === "string") headerList.push(h);
	}
	for (const line of headerList) {
		const idx = line.indexOf("=");
		if (idx > 0) result[line.substring(0, idx).trim()] = line.substring(idx + 1).trim();
	}
	return result;
}
//#endregion
//#region ../onebot/src/actions/friend.ts
var actions$8 = [
	defineAction({
		name: "get_friend_list",
		summary: "获取好友列表",
		readOnly: true,
		returns: "好友列表数组，每项含 QQ 号、昵称与备注。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: {
					user_id: {
						type: "integer",
						description: "好友 QQ 号"
					},
					nickname: {
						type: "string",
						description: "好友昵称"
					},
					remark: {
						type: "string",
						description: "好友备注"
					}
				},
				required: [
					"user_id",
					"nickname",
					"remark"
				]
			}
		},
		params: {},
		run: async (_p, ctx) => {
			if (ctx.getFriendList) return okResponse(await ctx.getFriendList());
			return okResponse([]);
		}
	}),
	defineAction({
		name: "get_stranger_info",
		summary: "获取陌生人信息",
		readOnly: true,
		returns: "陌生人资料：QQ 号、昵称、性别、年龄，命中资料时另含等级。",
		returnsSchema: {
			type: "object",
			properties: {
				user_id: {
					type: "integer",
					description: "QQ 号"
				},
				nickname: {
					type: "string",
					description: "昵称"
				},
				sex: {
					type: "string",
					description: "性别（male/female/unknown）"
				},
				age: {
					type: "integer",
					description: "年龄"
				},
				qq_level: {
					type: "integer",
					description: "QQ 等级（仅查到资料时返回）"
				},
				level: {
					type: "integer",
					description: "QQ 等级，同 qq_level（仅查到资料时返回）"
				}
			},
			required: [
				"user_id",
				"nickname",
				"sex",
				"age"
			]
		},
		params: { user_id: f.uint().describe("QQ 号") },
		run: async (p, ctx) => {
			const userId = p.user_id;
			if (ctx.getStrangerInfo) return okResponse(await ctx.getStrangerInfo(userId) ?? {
				user_id: userId,
				nickname: "",
				sex: "unknown",
				age: 0
			});
			return okResponse({
				user_id: userId,
				nickname: "",
				sex: "unknown",
				age: 0
			});
		}
	}),
	defineAction({
		name: "delete_friend",
		summary: "删除好友",
		params: {
			user_id: f.uint().describe("QQ 号"),
			block: f.bool().default(false)
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.friend.delete(p.user_id, p.block);
			return okResponse();
		}
	})
];
function register$8(h, ctx) {
	registerActions(h, ctx, actions$8);
}
//#endregion
//#region ../onebot/src/actions/group-admin.ts
var actions$7 = [
	groupUserAction({
		name: "set_group_kick",
		summary: "踢出群成员",
		params: { reject_add_request: f.bool().default(false) },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.kickMember(p.group_id, p.user_id, p.reject_add_request);
			return okResponse();
		}
	}),
	groupAction({
		name: "set_group_kick_members",
		summary: "批量踢出群成员",
		params: {
			user_id: f.array(f.uint()).nonEmpty(),
			reject_add_request: f.bool().default(false)
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.kickMembers(p.group_id, p.user_id, p.reject_add_request);
			return okResponse();
		}
	}),
	groupUserAction({
		name: "set_group_ban",
		summary: "禁言群成员（duration=0 解除）",
		params: { duration: f.int({ min: 0 }).default(1800) },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.muteMember(p.group_id, p.user_id, p.duration);
			return okResponse();
		}
	}),
	groupAction({
		name: "set_group_whole_ban",
		summary: "全员禁言开关",
		params: { enable: f.bool().default(true) },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.muteAll(p.group_id, p.enable);
			return okResponse();
		}
	}),
	groupAction({
		name: "set_group_add_option",
		summary: "设置加群选项",
		params: { add_type: f.int({ min: 0 }).default(0) },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.setAddOption(p.group_id, p.add_type);
			return okResponse();
		}
	}),
	groupAction({
		name: "set_group_search",
		summary: "允许群被搜索",
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.setSearch(p.group_id);
			return okResponse();
		}
	}),
	groupUserAction({
		name: "set_group_admin",
		summary: "设置/取消管理员",
		params: { enable: f.bool().default(true) },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.setAdmin(p.group_id, p.user_id, p.enable);
			return okResponse();
		}
	}),
	groupUserAction({
		name: "set_group_card",
		summary: "设置群名片（空字符串清除）",
		params: { card: f.string().default("") },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.setCard(p.group_id, p.user_id, p.card);
			return okResponse();
		}
	}),
	groupAction({
		name: "set_group_name",
		summary: "设置群名",
		params: { group_name: f.string().default("") },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.setName(p.group_id, p.group_name);
			return okResponse();
		}
	}),
	groupAction({
		name: "set_group_leave",
		summary: "退群",
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.leave(p.group_id);
			return okResponse();
		}
	}),
	groupUserAction({
		name: "set_group_special_title",
		summary: "设置群头衔",
		params: { special_title: f.string().default("") },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupAdmin.setSpecialTitle(p.group_id, p.user_id, p.special_title);
			return okResponse();
		}
	}),
	defineAction({
		name: "set_group_anonymous",
		summary: "匿名开关（未实现，返回 ok）",
		params: {},
		run: () => okResponse()
	}),
	defineAction({
		name: "set_group_anonymous_ban",
		summary: "匿名禁言（未实现，返回 ok）",
		params: {},
		run: () => okResponse()
	}),
	groupAction({
		name: "set_group_portrait",
		summary: "设置群头像",
		params: { file: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.profile.setGroupAvatar(p.group_id, p.file);
				return okResponse();
			} catch (err) {
				return failedResponse(RETCODE.ACTION_FAILED, err instanceof Error ? err.message : String(err));
			}
		}
	})
];
function register$7(h, ctx) {
	registerActions(h, ctx, actions$7);
}
//#endregion
//#region ../onebot/src/actions/group-album.ts
var actions$6 = [
	groupAction({
		name: "get_group_album_list",
		readOnly: true,
		returns: "群相册列表数组，每项为一个相册的基本信息。",
		returnsSchema: {
			type: "array",
			description: "群相册列表",
			items: {
				type: "object",
				properties: {
					id: {
						type: "string",
						description: "相册 id"
					},
					name: {
						type: "string",
						description: "相册名称"
					},
					picNum: {
						type: "integer",
						description: "相册内照片数量"
					},
					createTime: {
						type: "integer",
						description: "相册创建时间（unix 秒）"
					}
				},
				required: [
					"id",
					"name",
					"picNum",
					"createTime"
				]
			}
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.groupAlbum.list(p.group_id));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to get group album list";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	groupAction({
		name: "get_qun_album_list",
		readOnly: true,
		returns: "NapCat 风格的相册列表封套：{album_list, attach_info, has_more}（本实现 attach_info 恒为空串、has_more 恒为 false）。",
		returnsSchema: {
			type: "object",
			properties: {
				album_list: {
					type: "array",
					description: "相册列表",
					items: {
						type: "object",
						properties: {
							album_id: {
								type: "string",
								description: "相册 id"
							},
							album_name: {
								type: "string",
								description: "相册名称"
							},
							create_time: {
								type: "integer",
								description: "相册创建时间（unix 秒）"
							},
							pic_num: {
								type: "integer",
								description: "相册内照片数量"
							}
						},
						required: [
							"album_id",
							"album_name",
							"create_time",
							"pic_num"
						]
					}
				},
				attach_info: {
					type: "string",
					description: "分页游标（本 web 实现一次取满，恒为空串）"
				},
				has_more: {
					type: "boolean",
					description: "是否还有更多（本 web 实现恒为 false）"
				}
			},
			required: [
				"album_list",
				"attach_info",
				"has_more"
			]
		},
		run: async (p, ctx) => {
			try {
				return okResponse({
					album_list: (await ctx.bridge.apis.groupAlbum.list(p.group_id)).map((a) => ({
						album_id: a.id,
						album_name: a.name,
						create_time: a.createTime,
						pic_num: a.picNum
					})),
					attach_info: "",
					has_more: false
				});
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to get qun album list";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	groupAction({
		name: "upload_image_to_qun_album",
		params: {
			album_id: f.string({ allowEmpty: false }),
			album_name: f.string({ allowEmpty: false }),
			file: f.string({ allowEmpty: false })
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.groupAlbum.upload(p.group_id, p.album_id, p.album_name, p.file);
				return okResponse(null);
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to upload image to group album";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	groupAction({
		name: "get_group_album_media_list",
		readOnly: true,
		returns: "相册媒体列表及下一页分页游标：{mediaList, nextAttachInfo}。",
		returnsSchema: {
			type: "object",
			properties: {
				mediaList: {
					type: "array",
					description: "相册媒体项列表（各项字段不固定）",
					items: { type: "object" }
				},
				nextAttachInfo: {
					type: "string",
					description: "下一页分页游标（空串表示无更多）"
				}
			},
			required: ["mediaList", "nextAttachInfo"]
		},
		params: {
			album_id: f.string({ allowEmpty: false }),
			attach_info: f.string().default("")
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.groupAlbum.getMediaList(p.group_id, p.album_id, p.attach_info));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to get group album media list";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	groupAction({
		name: "do_group_album_comment",
		params: {
			album_id: f.string({ allowEmpty: false }),
			lloc: f.string({ allowEmpty: false }),
			content: f.string({ allowEmpty: false })
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.groupAlbum.comment(p.group_id, p.album_id, p.lloc, p.content));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to comment on album media";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	groupAction({
		name: "set_group_album_media_like",
		params: {
			album_id: f.string({ allowEmpty: false }),
			batch_id: f.string({ allowEmpty: false }),
			lloc: f.string().optional()
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.groupAlbum.like(p.group_id, p.album_id, p.batch_id, p.lloc || void 0, true));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to set like on album media";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	groupAction({
		name: "cancel_group_album_media_like",
		params: {
			album_id: f.string({ allowEmpty: false }),
			batch_id: f.string({ allowEmpty: false }),
			lloc: f.string().optional()
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.groupAlbum.like(p.group_id, p.album_id, p.batch_id, p.lloc || void 0, false));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to cancel like on album media";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	groupAction({
		name: "del_group_album_media",
		params: {
			album_id: f.string({ allowEmpty: false }),
			lloc: f.string({ allowEmpty: false })
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.groupAlbum.delete(p.group_id, p.album_id, p.lloc));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to delete album media";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	})
];
function register$6(h, ctx) {
	registerActions(h, ctx, actions$6);
}
//#endregion
//#region ../onebot/src/actions/group-file.ts
function busidOr102(raw) {
	const n = typeof raw === "number" && Number.isFinite(raw) ? Math.trunc(raw) : typeof raw === "string" && raw.trim() !== "" && Number.isFinite(Number(raw)) ? Math.trunc(Number(raw)) : NaN;
	return Number.isInteger(n) && n >= 0 ? n : 102;
}
var actions$5 = [
	groupAction({
		name: "upload_group_file",
		summary: "上传群文件",
		returns: "{ file_id: string }",
		params: {
			file: f.string({ allowEmpty: false }),
			name: f.string().default(""),
			folder: f.string().default(""),
			folder_id: f.string().default(""),
			upload_file: f.bool().default(true)
		},
		run: async (p, ctx) => {
			const folderId = p.folder || p.folder_id || "/";
			return okResponse({ file_id: (await ctx.bridge.apis.groupFile.upload(p.group_id, p.file, p.name, folderId, p.upload_file)).fileId });
		}
	}),
	defineAction({
		name: "upload_private_file",
		summary: "上传私聊文件",
		returns: "{ file_id: string }",
		params: {
			user_id: f.uint(),
			file: f.string({ allowEmpty: false }),
			name: f.string().default(""),
			upload_file: f.bool().default(true)
		},
		run: async (p, ctx) => {
			return okResponse({ file_id: (await ctx.bridge.apis.groupFile.uploadPrivate(p.user_id, p.file, p.name, p.upload_file)).fileId });
		}
	}),
	groupAction({
		name: "get_group_file_url",
		summary: "获取群文件下载链接",
		readOnly: true,
		returns: "群文件下载链接。",
		returnsSchema: {
			type: "object",
			properties: { url: {
				type: "string",
				description: "文件下载直链"
			} },
			required: ["url"]
		},
		params: {
			file_id: f.string({ allowEmpty: false }),
			busid: f.raw()
		},
		run: async (p, ctx) => {
			return okResponse({ url: await ctx.bridge.apis.groupFile.getUrl(p.group_id, p.file_id, busidOr102(p.busid)) });
		}
	}),
	groupAction({
		name: "get_group_root_files",
		summary: "获取群根目录文件列表",
		readOnly: true,
		returns: "群文件系统信息（文件与文件夹列表）。",
		returnsSchema: {
			type: "object",
			properties: {
				files: {
					type: "array",
					description: "文件列表",
					items: {
						type: "object",
						properties: {
							group_id: {
								type: "integer",
								description: "群号"
							},
							file_id: {
								type: "string",
								description: "文件 ID"
							},
							file_name: {
								type: "string",
								description: "文件名"
							},
							busid: {
								type: "integer",
								description: "业务 ID"
							},
							file_size: {
								type: "integer",
								description: "文件大小（字节）"
							},
							upload_time: {
								type: "integer",
								description: "上传时间戳"
							},
							dead_time: {
								type: "integer",
								description: "过期时间戳"
							},
							modify_time: {
								type: "integer",
								description: "修改时间戳"
							},
							download_times: {
								type: "integer",
								description: "下载次数"
							},
							uploader: {
								type: "integer",
								description: "上传者 QQ 号"
							},
							uploader_name: {
								type: "string",
								description: "上传者昵称"
							}
						}
					}
				},
				folders: {
					type: "array",
					description: "文件夹列表",
					items: {
						type: "object",
						properties: {
							group_id: {
								type: "integer",
								description: "群号"
							},
							folder_id: {
								type: "string",
								description: "文件夹 ID"
							},
							folder_name: {
								type: "string",
								description: "文件夹名"
							},
							create_time: {
								type: "integer",
								description: "创建时间戳"
							},
							creator: {
								type: "integer",
								description: "创建者 QQ 号"
							},
							create_name: {
								type: "string",
								description: "创建者昵称"
							},
							total_file_count: {
								type: "integer",
								description: "文件夹内文件总数"
							}
						}
					}
				}
			},
			required: ["files", "folders"]
		},
		run: async (p, ctx) => {
			return okResponse(await ctx.getGroupFiles(p.group_id, "/"));
		}
	}),
	groupAction({
		name: "get_group_files_by_folder",
		summary: "获取群子目录文件列表",
		readOnly: true,
		returns: "群文件系统信息（文件与文件夹列表）。",
		returnsSchema: {
			type: "object",
			properties: {
				files: {
					type: "array",
					description: "文件列表",
					items: {
						type: "object",
						properties: {
							group_id: {
								type: "integer",
								description: "群号"
							},
							file_id: {
								type: "string",
								description: "文件 ID"
							},
							file_name: {
								type: "string",
								description: "文件名"
							},
							busid: {
								type: "integer",
								description: "业务 ID"
							},
							file_size: {
								type: "integer",
								description: "文件大小（字节）"
							},
							upload_time: {
								type: "integer",
								description: "上传时间戳"
							},
							dead_time: {
								type: "integer",
								description: "过期时间戳"
							},
							modify_time: {
								type: "integer",
								description: "修改时间戳"
							},
							download_times: {
								type: "integer",
								description: "下载次数"
							},
							uploader: {
								type: "integer",
								description: "上传者 QQ 号"
							},
							uploader_name: {
								type: "string",
								description: "上传者昵称"
							}
						}
					}
				},
				folders: {
					type: "array",
					description: "文件夹列表",
					items: {
						type: "object",
						properties: {
							group_id: {
								type: "integer",
								description: "群号"
							},
							folder_id: {
								type: "string",
								description: "文件夹 ID"
							},
							folder_name: {
								type: "string",
								description: "文件夹名"
							},
							create_time: {
								type: "integer",
								description: "创建时间戳"
							},
							creator: {
								type: "integer",
								description: "创建者 QQ 号"
							},
							create_name: {
								type: "string",
								description: "创建者昵称"
							},
							total_file_count: {
								type: "integer",
								description: "文件夹内文件总数"
							}
						}
					}
				}
			},
			required: ["files", "folders"]
		},
		params: {
			folder_id: f.string().default(""),
			folder: f.string().default("")
		},
		run: async (p, ctx) => {
			const folderId = p.folder_id || p.folder || "/";
			return okResponse(await ctx.getGroupFiles(p.group_id, folderId));
		}
	}),
	groupAction({
		name: "delete_group_file",
		summary: "删除群文件",
		params: { file_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupFile.delete(p.group_id, p.file_id);
			return okResponse();
		}
	}),
	groupAction({
		name: "move_group_file",
		summary: "移动群文件",
		params: {
			file_id: f.string({ allowEmpty: false }),
			parent_directory: f.string({ allowEmpty: false }),
			target_directory: f.string({ allowEmpty: false })
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupFile.move(p.group_id, p.file_id, p.parent_directory, p.target_directory);
			return okResponse();
		}
	}),
	groupAction({
		name: "rename_group_file",
		summary: "重命名群文件",
		params: {
			file_id: f.string({ allowEmpty: false }),
			current_parent_directory: f.string().default("/"),
			new_name: f.string({ allowEmpty: false })
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupFile.rename(p.group_id, p.file_id, p.current_parent_directory || "/", p.new_name);
			return okResponse({ ok: true });
		}
	}),
	groupAction({
		name: "create_group_file_folder",
		summary: "创建群文件夹",
		params: {
			name: f.string({ allowEmpty: false }),
			parent_id: f.string().default("/")
		},
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupFile.createFolder(p.group_id, p.name, p.parent_id || "/");
			return okResponse();
		}
	}),
	groupAction({
		name: "delete_group_file_folder",
		summary: "删除群文件夹",
		params: { folder_id: f.string({ allowEmpty: false }) },
		run: async (p, ctx) => {
			await ctx.bridge.apis.groupFile.deleteFolder(p.group_id, p.folder_id);
			return okResponse();
		}
	}),
	groupAction({
		name: "rename_group_file_folder",
		summary: "重命名群文件夹",
		params: {
			folder_id: f.string({ allowEmpty: false }),
			new_folder_name: f.string().default(""),
			name: f.string().default("")
		},
		run: async (p, ctx) => {
			const newName = p.new_folder_name || p.name;
			if (!newName) return failedResponse(RETCODE.BAD_REQUEST, "group_id, folder_id and new_folder_name are required");
			await ctx.bridge.apis.groupFile.renameFolder(p.group_id, p.folder_id, newName);
			return okResponse();
		}
	}),
	defineAction({
		name: "get_private_file_url",
		summary: "获取私聊文件下载链接",
		readOnly: true,
		returns: "私聊文件下载链接。",
		returnsSchema: {
			type: "object",
			properties: { url: {
				type: "string",
				description: "文件下载直链"
			} },
			required: ["url"]
		},
		params: {
			user_id: f.uint().optional(),
			file_id: f.string({ allowEmpty: false }),
			file_hash: f.string().default("")
		},
		run: async (p, ctx) => {
			return okResponse({ url: await ctx.bridge.apis.groupFile.getPrivateUrl(p.user_id ?? 0, p.file_id, p.file_hash) });
		}
	})
];
function register$5(h, ctx) {
	registerActions(h, ctx, actions$5);
}
//#endregion
//#region ../protocol/src/web/request-util.ts
var RequestUtil = class {
	static async HttpsGetCookies(url) {
		const client = url.startsWith("https") ? https : http;
		return new Promise((resolve, reject) => {
			client.get(url, (res) => {
				const cookies = {};
				res.on("data", () => {});
				res.on("end", () => {
					this.handleRedirect(res, url, cookies).then(resolve).catch(reject);
				});
				if (res.headers["set-cookie"]) this.extractCookies(res.headers["set-cookie"], cookies);
			}).on("error", (error) => {
				reject(error);
			});
		});
	}
	static async handleRedirect(res, url, cookies) {
		if (res.statusCode === 301 || res.statusCode === 302) {
			if (res.headers.location) {
				const redirectUrl = new URL(res.headers.location, url);
				const redirectCookies = await this.HttpsGetCookies(redirectUrl.href);
				return {
					...cookies,
					...redirectCookies
				};
			}
		}
		return cookies;
	}
	static extractCookies(setCookieHeaders, cookies) {
		setCookieHeaders.forEach((cookie) => {
			const parts = cookie.split(";")[0]?.split("=");
			if (parts) {
				const key = parts[0];
				const value = parts[1];
				if (key && value && key.length > 0 && value.length > 0) cookies[key] = value;
			}
		});
	}
	static async HttpGetJson(url, method = "GET", data, headers = {}, isJsonRet = true, isArgJson = true, maxRedirects = 5) {
		const option = new URL(url);
		const protocol = url.startsWith("https://") ? https : http;
		const options = {
			hostname: option.hostname,
			port: option.port,
			path: option.pathname + option.search,
			method,
			headers
		};
		return new Promise((resolve, reject) => {
			const req = protocol.request(options, (res) => {
				if ((res.statusCode === 301 || res.statusCode === 302 || res.statusCode === 307 || res.statusCode === 308) && res.headers.location) {
					if (maxRedirects <= 0) {
						reject(/* @__PURE__ */ new Error("Too many redirects"));
						return;
					}
					const redirectUrl = new URL(res.headers.location, url).href;
					this.HttpGetJson(redirectUrl, method, data, headers, isJsonRet, isArgJson, maxRedirects - 1).then(resolve).catch(reject);
					return;
				}
				let responseBody = "";
				res.on("data", (chunk) => {
					responseBody += chunk.toString();
				});
				res.on("end", () => {
					try {
						if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) if (isJsonRet) resolve(JSON.parse(responseBody));
						else resolve(responseBody);
						else reject(/* @__PURE__ */ new Error(`Unexpected status code: ${res.statusCode}`));
					} catch (parseError) {
						reject(new Error(parseError instanceof Error ? parseError.message : String(parseError)));
					}
				});
			});
			req.on("error", (error) => reject(error));
			if (method === "POST" || method === "PUT" || method === "PATCH") req.write(isArgJson ? JSON.stringify(data) : data);
			req.end();
		});
	}
	static async HttpGetText(url, method = "GET", data, headers = {}) {
		return this.HttpGetJson(url, method, data, headers, false, false);
	}
};
function cookieToString(cookieObject) {
	return Object.entries(cookieObject).map(([key, value]) => `${key}=${value}`).join("; ");
}
function getBknFromCookie(cookieObject) {
	const skey = cookieObject["p_skey"] || cookieObject["skey"] || "";
	let hash = 5381;
	for (let i = 0; i < skey.length; i++) hash += (hash << 5) + skey.charCodeAt(i);
	return (hash & 2147483647).toString();
}
//#endregion
//#region ../protocol/src/web/group-honor.ts
var log$2 = createLogger("Bridge.Web");
var WebHonorType = /* @__PURE__ */ function(WebHonorType) {
	WebHonorType["TALKATIVE"] = "talkative";
	WebHonorType["PERFORMER"] = "performer";
	WebHonorType["LEGEND"] = "legend";
	WebHonorType["EMOTION"] = "emotion";
	WebHonorType["ALL"] = "all";
	return WebHonorType;
}({});
async function fetchHonorData(cookieObject, groupCode, type) {
	let resJson;
	try {
		const res = await RequestUtil.HttpGetText(`https://qun.qq.com/interactive/honorlist?${new URLSearchParams({
			gc: groupCode,
			type: type.toString()
		}).toString()}`, "GET", "", { Cookie: cookieToString(cookieObject) });
		const match = /window\.__INITIAL_STATE__=(.*?);/.exec(res);
		if (match?.[1]) resJson = JSON.parse(match[1].trim());
		return type === 1 ? resJson?.talkativeList : resJson?.actorList;
	} catch (e) {
		throw new Error(`获取群 ${groupCode} 类型 ${type} 的荣誉信息失败: ${e}`);
	}
}
async function getHonorListWebAPI(cookieObject, groupCode, type) {
	try {
		const data = await fetchHonorData(cookieObject, groupCode, type);
		if (!data) return [];
		return data.map((item) => ({
			user_id: item?.uin ?? null,
			nickname: item?.name ?? "",
			avatar: item?.avatar ?? "",
			description: item?.desc ?? ""
		}));
	} catch (e) {
		log$2.warn("getHonorListWebAPI failed (group=%s type=%d): %s", groupCode, type, e instanceof Error ? e.stack ?? e.message : String(e));
		return [];
	}
}
//#endregion
//#region ../onebot/src/actions/group-info.ts
var actions$4 = [
	defineAction({
		name: "get_group_list",
		summary: "获取群列表",
		readOnly: true,
		returns: "群信息对象数组。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: {
					group_id: {
						type: "integer",
						description: "群号"
					},
					group_name: {
						type: "string",
						description: "群名"
					},
					member_count: {
						type: "integer",
						description: "当前成员数"
					},
					max_member_count: {
						type: "integer",
						description: "成员上限"
					}
				},
				required: [
					"group_id",
					"group_name",
					"member_count",
					"max_member_count"
				]
			}
		},
		params: { no_cache: f.bool().default(false) },
		run: async (p, ctx) => {
			const noCache = p.no_cache;
			if (ctx.getGroupList) return okResponse(await ctx.getGroupList(noCache));
			return okResponse([]);
		}
	}),
	groupAction({
		name: "get_group_info",
		summary: "获取群信息",
		readOnly: true,
		returns: "群信息对象。",
		returnsSchema: {
			type: "object",
			properties: {
				group_id: {
					type: "integer",
					description: "群号"
				},
				group_name: {
					type: "string",
					description: "群名"
				},
				member_count: {
					type: "integer",
					description: "当前成员数"
				},
				max_member_count: {
					type: "integer",
					description: "成员上限"
				}
			},
			required: [
				"group_id",
				"group_name",
				"member_count",
				"max_member_count"
			]
		},
		params: { no_cache: f.bool().default(false) },
		run: async (p, ctx) => {
			const groupId = p.group_id;
			const noCache = p.no_cache;
			if (ctx.getGroupInfo) return okResponse(await ctx.getGroupInfo(groupId, noCache) ?? {
				group_id: groupId,
				group_name: "",
				member_count: 0,
				max_member_count: 0
			});
			return okResponse({
				group_id: groupId,
				group_name: "",
				member_count: 0,
				max_member_count: 0
			});
		}
	}),
	groupAction({
		name: "get_group_member_list",
		summary: "获取群成员列表",
		readOnly: true,
		returns: "群成员信息对象数组。",
		returnsSchema: {
			type: "array",
			items: {
				type: "object",
				properties: {
					group_id: {
						type: "integer",
						description: "群号"
					},
					user_id: {
						type: "integer",
						description: "QQ 号"
					},
					nickname: {
						type: "string",
						description: "昵称"
					},
					card: {
						type: "string",
						description: "群名片"
					},
					sex: {
						type: "string",
						enum: [
							"male",
							"female",
							"unknown"
						],
						description: "性别"
					},
					age: {
						type: "integer",
						description: "年龄"
					},
					join_time: {
						type: "integer",
						description: "入群时间戳（秒）"
					},
					last_sent_time: {
						type: "integer",
						description: "最后发言时间戳（秒）"
					},
					level: {
						type: "string",
						description: "群等级"
					},
					role: {
						type: "string",
						enum: [
							"owner",
							"admin",
							"member"
						],
						description: "角色"
					},
					title: {
						type: "string",
						description: "专属头衔"
					}
				},
				required: [
					"group_id",
					"user_id",
					"nickname",
					"role"
				]
			}
		},
		params: { no_cache: f.bool().default(false) },
		run: async (p, ctx) => {
			const groupId = p.group_id;
			const noCache = p.no_cache;
			if (ctx.getGroupMemberList) return okResponse(await ctx.getGroupMemberList(groupId, noCache));
			return okResponse([]);
		}
	}),
	groupUserAction({
		name: "get_group_member_info",
		summary: "获取群成员信息",
		readOnly: true,
		returns: "群成员信息对象。",
		returnsSchema: {
			type: "object",
			properties: {
				group_id: {
					type: "integer",
					description: "群号"
				},
				user_id: {
					type: "integer",
					description: "QQ 号"
				},
				nickname: {
					type: "string",
					description: "昵称"
				},
				card: {
					type: "string",
					description: "群名片"
				},
				sex: {
					type: "string",
					enum: [
						"male",
						"female",
						"unknown"
					],
					description: "性别"
				},
				age: {
					type: "integer",
					description: "年龄"
				},
				join_time: {
					type: "integer",
					description: "入群时间戳（秒）"
				},
				last_sent_time: {
					type: "integer",
					description: "最后发言时间戳（秒）"
				},
				level: {
					type: "string",
					description: "群等级"
				},
				role: {
					type: "string",
					enum: [
						"owner",
						"admin",
						"member"
					],
					description: "角色"
				},
				title: {
					type: "string",
					description: "专属头衔"
				}
			},
			required: [
				"group_id",
				"user_id",
				"nickname",
				"role"
			]
		},
		params: { no_cache: f.bool().default(false) },
		run: async (p, ctx) => {
			const groupId = p.group_id;
			const userId = p.user_id;
			const noCache = p.no_cache;
			if (ctx.getGroupMemberInfo) return okResponse(await ctx.getGroupMemberInfo(groupId, userId, noCache) ?? {
				group_id: groupId,
				user_id: userId,
				nickname: "",
				card: "",
				sex: "unknown",
				age: 0,
				join_time: 0,
				last_sent_time: 0,
				level: "0",
				role: "member",
				title: ""
			});
			return okResponse({
				group_id: groupId,
				user_id: userId,
				nickname: "",
				card: "",
				sex: "unknown",
				age: 0,
				join_time: 0,
				last_sent_time: 0,
				level: "0",
				role: "member",
				title: ""
			});
		}
	}),
	groupAction({
		name: "get_group_honor_info",
		summary: "获取群荣誉信息",
		readOnly: true,
		params: { type: f.raw() },
		run: async (p, ctx) => {
			const groupId = p.group_id;
			const typeStr = asString(p.type) || "all";
			const typeValues = Object.values(WebHonorType);
			if (!typeValues.includes(typeStr)) return failedResponse(RETCODE.BAD_REQUEST, `invalid type, must be one of ${typeValues.join(", ")}`);
			try {
				return okResponse(await ctx.bridge.apis.web.getHonorInfo(groupId, typeStr));
			} catch (e) {
				return failedResponse(RETCODE.ACTION_FAILED, `failed to get group honor info: ${e.message}`);
			}
		}
	}),
	defineAction({
		name: "get_group_system_msg",
		summary: "获取群系统消息",
		readOnly: true,
		params: {},
		run: async (_p, ctx) => {
			if (ctx.handleGetGroupSystemMsg) return okResponse(await ctx.handleGetGroupSystemMsg());
			return okResponse([]);
		}
	})
];
function register$4(h, ctx) {
	registerActions(h, ctx, actions$4);
}
//#endregion
//#region ../onebot/src/actions/info.ts
var appVersion = "1.10.3";
var actions$3 = [
	defineAction({
		name: "get_login_info",
		readOnly: true,
		returns: "当前登录账号的 QQ 号与昵称。",
		returnsSchema: {
			type: "object",
			properties: {
				user_id: {
					type: "integer",
					description: "登录 QQ 号"
				},
				nickname: {
					type: "string",
					description: "登录昵称"
				}
			},
			required: ["user_id", "nickname"]
		},
		params: {},
		run: (_p, ctx) => {
			const login = ctx.getLoginInfo();
			return okResponse({
				user_id: login.userId,
				nickname: login.nickname
			});
		}
	}),
	defineAction({
		name: "get_status",
		readOnly: true,
		returns: "运行状态。`online`/`good` 均表示账号是否在线。",
		returnsSchema: {
			type: "object",
			properties: {
				online: {
					type: "boolean",
					description: "是否在线"
				},
				good: {
					type: "boolean",
					description: "状态是否正常（与 online 一致）"
				}
			},
			required: ["online", "good"]
		},
		params: {},
		run: (_p, ctx) => {
			const online = ctx.isOnline();
			return okResponse({
				online,
				good: online
			});
		}
	}),
	defineAction({
		name: "get_version_info",
		readOnly: true,
		returns: "实现与协议版本信息。",
		returnsSchema: {
			type: "object",
			properties: {
				app_name: {
					type: "string",
					description: "实现名称（SnowLuma）"
				},
				app_version: {
					type: "string",
					description: "实现版本"
				},
				protocol_version: {
					type: "string",
					description: "OneBot 协议版本"
				}
			},
			required: [
				"app_name",
				"app_version",
				"protocol_version"
			]
		},
		params: {},
		run: () => {
			return okResponse({
				app_name: "SnowLuma",
				app_version: `${appVersion}-node`,
				protocol_version: "v11"
			});
		}
	}),
	defineAction({
		name: "can_send_image",
		readOnly: true,
		returns: "能力查询结果。",
		returnsSchema: {
			type: "object",
			properties: { yes: {
				type: "boolean",
				description: "是否支持发送图片"
			} },
			required: ["yes"]
		},
		params: {},
		run: (_p, ctx) => {
			return okResponse({ yes: ctx.canSendImage?.() ?? false });
		}
	}),
	defineAction({
		name: "can_send_record",
		readOnly: true,
		returns: "能力查询结果。",
		returnsSchema: {
			type: "object",
			properties: { yes: {
				type: "boolean",
				description: "是否支持发送语音"
			} },
			required: ["yes"]
		},
		params: {},
		run: (_p, ctx) => {
			return okResponse({ yes: ctx.canSendRecord?.() ?? false });
		}
	})
];
function register$3(h, ctx) {
	registerActions(h, ctx, actions$3);
}
//#endregion
//#region ../onebot/src/actions/message.ts
var log$1 = createLogger("OneBot");
/**
* Re-sign image URLs in a stored message event at read time. `get_msg`
* returns a copy persisted when the message first arrived, and image rkeys
* expire — so walk the segment array and refresh each image URL through
* `ctx.getImageInfo`, which mints a current rkey. Best-effort and in-place;
* `findEvent` returns a fresh parse, so mutating the array is safe.
*/
async function refreshStoredImageUrls(event, ctx) {
	const segments = event.message;
	if (!Array.isArray(segments)) return;
	for (const seg of segments) {
		if (!seg || typeof seg !== "object") continue;
		const segment = seg;
		if (segment.type !== "image") continue;
		const data = segment.data;
		if (!data || typeof data !== "object") continue;
		const file = typeof data.file === "string" ? data.file : typeof data.file_id === "string" ? data.file_id : "";
		if (!file) continue;
		try {
			const info = await ctx.getImageInfo(file);
			if (info && typeof info.url === "string" && info.url) data.url = info.url;
		} catch {}
	}
}
var actions$2 = [
	defineAction({
		name: "send_msg",
		summary: "发送消息（按 message_type/群号 自动路由群聊或私聊）",
		returns: "{ message_id: number }",
		params: {
			message: f.message(),
			message_type: f.string().optional(),
			group_id: f.uint().optional(),
			user_id: f.uint().optional(),
			auto_escape: f.bool().default(false)
		},
		run: async (p, ctx) => {
			if (p.message_type === "group" || p.group_id !== void 0) {
				if (p.group_id === void 0) return failedResponse(RETCODE.BAD_REQUEST, "group_id is required");
				return okResponse({ message_id: (await ctx.sendGroupMessage(p.group_id, p.message, p.auto_escape)).messageId });
			}
			if (p.user_id === void 0) return failedResponse(RETCODE.BAD_REQUEST, "user_id is required");
			return okResponse({ message_id: (await ctx.sendPrivateMessage(p.user_id, p.message, p.auto_escape)).messageId });
		}
	}),
	defineAction({
		name: "send_private_msg",
		summary: "发送私聊消息",
		returns: "{ message_id: number }",
		params: {
			user_id: f.uint(),
			message: f.message(),
			auto_escape: f.bool().default(false)
		},
		run: async (p, ctx) => {
			return okResponse({ message_id: (await ctx.sendPrivateMessage(p.user_id, p.message, p.auto_escape)).messageId });
		}
	}),
	groupAction({
		name: "send_group_msg",
		summary: "发送群消息",
		returns: "{ message_id: number }",
		params: {
			message: f.message(),
			auto_escape: f.bool().default(false)
		},
		run: async (p, ctx) => {
			return okResponse({ message_id: (await ctx.sendGroupMessage(p.group_id, p.message, p.auto_escape)).messageId });
		}
	}),
	defineAction({
		name: "get_msg",
		summary: "获取消息",
		readOnly: true,
		returns: "消息事件对象（首次收到时存储的副本，已去除 post_type/self_id、附带 real_id 字段并刷新图片 URL）。",
		params: { message_id: f.messageId() },
		run: async (p, ctx) => {
			const data = ctx.getMessage(p.message_id);
			if (!data) {
				log$1.warn("[get_msg] miss message_id=%d", p.message_id);
				return failedResponse(RETCODE.ACTION_FAILED, "message not found");
			}
			const result = { ...data };
			delete result.post_type;
			delete result.self_id;
			result.real_id = result.message_id ?? p.message_id;
			await refreshStoredImageUrls(result, ctx);
			return okResponse(result);
		}
	}),
	defineAction({
		name: "delete_msg",
		summary: "撤回消息",
		params: { message_id: f.messageId() },
		run: async (p, ctx) => {
			const meta = ctx.getMessageMeta(p.message_id);
			if (!meta) return failedResponse(RETCODE.ACTION_FAILED, "message not found or not retractable");
			await ctx.deleteMessage(p.message_id, meta);
			return okResponse();
		}
	})
];
function register$2(h, ctx) {
	registerActions(h, ctx, actions$2);
}
//#endregion
//#region ../onebot/src/actions/qzone.ts
var actions$1 = [
	defineAction({
		name: "get_qzone_msg_list",
		readOnly: true,
		returns: "说说列表对象，含说说总数与本页说说数组。",
		returnsSchema: {
			type: "object",
			properties: {
				total: {
					type: "integer",
					description: "账号说说总数（非本页数量）"
				},
				msglist: {
					type: "array",
					description: "本页说说数组",
					items: {
						type: "object",
						properties: {
							tid: {
								type: "string",
								description: "说说 id（delete/comment/like 的句柄）"
							},
							content: {
								type: "string",
								description: "说说正文"
							},
							time: {
								type: "integer",
								description: "发表时间（unix 秒）"
							},
							comment_num: {
								type: "integer",
								description: "评论数"
							},
							is_private: {
								type: "boolean",
								description: "是否仅自己可见"
							},
							images: {
								type: "array",
								items: { type: "string" },
								description: "图片 URL 列表（每图取最大可用变体）"
							}
						},
						required: [
							"tid",
							"content",
							"time",
							"comment_num",
							"is_private",
							"images"
						]
					}
				}
			},
			required: ["total", "msglist"]
		},
		summary: "获取 QQ 空间说说列表（默认机器人自己的空间）",
		params: {
			target_uin: f.uint().describe("目标 QQ 号，省略则取机器人自己").optional(),
			pos: f.int({ min: 0 }).describe("起始偏移").default(0),
			num: f.int({
				min: 1,
				max: 100
			}).describe("本页数量").default(20)
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.qzone.getMsgList(p.target_uin, p.pos, p.num));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to get qzone msg list";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	defineAction({
		name: "get_qzone_feeds",
		readOnly: true,
		returns: "好友动态对象，含本页 feed 数组与是否有更多页。",
		returnsSchema: {
			type: "object",
			properties: {
				feeds: {
					type: "array",
					description: "本页好友动态数组",
					items: {
						type: "object",
						properties: {
							uin: {
								type: "integer",
								description: "动态作者 QQ 号"
							},
							nickname: {
								type: "string",
								description: "作者昵称"
							},
							time: {
								type: "integer",
								description: "发表时间（unix 秒）"
							},
							appid: {
								type: "integer",
								description: "Qzone 应用 id（311=说说，4=相册，…）"
							},
							key: {
								type: "string",
								description: "feed 句柄（Qzone 用于定位该条动态）"
							},
							html: {
								type: "string",
								description: "预渲染 HTML 原样透传"
							}
						},
						required: [
							"uin",
							"nickname",
							"time",
							"appid",
							"key",
							"html"
						]
					}
				},
				has_more: {
					type: "boolean",
					description: "服务端是否报告本页之后还有更多页"
				}
			},
			required: ["feeds", "has_more"]
		},
		summary: "获取 QQ 空间好友动态（feed）；page_num 仅首页可靠，深翻页需时间游标（暂未实现）",
		params: {
			page_num: f.int({ min: 1 }).describe("页码（1 起；仅首页可靠）").default(1),
			count: f.int({
				min: 1,
				max: 50
			}).describe("本页数量").default(10)
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.qzone.getFeeds(p.page_num, p.count));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to get qzone feeds";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	defineAction({
		name: "send_qzone_msg",
		summary: "发表一条纯文字说说（QQ 空间）",
		params: { content: f.string({ allowEmpty: false }).describe("说说正文") },
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.qzone.publish(p.content));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to publish qzone msg";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	defineAction({
		name: "delete_qzone_msg",
		summary: "删除一条说说（QQ 空间，按 tid）",
		params: { tid: f.string({ allowEmpty: false }).describe("说说 tid（来自 get_qzone_msg_list / send_qzone_msg）") },
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.qzone.delete(p.tid);
				return okResponse(null);
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to delete qzone msg";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	defineAction({
		name: "like_qzone",
		summary: "给一条说说点赞（QQ 空间）",
		params: {
			tid: f.string({ allowEmpty: false }).describe("说说 tid"),
			target_uin: f.uint().describe("说说所属 QQ 号，省略则为机器人自己").optional(),
			abstime: f.int({ min: 0 }).describe("说说发表时间（unix 秒），传真实值更可靠").default(0)
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.qzone.like(p.tid, p.target_uin, true, p.abstime);
				return okResponse(null);
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to like qzone msg";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	defineAction({
		name: "unlike_qzone",
		summary: "取消对一条说说的点赞（QQ 空间；取消赞端点待真机核实）",
		params: {
			tid: f.string({ allowEmpty: false }).describe("说说 tid"),
			target_uin: f.uint().describe("说说所属 QQ 号，省略则为机器人自己").optional(),
			abstime: f.int({ min: 0 }).describe("说说发表时间（unix 秒），传真实值更可靠").default(0)
		},
		run: async (p, ctx) => {
			try {
				await ctx.bridge.apis.qzone.like(p.tid, p.target_uin, false, p.abstime);
				return okResponse(null);
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to unlike qzone msg";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	}),
	defineAction({
		name: "comment_qzone",
		summary: "评论一条说说（QQ 空间）",
		params: {
			tid: f.string({ allowEmpty: false }).describe("说说 tid"),
			content: f.string({ allowEmpty: false }).describe("评论内容"),
			target_uin: f.uint().describe("说说所属 QQ 号，省略则为机器人自己").optional()
		},
		run: async (p, ctx) => {
			try {
				return okResponse(await ctx.bridge.apis.qzone.comment(p.tid, p.content, p.target_uin));
			} catch (error) {
				const message = error instanceof Error ? error.message : "failed to comment qzone msg";
				return failedResponse(RETCODE.INTERNAL_ERROR, message);
			}
		}
	})
];
function register$1(h, ctx) {
	registerActions(h, ctx, actions$1);
}
//#endregion
//#region ../onebot/src/actions/request.ts
var actions = [defineAction({
	name: "set_friend_add_request",
	summary: "处理好友添加请求",
	params: {
		flag: f.string({ allowEmpty: false }),
		approve: f.bool().default(true)
	},
	run: async (p, ctx) => {
		await ctx.bridge.apis.friend.handleRequest(p.flag, p.approve);
		return okResponse();
	}
}), defineAction({
	name: "set_group_add_request",
	summary: "处理加群请求",
	params: {
		flag: f.string({ allowEmpty: false }),
		sub_type: f.raw(),
		type: f.raw(),
		approve: f.bool().default(true),
		reason: f.string().default("")
	},
	run: async (p, ctx) => {
		const subType = asString(p.sub_type, asString(p.type, "add"));
		await ctx.handleGroupRequest(p.flag, subType, p.approve, p.reason);
		return okResponse();
	}
})];
function register(h, ctx) {
	registerActions(h, ctx, actions);
}
//#endregion
//#region ../onebot/src/api-handler.ts
var moduleLog = createLogger("Bridge.Action");
var ApiHandler = class {
	handlers = /* @__PURE__ */ new Map();
	log;
	/** Debug-stream taps — notified after every handled action. Attached
	*  on-demand (ref-counted) by the WebUI debug stream. */
	observers = /* @__PURE__ */ new Set();
	/** Observe handled actions (debug). Returns an unsubscribe. */
	setObserver(cb) {
		this.observers.add(cb);
		return () => {
			this.observers.delete(cb);
		};
	}
	constructor(context, uin) {
		this.log = typeof uin === "number" && uin > 0 ? moduleLog.child({ uin }) : moduleLog;
		register$3(this, context);
		register$2(this, context);
		register$8(this, context);
		register$4(this, context);
		register$7(this, context);
		register$5(this, context);
		register(this, context);
		register$9(this, context);
		register$6(this, context);
		register$1(this, context);
	}
	registerAction(action, handler) {
		this.handlers.set(action, handler);
	}
	async handle(action, params) {
		const handler = this.handlers.get(action);
		if (!handler) {
			this.log.debug("unknown action %s", action);
			return failedResponse(RETCODE.UNKNOWN_ACTION, "unknown action");
		}
		if (getLogLevel() !== "trace") return this.runAction(action, handler, params);
		return runWithRequestId(nextRequestId(), () => this.runAction(action, handler, params));
	}
	async runAction(action, handler, params) {
		this.log.debug("%s params=%s", action, summarizeParams(params));
		this.log.trace(() => [`${action} ⇐ %s`, renderParamsVerbose(params)]);
		const startedAt = Date.now();
		let response;
		try {
			response = await handler(params);
			this.log.trace(() => [`${action} ⇒ ${response.status} (${Date.now() - startedAt}ms)`]);
		} catch (error) {
			this.log.warn("%s failed: %s\n%s", action, error instanceof Error ? error.message : String(error), error instanceof Error ? error.stack ?? "" : "");
			const message = error instanceof Error ? error.message : "internal error";
			response = failedResponse(RETCODE.INTERNAL_ERROR, message);
		}
		this.notifyObservers(action, params, response, Date.now() - startedAt);
		return response;
	}
	notifyObservers(action, params, response, ms) {
		if (!this.observers.size) return;
		for (const cb of this.observers) try {
			cb({
				action,
				params,
				response,
				ms
			});
		} catch (err) {
			this.log.warn("action observer error: %s", err instanceof Error ? err.message : String(err));
		}
	}
	async processRequest(rawRequest) {
		if (!rawRequest.trim()) return JSON.stringify(failedResponse(RETCODE.BAD_REQUEST, "bad request"));
		try {
			const parsed = JSON.parse(rawRequest);
			if (!isJsonObject(parsed)) return JSON.stringify(failedResponse(RETCODE.BAD_REQUEST, "bad request"));
			const action = asString(parsed.action);
			if (!action) return JSON.stringify(failedResponse(RETCODE.BAD_REQUEST, "bad request"));
			const params = isJsonObject(parsed.params) ? parsed.params : {};
			const echo = parsed.echo;
			const response = await this.handle(action, params);
			if (echo !== void 0) response.echo = toJsonValue(echo);
			return JSON.stringify(response);
		} catch {
			return JSON.stringify(failedResponse(RETCODE.BAD_REQUEST, "bad request"));
		}
	}
};
function isJsonObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function asString(value, fallback = "") {
	if (typeof value === "string") return value;
	if (typeof value === "number" || typeof value === "boolean") return String(value);
	return fallback;
}
function asNumber(value) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.trunc(value);
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) return Math.trunc(n);
	}
	return 0;
}
function toJsonValue(value) {
	if (value === null) return null;
	if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return value;
	if (Array.isArray(value)) return value.map(toJsonValue);
	if (isJsonObject(value)) {
		const obj = {};
		for (const [key, item] of Object.entries(value)) obj[key] = toJsonValue(item);
		return obj;
	}
	return String(value);
}
//#endregion
//#region ../websocket/src/native.ts
var __dirname = path.dirname(fileURLToPath(import.meta.url));
function platformBinaryName() {
	return `websocket-${process.platform}-${process.arch}.node`;
}
function searchDirs() {
	return [
		path.resolve(__dirname, "native"),
		path.resolve(__dirname, "..", "native"),
		path.resolve(__dirname, "..", "..", "runtime", "native"),
		path.resolve(process.cwd(), "native"),
		path.resolve(process.cwd(), "dist", "native"),
		path.resolve(process.cwd(), "packages", "runtime", "native")
	];
}
function resolveAddonPath() {
	const fileName = platformBinaryName();
	for (const dir of searchDirs()) {
		const full = path.join(dir, fileName);
		if (existsSync(full)) return full;
	}
	throw new Error(`[snowluma/websocket] native addon not found: ${fileName}. Searched: ${searchDirs().join(", ")}`);
}
function loadAddon() {
	const addonPath = resolveAddonPath();
	const mod = { exports: {} };
	process.dlopen(mod, addonPath);
	return mod.exports;
}
function createStubAddon(reason) {
	const fail = () => {
		throw new Error(`[snowluma/websocket] native addon is stubbed (${reason}). Set SNOWLUMA_DEV_NO_NATIVE=0 (or unset) and provide the prebuilt binary to enable WebSocket I/O.`);
	};
	class StubParser {
		constructor(_options) {}
		push(_chunk) {
			return fail();
		}
	}
	console.warn(`[snowluma/websocket] WARNING: using stub addon (${reason}). WebSocket features are disabled.`);
	return {
		Parser: StubParser,
		buildFrame: fail,
		computeAcceptKey: fail
	};
}
function tryLoad() {
	const devSkip = process.env.SNOWLUMA_DEV_NO_NATIVE === "1";
	try {
		return loadAddon();
	} catch (err) {
		if (devSkip) return createStubAddon(err.message);
		throw err;
	}
}
var addon = tryLoad();
//#endregion
//#region ../websocket/src/extensions.ts
var TRAILER = Buffer.from([
	0,
	0,
	255,
	255
]);
function parseHeader(header) {
	const offers = [];
	if (!header) return offers;
	for (const rawOffer of String(header).split(",")) {
		const parts = rawOffer.split(";").map((p) => p.trim()).filter(Boolean);
		if (parts.length === 0) continue;
		const name = parts.shift().toLowerCase();
		const params = Object.create(null);
		for (const part of parts) {
			const eq = part.indexOf("=");
			if (eq === -1) params[part.toLowerCase()] = true;
			else {
				const key = part.slice(0, eq).trim().toLowerCase();
				let value = part.slice(eq + 1).trim();
				if (value.startsWith("\"") && value.endsWith("\"") || value.startsWith("'") && value.endsWith("'")) value = value.slice(1, -1);
				params[key] = value;
			}
		}
		offers.push({
			name,
			params
		});
	}
	return offers;
}
function normalizePerMessageDeflateOptions(value) {
	if (value === void 0 || value === false || value === null) return null;
	if (value === true) return {
		clientNoContextTakeover: true,
		serverNoContextTakeover: true
	};
	if (typeof value === "object") return {
		clientNoContextTakeover: true,
		serverNoContextTakeover: true,
		...value
	};
	return {
		clientNoContextTakeover: true,
		serverNoContextTakeover: true
	};
}
function acceptPerMessageDeflate(requestHeader, options) {
	const config = normalizePerMessageDeflateOptions(options);
	if (!config) return null;
	const offer = parseHeader(requestHeader).find((item) => item.name === "permessage-deflate");
	if (!offer) return null;
	const responseParams = [];
	if (config.serverNoContextTakeover !== false || offer.params.server_no_context_takeover) responseParams.push("server_no_context_takeover");
	if (config.clientNoContextTakeover !== false || offer.params.client_no_context_takeover) responseParams.push("client_no_context_takeover");
	const accepted = {
		enabled: true,
		requestNoContextTakeover: responseParams.includes("client_no_context_takeover"),
		responseNoContextTakeover: responseParams.includes("server_no_context_takeover"),
		threshold: config.threshold ?? 1024
	};
	return {
		header: ["permessage-deflate", ...responseParams].join("; "),
		options: accepted
	};
}
function offerPerMessageDeflate(options) {
	const config = normalizePerMessageDeflateOptions(options);
	if (!config) return null;
	const params = ["permessage-deflate"];
	if (config.clientNoContextTakeover !== false) params.push("client_no_context_takeover");
	if (config.serverNoContextTakeover !== false) params.push("server_no_context_takeover");
	return params.join("; ");
}
function parseAcceptedPerMessageDeflate(responseHeader, requestedOptions) {
	const config = normalizePerMessageDeflateOptions(requestedOptions);
	if (!config) return null;
	const accepted = parseHeader(responseHeader).find((item) => item.name === "permessage-deflate");
	if (!accepted) return null;
	for (const key of Object.keys(accepted.params)) if (key !== "client_no_context_takeover" && key !== "server_no_context_takeover") throw new Error(`Unsupported permessage-deflate parameter: ${key}`);
	return {
		enabled: true,
		requestNoContextTakeover: !!accepted.params.server_no_context_takeover,
		responseNoContextTakeover: !!accepted.params.client_no_context_takeover,
		threshold: config.threshold ?? 1024
	};
}
function compressRaw(data) {
	const compressed = zlib.deflateRawSync(data, { flush: zlib.constants.Z_SYNC_FLUSH });
	if (compressed.length >= 4 && compressed.subarray(compressed.length - 4).equals(TRAILER)) return compressed.subarray(0, compressed.length - 4);
	return compressed;
}
function decompressRaw(data, maxPayload) {
	const inflated = zlib.inflateRawSync(Buffer.concat([data, TRAILER]), { finishFlush: zlib.constants.Z_SYNC_FLUSH });
	if (maxPayload !== void 0 && inflated.length > maxPayload) {
		const err = /* @__PURE__ */ new Error("Message too large after inflate");
		err.code = 1009;
		throw err;
	}
	return inflated;
}
function normalizeProtocolList(protocols) {
	if (!protocols) return [];
	if (typeof protocols === "string") return protocols.split(",").map((p) => p.trim()).filter(Boolean);
	if (Array.isArray(protocols)) return protocols.map(String).map((p) => p.trim()).filter(Boolean);
	if (protocols instanceof Set) return Array.from(protocols).map(String).map((p) => p.trim()).filter(Boolean);
	return [];
}
function chooseSubprotocol(requestHeader, protocols) {
	const requested = normalizeProtocolList(requestHeader);
	if (typeof protocols === "function") {
		const selected = protocols(requested);
		return selected && requested.includes(String(selected)) ? String(selected) : null;
	}
	const supported = normalizeProtocolList(protocols);
	if (requested.length === 0 || supported.length === 0) return null;
	for (const protocol of supported) if (requested.includes(protocol)) return protocol;
	return null;
}
var DEFAULT_MAX_PAYLOAD = 100 * 1024 * 1024;
function isValidCloseCode(code) {
	if (code === 1e3 || code === 1001 || code === 1002 || code === 1003 || code === 1007 || code === 1008 || code === 1009 || code === 1010 || code === 1011) return true;
	if (code >= 3e3 && code <= 4999) return true;
	return false;
}
function encodeClosePayload(code, reason) {
	const reasonBuf = reason ? Buffer.from(String(reason), "utf8") : Buffer.alloc(0);
	if (code === void 0 || code === null) {
		if (reasonBuf.length > 0) throw new Error("Cannot send close reason without a code");
		return Buffer.alloc(0);
	}
	const buf = Buffer.allocUnsafe(2 + reasonBuf.length);
	buf.writeUInt16BE(code & 65535, 0);
	reasonBuf.copy(buf, 2);
	return buf;
}
var Utf8Validator = class {
	state = 0;
	codepoint = 0;
	minNext = 0;
	push(buf) {
		for (let i = 0; i < buf.length; i++) {
			const b = buf[i];
			if (this.state === 0) {
				if ((b & 128) === 0) continue;
				if ((b & 224) === 192) {
					if (b < 194) return false;
					this.codepoint = b & 31;
					this.state = 1;
					this.minNext = 128;
				} else if ((b & 240) === 224) {
					this.codepoint = b & 15;
					this.state = 2;
					this.minNext = b === 224 ? 160 : 128;
				} else if ((b & 248) === 240) {
					if (b > 244) return false;
					this.codepoint = b & 7;
					this.state = 3;
					this.minNext = b === 240 ? 144 : 128;
				} else return false;
			} else {
				if (b < this.minNext || b > 191) return false;
				if (this.state === 2 && this.codepoint === 13 && b >= 160) return false;
				this.codepoint = this.codepoint << 6 | b & 63;
				this.state--;
				this.minNext = 128;
			}
		}
		return true;
	}
	done() {
		return this.state === 0;
	}
};
function randomMaskKey() {
	const b = Buffer.allocUnsafe(4);
	crypto$1.randomFillSync(b);
	return b;
}
var WebSocket$1 = class extends EventEmitter {
	_socket;
	_isServer;
	_maxPayload;
	_readyState;
	_perMessageDeflate;
	protocol;
	extensions;
	_parser;
	_msgOpcode = 0;
	_msgChunks = [];
	_msgSize = 0;
	_msgValidator = null;
	_msgCompressed = false;
	_closeCodeSent = null;
	_closeCodeReceived = null;
	_closeReasonReceived = "";
	_closeFrameSent = false;
	_closeTimer = null;
	static CONNECTING = 0;
	static OPEN = 1;
	static CLOSING = 2;
	static CLOSED = 3;
	constructor(socket, options) {
		super();
		options = options || {};
		this._socket = socket;
		this._isServer = !!options.isServer;
		this._maxPayload = options.maxPayload ?? DEFAULT_MAX_PAYLOAD;
		this._readyState = options.readyState ?? 1;
		this._perMessageDeflate = options.extensions?.perMessageDeflate;
		this.protocol = options.protocol || "";
		this.extensions = this._perMessageDeflate ? "permessage-deflate" : "";
		this._parser = new addon.Parser({
			isServer: this._isServer,
			maxPayload: this._maxPayload,
			allowedRsv: this._perMessageDeflate ? 64 : 0
		});
		this._bindSocket();
	}
	get readyState() {
		return this._readyState;
	}
	get isServer() {
		return this._isServer;
	}
	_bindSocket() {
		const sock = this._socket;
		sock.on("data", (chunk) => this._onData(chunk));
		sock.on("end", () => this._onEnd());
		sock.on("close", () => this._onSocketClose());
		sock.on("error", (err) => this._onError(err));
	}
	/** @internal */
	_onData(chunk) {
		if (this._readyState === 3) return;
		const res = this._parser.push(chunk);
		if (res.error) {
			this._failConnection(res.code || 1002, res.message || "Protocol error");
			return;
		}
		for (const f of res.frames) {
			this._handleFrame(f);
			if (this._readyState === 3) return;
		}
	}
	_onEnd() {
		if (this._readyState !== 3) {
			if (this._closeCodeReceived === null) {
				this._closeCodeReceived = 1006;
				this._closeReasonReceived = "";
			}
			this._destroySocket();
		}
	}
	_onSocketClose() {
		if (this._readyState === 3) return;
		if (this._closeCodeReceived === null) this._closeCodeReceived = 1006;
		this._readyState = 3;
		if (this._closeTimer) {
			clearTimeout(this._closeTimer);
			this._closeTimer = null;
		}
		this.emit("close", this._closeCodeReceived, this._closeReasonReceived);
	}
	_onError(err) {
		this.emit("error", err);
	}
	_handleFrame(f) {
		const { fin, opcode, payload } = f;
		const rsv = f.rsv ?? 0;
		if (opcode === 9) {
			this.emit("ping", payload);
			if (this._readyState === 1) this._sendControl(10, payload);
			return;
		}
		if (opcode === 10) {
			this.emit("pong", payload);
			return;
		}
		if (opcode === 8) {
			this._handleCloseFrame(payload);
			return;
		}
		if (opcode === 1 || opcode === 2) {
			if (this._msgOpcode !== 0) {
				this._failConnection(1002, "New data frame started before previous fragmented message finished");
				return;
			}
			if (rsv & 64 && !this._perMessageDeflate) {
				this._failConnection(1002, "Compressed frame without negotiated permessage-deflate");
				return;
			}
			this._msgOpcode = opcode;
			this._msgChunks = [];
			this._msgSize = 0;
			this._msgCompressed = (rsv & 64) !== 0;
			this._msgValidator = opcode === 1 ? new Utf8Validator() : null;
		} else if (opcode === 0) {
			if (this._msgOpcode === 0) {
				this._failConnection(1002, "Continuation frame without active message");
				return;
			}
			if (rsv !== 0) {
				this._failConnection(1002, "RSV bits set on continuation frame");
				return;
			}
		}
		this._msgSize += payload.length;
		if (this._msgSize > this._maxPayload) {
			this._failConnection(1009, "Message too large");
			return;
		}
		if (payload.length > 0) this._msgChunks.push(payload);
		if (fin) {
			let data = this._msgChunks.length === 1 ? this._msgChunks[0] : Buffer.concat(this._msgChunks, this._msgSize);
			if (this._msgCompressed) try {
				data = decompressRaw(data, this._maxPayload);
			} catch (err) {
				const e = err;
				this._failConnection(e.code || 1007, e.message || "Invalid compressed payload");
				return;
			}
			if (this._msgValidator) {
				if (!this._msgValidator.push(data) || !this._msgValidator.done()) {
					this._failConnection(1007, "Invalid UTF-8");
					return;
				}
			}
			const isBinary = this._msgOpcode === 2;
			this._msgOpcode = 0;
			this._msgChunks = [];
			this._msgSize = 0;
			this._msgValidator = null;
			this._msgCompressed = false;
			this.emit("message", data, isBinary);
		}
	}
	_handleCloseFrame(payload) {
		let code = 1005;
		let reason = "";
		if (payload.length === 1) {
			this._failConnection(1002, "Close payload length 1");
			return;
		}
		if (payload.length >= 2) {
			code = payload.readUInt16BE(0);
			if (!isValidCloseCode(code)) {
				this._failConnection(1002, "Invalid close code");
				return;
			}
			if (payload.length > 2) try {
				reason = new TextDecoder("utf-8", { fatal: true }).decode(payload.subarray(2));
			} catch {
				this._failConnection(1007, "Invalid UTF-8 in close reason");
				return;
			}
		}
		this._closeCodeReceived = code;
		this._closeReasonReceived = reason;
		if (this._readyState === 1) {
			this._readyState = 2;
			const echo = encodeClosePayload(code === 1005 ? void 0 : code, "");
			this._sendControl(8, echo);
			this._closeFrameSent = true;
			this._endSocketSoon();
		} else if (this._readyState === 2) this._endSocketSoon();
	}
	_endSocketSoon() {
		try {
			this._socket.end();
		} catch {}
		if (this._closeTimer) clearTimeout(this._closeTimer);
		this._closeTimer = setTimeout(() => this._destroySocket(), 3e4);
		this._closeTimer.unref?.();
	}
	_destroySocket() {
		try {
			this._socket.destroy();
		} catch {}
	}
	_failConnection(code, reason) {
		if (this._readyState === 3) return;
		const payload = encodeClosePayload(code, reason);
		let frame = null;
		try {
			frame = addon.buildFrame(8, true, payload, this._isServer ? null : randomMaskKey(), 0);
		} catch {}
		this._closeCodeSent = code;
		this._readyState = 2;
		const err = /* @__PURE__ */ new Error(`WebSocket protocol error: ${reason}`);
		err.code = code;
		this.emit("error", err);
		try {
			if (frame) this._socket.end(frame);
			else this._socket.end();
		} catch {}
		if (this._closeTimer) clearTimeout(this._closeTimer);
		this._closeTimer = setTimeout(() => this._destroySocket(), 2e3);
		this._closeTimer.unref?.();
	}
	_sendControl(opcode, payload) {
		const data = payload ?? Buffer.alloc(0);
		const frame = addon.buildFrame(opcode, true, data, this._isServer ? null : randomMaskKey(), 0);
		this._socket.write(frame);
	}
	send(data, options, cb) {
		if (typeof options === "function") {
			cb = options;
			options = void 0;
		}
		const opts = options || {};
		if (this._readyState !== 1) {
			const err = /* @__PURE__ */ new Error("WebSocket is not open");
			if (cb) {
				cb(err);
				return;
			}
			throw err;
		}
		let payload;
		let opcode;
		if (typeof data === "string") {
			payload = Buffer.from(data, "utf8");
			opcode = opts.binary ? 2 : 1;
		} else if (Buffer.isBuffer(data)) {
			payload = data;
			opcode = opts.binary === false ? 1 : 2;
		} else if (data instanceof Uint8Array) {
			payload = Buffer.from(data.buffer, data.byteOffset, data.byteLength);
			opcode = opts.binary === false ? 1 : 2;
		} else if (data instanceof ArrayBuffer) {
			payload = Buffer.from(data);
			opcode = opts.binary === false ? 1 : 2;
		} else {
			const err = /* @__PURE__ */ new TypeError("Unsupported data type for send()");
			if (cb) {
				cb(err);
				return;
			}
			throw err;
		}
		let rsv = 0;
		if (this._perMessageDeflate && opts.compress !== false && payload.length >= (this._perMessageDeflate.threshold ?? 1024)) {
			payload = compressRaw(payload);
			rsv = 64;
		}
		const maskKey = this._isServer ? null : randomMaskKey();
		const frame = addon.buildFrame(opcode, true, payload, maskKey, rsv);
		this._socket.write(frame, cb);
	}
	ping(data, _mask, cb) {
		if (typeof data === "function") {
			cb = data;
			data = void 0;
		}
		const payload = data ? Buffer.isBuffer(data) ? data : Buffer.from(String(data), "utf8") : Buffer.alloc(0);
		if (payload.length > 125) throw new Error("Ping payload must be <=125 bytes");
		if (this._readyState !== 1) {
			const err = /* @__PURE__ */ new Error("WebSocket is not open");
			if (cb) {
				cb(err);
				return;
			}
			throw err;
		}
		const maskKey = this._isServer ? null : randomMaskKey();
		const frame = addon.buildFrame(9, true, payload, maskKey, 0);
		this._socket.write(frame, cb);
	}
	pong(data, _mask, cb) {
		if (typeof data === "function") {
			cb = data;
			data = void 0;
		}
		const payload = data ? Buffer.isBuffer(data) ? data : Buffer.from(String(data), "utf8") : Buffer.alloc(0);
		if (payload.length > 125) throw new Error("Pong payload must be <=125 bytes");
		if (this._readyState !== 1) {
			const err = /* @__PURE__ */ new Error("WebSocket is not open");
			if (cb) {
				cb(err);
				return;
			}
			throw err;
		}
		const maskKey = this._isServer ? null : randomMaskKey();
		const frame = addon.buildFrame(10, true, payload, maskKey, 0);
		this._socket.write(frame, cb);
	}
	close(code, reason) {
		if (this._readyState === 3 || this._readyState === 2) return;
		if (code !== void 0 && !isValidCloseCode(code)) throw new RangeError(`Invalid close code: ${code}`);
		if ((reason ? Buffer.from(String(reason), "utf8") : Buffer.alloc(0)).length > 123) throw new RangeError("Close reason must be <=123 bytes");
		const payload = encodeClosePayload(code, reason);
		const maskKey = this._isServer ? null : randomMaskKey();
		const frame = addon.buildFrame(8, true, payload, maskKey, 0);
		this._readyState = 2;
		this._closeCodeSent = code ?? null;
		this._socket.write(frame);
		this._closeFrameSent = true;
		this._endSocketSoon();
	}
	terminate() {
		this._readyState = 2;
		this._destroySocket();
	}
};
//#endregion
//#region ../websocket/src/server.ts
function computeAccept(key) {
	return addon.computeAcceptKey(key);
}
function abortUpgrade(socket, status, message) {
	try {
		const body = message ? message : http.STATUS_CODES[status] || "";
		const head = `HTTP/1.1 ${status} ${http.STATUS_CODES[status] || "Error"}\r\nConnection: close\r
Content-Length: ${Buffer.byteLength(body)}\r\nContent-Type: text/plain\r
\r
`;
		socket.write(head + body);
	} catch {}
	try {
		socket.destroy();
	} catch {}
}
var TLS_OPTION_KEYS = [
	"ALPNProtocols",
	"SNICallback",
	"ca",
	"cert",
	"ciphers",
	"clientCertEngine",
	"crl",
	"dhparam",
	"ecdhCurve",
	"honorCipherOrder",
	"key",
	"maxVersion",
	"minVersion",
	"passphrase",
	"pfx",
	"privateKeyEngine",
	"privateKeyIdentifier",
	"requestCert",
	"rejectUnauthorized",
	"secureOptions",
	"secureProtocol",
	"sessionIdContext",
	"sigalgs",
	"ticketKeys"
];
function getTlsOptions(options) {
	const tlsOptions = {};
	for (const key of TLS_OPTION_KEYS) if (options[key] !== void 0) tlsOptions[key] = options[key];
	if (options.tls && typeof options.tls === "object") Object.assign(tlsOptions, options.tls);
	return tlsOptions;
}
var WebSocketServer = class extends EventEmitter {
	options;
	clients = /* @__PURE__ */ new Set();
	_server = null;
	_externalServer = null;
	_upgradeHandler = null;
	constructor(options) {
		super();
		options = options || {};
		this.options = {
			port: options.port,
			host: options.host,
			server: options.server,
			noServer: !!options.noServer,
			path: options.path,
			maxPayload: options.maxPayload,
			verifyClient: options.verifyClient,
			protocols: options.protocols,
			perMessageDeflate: options.perMessageDeflate,
			backlog: options.backlog,
			tls: options.tls
		};
		const tlsOptions = getTlsOptions(options);
		this.options.tls = Object.keys(tlsOptions).length > 0 ? tlsOptions : void 0;
		if (this.options.noServer) return;
		if (this.options.server) {
			this._externalServer = this.options.server;
			this._attachToServer(this._externalServer);
		} else if (this.options.port !== void 0) {
			const requestHandler = (_req, res) => {
				const body = http.STATUS_CODES[426] ?? "";
				res.writeHead(426, {
					"Content-Length": Buffer.byteLength(body),
					"Content-Type": "text/plain"
				});
				res.end(body);
			};
			this._server = this.options.tls ? https.createServer(this.options.tls, requestHandler) : http.createServer(requestHandler);
			this._attachToServer(this._server);
			this._server.listen(this.options.port, this.options.host, this.options.backlog, () => this.emit("listening"));
			this._server.on("error", (err) => this.emit("error", err));
		} else throw new Error("WebSocketServer requires { port } or { server } or { noServer: true }");
	}
	address() {
		if (this._server) return this._server.address();
		if (this._externalServer && this._externalServer.address) return this._externalServer.address();
		return null;
	}
	_attachToServer(server) {
		const handler = (req, socket, head) => {
			if (this.options.path) {
				if ((req.url ?? "/").split("?")[0] !== this.options.path) {
					if (server.listenerCount("upgrade") === 1) abortUpgrade(socket, 400, "Bad path for WebSocket");
					return;
				}
			}
			this.handleUpgrade(req, socket, head, (ws) => {
				this.emit("connection", ws, req);
			});
		};
		this._upgradeHandler = handler;
		server.on("upgrade", handler);
	}
	handleUpgrade(request, socket, head, cb) {
		const upgrade = (request.headers["upgrade"] ?? "").toLowerCase();
		const connection = (Array.isArray(request.headers["connection"]) ? request.headers["connection"].join(",") : request.headers["connection"] ?? "").toLowerCase();
		const version = request.headers["sec-websocket-version"];
		const key = request.headers["sec-websocket-key"];
		if (request.method !== "GET") return abortUpgrade(socket, 405, "Method not allowed");
		if (upgrade !== "websocket") return abortUpgrade(socket, 400, "Upgrade header must be websocket");
		if (!/\bupgrade\b/i.test(connection)) return abortUpgrade(socket, 400, "Connection header must contain \"upgrade\"");
		if (version !== "13") {
			try {
				socket.write("HTTP/1.1 426 Upgrade Required\r\nSec-WebSocket-Version: 13\r\nConnection: close\r\n\r\n");
			} catch {}
			try {
				socket.destroy();
			} catch {}
			return;
		}
		if (typeof key !== "string" || !/^[+/0-9A-Za-z]{22}==$/.test(key)) return abortUpgrade(socket, 400, "Invalid Sec-WebSocket-Key");
		const doAccept = () => {
			const accept = computeAccept(key);
			const extension = acceptPerMessageDeflate(request.headers["sec-websocket-extensions"], this.options.perMessageDeflate);
			const protocol = chooseSubprotocol(request.headers["sec-websocket-protocol"], this.options.protocols);
			const responseHeaders = [
				"HTTP/1.1 101 Switching Protocols",
				"Upgrade: websocket",
				"Connection: Upgrade",
				`Sec-WebSocket-Accept: ${accept}`
			];
			if (extension) responseHeaders.push(`Sec-WebSocket-Extensions: ${extension.header}`);
			if (protocol) responseHeaders.push(`Sec-WebSocket-Protocol: ${protocol}`);
			try {
				socket.write(responseHeaders.join("\r\n") + "\r\n\r\n");
			} catch {
				try {
					socket.destroy();
				} catch {}
				return;
			}
			const ns = socket;
			ns.setTimeout?.(0);
			ns.setNoDelay?.(true);
			const ws = new WebSocket$1(socket, {
				isServer: true,
				maxPayload: this.options.maxPayload,
				extensions: extension ? { perMessageDeflate: extension.options } : void 0,
				protocol: protocol ?? "",
				readyState: 1
			});
			this.clients.add(ws);
			ws.on("close", () => this.clients.delete(ws));
			if (head && head.length > 0) ws._onData(head);
			cb(ws, request);
		};
		const verify = this.options.verifyClient;
		if (typeof verify === "function") {
			const info = {
				origin: request.headers["origin"],
				secure: !!socket.encrypted,
				req: request
			};
			if (verify.length >= 2) verify(info, (allow, code, message) => {
				if (!allow) return abortUpgrade(socket, code || 401, message);
				doAccept();
			});
			else {
				if (!verify(info)) return abortUpgrade(socket, 401, "Unauthorized");
				doAccept();
			}
		} else doAccept();
	}
	close(cb) {
		if (this._externalServer && this._upgradeHandler) {
			this._externalServer.removeListener("upgrade", this._upgradeHandler);
			this._upgradeHandler = null;
		}
		for (const ws of this.clients) try {
			ws.close(1001, "Server shutting down");
		} catch {}
		if (this._server) this._server.close((err) => cb && cb(err));
		else if (cb) setImmediate(cb);
	}
};
//#endregion
//#region ../websocket/src/client.ts
function parseHeaders(headerBlock) {
	const lines = headerBlock.split("\r\n");
	const status = lines.shift();
	const m = /^HTTP\/1\.1\s+(\d+)\s*(.*)$/.exec(status);
	if (!m) throw new Error("Bad HTTP status line: " + status);
	const headers = Object.create(null);
	for (const line of lines) {
		if (!line) continue;
		const idx = line.indexOf(":");
		if (idx < 0) continue;
		const k = line.slice(0, idx).trim().toLowerCase();
		headers[k] = line.slice(idx + 1).trim();
	}
	return {
		statusCode: Number(m[1]),
		statusMessage: m[2] ?? "",
		headers
	};
}
var WebSocketClient = class extends EventEmitter {
	static CONNECTING = 0;
	static OPEN = 1;
	static CLOSING = 2;
	static CLOSED = 3;
	static Server;
	_url;
	_secure;
	_readyState;
	_maxPayload;
	_ws = null;
	_pendingQueue = [];
	_perMessageDeflate;
	_protocols;
	protocol = "";
	extensions = "";
	_socket;
	_handshakeBuf = Buffer.alloc(0);
	_wsKey;
	_expectedAccept;
	constructor(address, protocols, options) {
		super();
		if (typeof protocols === "object" && !Array.isArray(protocols) && protocols !== null) {
			options = protocols;
			protocols = void 0;
		}
		options = options || {};
		this._url = new URL$1(address);
		if (this._url.protocol !== "ws:" && this._url.protocol !== "wss:") throw new Error("Only ws: and wss: URLs are supported");
		this._secure = this._url.protocol === "wss:";
		this._readyState = 0;
		this._maxPayload = options.maxPayload;
		this._perMessageDeflate = options.perMessageDeflate;
		this._protocols = Array.isArray(protocols) ? protocols.map(String) : typeof protocols === "string" ? [protocols] : void 0;
		const host = this._url.hostname;
		const port = this._url.port ? Number(this._url.port) : this._secure ? 443 : 80;
		const keyBytes = crypto$1.randomBytes(16);
		this._wsKey = keyBytes.toString("base64");
		this._expectedAccept = addon.computeAcceptKey(this._wsKey);
		const connectOpts = {
			host,
			port,
			...options.socketOptions || {}
		};
		const onConnect = () => {
			const pathAndQuery = (this._url.pathname || "/") + (this._url.search || "");
			const hostHeader = this._url.port && Number(this._url.port) !== (this._secure ? 443 : 80) ? `${host}:${this._url.port}` : host;
			const reqLines = [
				`GET ${pathAndQuery} HTTP/1.1`,
				`Host: ${hostHeader}`,
				"Upgrade: websocket",
				"Connection: Upgrade",
				`Sec-WebSocket-Key: ${this._wsKey}`,
				"Sec-WebSocket-Version: 13"
			];
			if (this._protocols && this._protocols.length > 0) reqLines.push(`Sec-WebSocket-Protocol: ${this._protocols.join(", ")}`);
			const extensionOffer = offerPerMessageDeflate(this._perMessageDeflate);
			if (extensionOffer) reqLines.push(`Sec-WebSocket-Extensions: ${extensionOffer}`);
			if (options.headers) for (const [k, v] of Object.entries(options.headers)) reqLines.push(`${k}: ${v}`);
			reqLines.push("", "");
			this._socket.write(reqLines.join("\r\n"));
		};
		if (this._secure && connectOpts.servername === void 0 && net.isIP(host) === 0) connectOpts.servername = host;
		this._socket = this._secure ? tls.connect(connectOpts, onConnect) : net.connect(connectOpts, onConnect);
		this._socket.setNoDelay?.(true);
		this._socket.on("data", (chunk) => this._onHandshakeData(chunk));
		this._socket.on("error", (err) => this._onEarlyError(err));
		this._socket.on("close", () => this._onEarlyClose());
	}
	get readyState() {
		return this._ws ? this._ws.readyState : this._readyState;
	}
	_onHandshakeData(chunk) {
		this._handshakeBuf = Buffer.concat([this._handshakeBuf, chunk]);
		const idx = this._handshakeBuf.indexOf("\r\n\r\n");
		if (idx < 0) {
			if (this._handshakeBuf.length > 16384) this._abort("Handshake response too large");
			return;
		}
		const headBlock = this._handshakeBuf.slice(0, idx).toString("latin1");
		const rest = this._handshakeBuf.slice(idx + 4);
		let parsed;
		try {
			parsed = parseHeaders(headBlock);
		} catch (e) {
			return this._abort(e.message);
		}
		if (parsed.statusCode !== 101) return this._abort(`Unexpected response status ${parsed.statusCode}`);
		if ((parsed.headers["upgrade"] || "").toLowerCase() !== "websocket") return this._abort("Missing/invalid Upgrade header");
		if (!/\bupgrade\b/i.test(parsed.headers["connection"] || "")) return this._abort("Missing Connection: Upgrade header");
		if (parsed.headers["sec-websocket-accept"] !== this._expectedAccept) return this._abort("Invalid Sec-WebSocket-Accept");
		let acceptedExtensions;
		try {
			acceptedExtensions = parseAcceptedPerMessageDeflate(parsed.headers["sec-websocket-extensions"], this._perMessageDeflate);
		} catch (e) {
			return this._abort(e.message);
		}
		if (parsed.headers["sec-websocket-extensions"] && !acceptedExtensions) return this._abort("Unexpected Sec-WebSocket-Extensions");
		const protocol = parsed.headers["sec-websocket-protocol"] || "";
		if (protocol && (!this._protocols || !this._protocols.includes(protocol))) return this._abort("Unexpected Sec-WebSocket-Protocol");
		this._socket.removeAllListeners("data");
		this._socket.removeAllListeners("error");
		this._socket.removeAllListeners("close");
		this._readyState = 1;
		this._ws = new WebSocket$1(this._socket, {
			isServer: false,
			maxPayload: this._maxPayload,
			extensions: acceptedExtensions ? { perMessageDeflate: acceptedExtensions } : void 0,
			protocol,
			readyState: 1
		});
		this.protocol = protocol;
		this.extensions = acceptedExtensions ? "permessage-deflate" : "";
		this._ws.on("message", (d, isBinary) => this.emit("message", d, isBinary));
		this._ws.on("ping", (d) => this.emit("ping", d));
		this._ws.on("pong", (d) => this.emit("pong", d));
		this._ws.on("close", (c, r) => this.emit("close", c, r));
		this._ws.on("error", (e) => this.emit("error", e));
		this.emit("upgrade", parsed);
		this.emit("open");
		if (rest.length > 0) this._ws._onData(rest);
		for (const entry of this._pendingQueue) this._ws.send(entry.data, entry.options, entry.cb);
		this._pendingQueue = [];
	}
	_onEarlyError(err) {
		this.emit("error", err);
	}
	_onEarlyClose() {
		if (!this._ws) {
			this._readyState = 3;
			this.emit("close", 1006, "");
		}
	}
	_abort(msg) {
		const err = /* @__PURE__ */ new Error("WebSocket handshake failed: " + msg);
		try {
			this._socket.destroy();
		} catch {}
		this.emit("error", err);
		this._readyState = 3;
		this.emit("close", 1006, "");
	}
	send(data, options, cb) {
		if (this._ws) return this._ws.send(data, options, cb);
		if (typeof options === "function") {
			cb = options;
			options = void 0;
		}
		this._pendingQueue.push({
			data,
			options,
			cb
		});
	}
	ping(data, mask, cb) {
		this._ws?.ping(data, mask, cb);
	}
	pong(data, mask, cb) {
		this._ws?.pong(data, mask, cb);
	}
	close(code, reason) {
		if (code !== void 0 && !isValidCloseCode(code)) throw new RangeError(`Invalid close code: ${code}`);
		if (this._ws) return this._ws.close(code, reason);
		try {
			this._socket.destroy();
		} catch {}
	}
	terminate() {
		if (this._ws) return this._ws.terminate();
		try {
			this._socket.destroy();
		} catch {}
	}
};
//#endregion
//#region ../websocket/src/index.ts
WebSocketClient.Server = WebSocketServer;
var WebSocket = WebSocketClient;
//#endregion
//#region ../common/src/coerce.ts
/** True only for a plain, non-null, non-array object. */
function isObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
/** The value when it is a real boolean, else the fallback. Strings/numbers
*  are NOT coerced — `'true'` and `1` both yield the fallback. */
function boolOr(value, fallback) {
	return typeof value === "boolean" ? value : fallback;
}
/** A finite number (numeric strings coerced) clamped to `[min, max]`, else
*  the fallback. Fractional precision is preserved — use `clampInt` to floor. */
function clampNum(value, min, max, fallback) {
	const n = typeof value === "number" ? value : typeof value === "string" ? Number(value) : NaN;
	if (!Number.isFinite(n)) return fallback;
	return Math.min(max, Math.max(min, n));
}
/** `clampNum` truncated toward zero — clamp first, then drop the fraction. */
function clampInt(value, min, max, fallback) {
	return Math.trunc(clampNum(value, min, max, fallback));
}
//#endregion
//#region src/notifications/config.ts
var log = createLogger("Notifications.Config");
var CONFIG_DIR = "config";
var NOTIFICATIONS_CONFIG_PATH = path$1.join(CONFIG_DIR, "notifications.json");
var DEBOUNCE_SECONDS_MAX = 3600;
/** A channel id is a slug: it is referenced by per-UIN `channelIds`, so it must
*  be safe to use as a stable key. Kept in sync with `normalizeChannelIds` in
*  packages/onebot/src/config.ts (cross-package; can't share without a circular
*  dep — core depends on onebot, not the reverse). */
var CHANNEL_ID_RE = /^[\w.-]+$/;
var CHANNEL_ID_MAX = 64;
var CHANNEL_NAME_MAX = 128;
var BODY_TEMPLATE_MAX = 8192;
/** Default body template — Server酱-style JSON ({title}/{desp}). The WebUI
*  ships additional per-vendor presets (钉钉/Discord/…) as frontend constants
*  the operator can drop in. */
var DEFAULT_BODY_TEMPLATE = `{
  "title": "账号状态通知：{event}",
  "desp": "您的账号状态发生了改变。\\n\\n**昵称**：{nickname}\\n**QQ号**：{uin}\\n**当前状态**：{event}\\n**时间**：{time}"
}`;
function defaultNotificationsConfig() {
	return {
		version: 1,
		debounceSeconds: 30,
		channels: []
	};
}
/**
* Mechanical `{key}` substitution — no logic, no conditionals, no escaping.
* A key present in `vars` is replaced by its value; an unknown `{key}` is left
* untouched (原样) so a typo'd placeholder is visible rather than silently
* blanked. Pure + total (a non-string template yields '').
*
* **JSON safety**: When the template is valid JSON (parseable by JSON.parse),
* values are escaped to prevent breaking the JSON structure — backslashes
* become `\\` and double-quotes become `\"`.
*/
function renderTemplate(template, vars) {
	if (typeof template !== "string") return "";
	let isJson = false;
	try {
		JSON.parse(template);
		isJson = true;
	} catch {}
	return template.replace(/\{(\w+)\}/g, (match, key) => {
		if (!Object.prototype.hasOwnProperty.call(vars, key)) return match;
		const val = vars[key];
		return isJson ? val.replace(/\\/g, "\\\\").replace(/"/g, "\\\"") : val;
	});
}
function strOr(value, fallback, maxLen) {
	return typeof value === "string" ? value.slice(0, maxLen) : fallback;
}
function normalizeChannelId(value) {
	if (typeof value !== "string") return null;
	const v = value.trim();
	if (v.length === 0 || v.length > CHANNEL_ID_MAX) return null;
	if (!CHANNEL_ID_RE.test(v)) return null;
	return v;
}
function isHttpUrl(value) {
	try {
		const u = new URL(value);
		return u.protocol === "http:" || u.protocol === "https:";
	} catch {
		return false;
	}
}
/** A channel is usable only with a valid id AND an http(s) target — anything
*  else is unusable, so the whole entry is dropped (total normalize). */
function normalizeChannel(raw) {
	if (!isObject(raw)) return null;
	const id = normalizeChannelId(raw.id);
	if (!id) return null;
	const url = typeof raw.url === "string" ? raw.url.trim() : "";
	if (!isHttpUrl(url)) return null;
	return {
		id,
		name: strOr(raw.name, id, CHANNEL_NAME_MAX).trim() || id,
		url,
		bodyTemplate: strOr(raw.bodyTemplate, DEFAULT_BODY_TEMPLATE, BODY_TEMPLATE_MAX),
		enabled: boolOr(raw.enabled, true)
	};
}
function normalizeChannels(value) {
	if (!Array.isArray(value)) return [];
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const raw of value) {
		const ch = normalizeChannel(raw);
		if (!ch) continue;
		if (seen.has(ch.id)) continue;
		seen.add(ch.id);
		out.push(ch);
	}
	return out;
}
function normalizeNotificationsConfig(value) {
	const v = isObject(value) ? value : {};
	return {
		version: 1,
		debounceSeconds: clampInt(v.debounceSeconds, 0, DEBOUNCE_SECONDS_MAX, 30),
		channels: normalizeChannels(v.channels)
	};
}
function ensureConfigDir() {
	fs$1.mkdirSync(CONFIG_DIR, { recursive: true });
}
function atomicWrite(config) {
	ensureConfigDir();
	const tmp = NOTIFICATIONS_CONFIG_PATH + ".tmp";
	fs$1.writeFileSync(tmp, JSON.stringify(config, null, 2), "utf8");
	fs$1.renameSync(tmp, NOTIFICATIONS_CONFIG_PATH);
}
var cached = null;
/** Load + normalize the channel store, creating it from defaults if absent. */
function loadNotificationsConfig() {
	if (cached) return cached;
	ensureConfigDir();
	if (!fs$1.existsSync(NOTIFICATIONS_CONFIG_PATH)) {
		const fresh = defaultNotificationsConfig();
		try {
			atomicWrite(fresh);
		} catch (err) {
			log.warn("failed to write initial notifications.json: %s", err instanceof Error ? err.message : String(err));
		}
		cached = fresh;
		return fresh;
	}
	try {
		const raw = fs$1.readFileSync(NOTIFICATIONS_CONFIG_PATH, "utf8");
		const parsed = JSON.parse(raw);
		const normalized = normalizeNotificationsConfig(parsed);
		if (JSON.stringify(parsed) !== JSON.stringify(normalized)) try {
			atomicWrite(normalized);
		} catch {}
		cached = normalized;
		return normalized;
	} catch (err) {
		log.warn("notifications.json unreadable; using defaults: %s", err instanceof Error ? err.message : String(err));
		const fresh = defaultNotificationsConfig();
		cached = fresh;
		return fresh;
	}
}
/**
* Persist a (possibly partial) client-supplied config. A missing `channels` or
* `debounceSeconds` keeps the current on-disk value — section-level merge, same
* as `saveUiConfig`. Returns the stored, normalized config.
*/
function saveNotificationsConfig(incoming) {
	const current = loadNotificationsConfig();
	const v = isObject(incoming) ? incoming : {};
	const next = {
		version: 1,
		debounceSeconds: v.debounceSeconds !== void 0 ? clampInt(v.debounceSeconds, 0, DEBOUNCE_SECONDS_MAX, 30) : current.debounceSeconds,
		channels: Array.isArray(v.channels) ? normalizeChannels(v.channels) : current.channels
	};
	atomicWrite(next);
	cached = next;
	return next;
}
//#endregion
export { readRuntimeConfig as A, nextRequestId as B, actions$7 as C, loadOneBotConfig as D, renderParamsVerbose as E, createLogger as F, getLogLevel as I, getRecentLogs as L, updateRuntimeConfig as M, LOG_LEVELS as N, saveOneBotConfig as O, closeLogger as P, setLogLevel as R, actions$6 as S, actions$9 as T, runWithRequestId as V, getHonorListWebAPI as _, clampInt as a, getBknFromCookie as b, WebSocket as c, actions as d, actions$1 as f, WebHonorType as g, actions$4 as h, boolOr as i, resolveRuntimeEnvOverrides as j, loadRuntimeConfig as k, WebSocketServer as l, actions$3 as m, renderTemplate as n, clampNum as o, actions$2 as p, saveNotificationsConfig as r, isObject as s, loadNotificationsConfig as t, ApiHandler as u, RequestUtil as v, actions$8 as w, actions$5 as x, cookieToString as y, subscribeLogs as z };
