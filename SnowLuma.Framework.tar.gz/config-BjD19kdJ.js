import fs from "fs";
import path from "path";
//#region src/onebot/config.ts
var CONFIG_DIR = "config";
var DEFAULT_CONFIG_PATH = path.join(CONFIG_DIR, "onebot.json");
function makeDefaultOneBotConfig() {
	return {
		httpServers: [{
			host: "0.0.0.0",
			port: 3e3,
			path: "/"
		}],
		httpPostEndpoints: [],
		wsServers: [{
			host: "0.0.0.0",
			port: 3001
		}],
		wsClients: [],
		musicSignUrl: ""
	};
}
function loadOneBotConfig(uin) {
	ensureConfigDir();
	const merged = deepClone(toJsonObject(makeDefaultOneBotConfig()));
	const globalConfig = tryLoadJson(DEFAULT_CONFIG_PATH);
	if (globalConfig) deepMerge(merged, globalConfig);
	const perUinPath = path.join(CONFIG_DIR, `onebot_${uin}.json`);
	const perUinConfig = tryLoadJson(perUinPath);
	if (perUinConfig) deepMerge(merged, perUinConfig);
	const config = fromJson(merged);
	let shouldSave = !perUinConfig;
	merged.httpServers = config.httpServers.map((s) => {
		const out = {
			host: s.host,
			port: s.port,
			path: s.path ?? "/",
			accessToken: s.accessToken ?? ""
		};
		if (s.name) out.name = s.name;
		return out;
	});
	merged.httpPostEndpoints = config.httpPostEndpoints.map((e) => {
		const out = { url: e.url };
		if (e.name) out.name = e.name;
		if (e.accessToken) out.accessToken = e.accessToken;
		if (typeof e.timeoutMs === "number") out.timeoutMs = e.timeoutMs;
		return out;
	});
	merged.wsServers = config.wsServers.map((s) => {
		const out = {
			host: s.host,
			port: s.port,
			path: s.path ?? "/",
			role: s.role ?? "universal",
			accessToken: s.accessToken ?? ""
		};
		if (s.name) out.name = s.name;
		return out;
	});
	merged.wsClients = config.wsClients.map((c) => {
		const out = {
			url: c.url,
			role: c.role ?? "universal",
			accessToken: c.accessToken ?? ""
		};
		if (c.name) out.name = c.name;
		if (typeof c.reconnectIntervalMs === "number" && Number.isFinite(c.reconnectIntervalMs)) out.reconnectIntervalMs = Math.max(1e3, Math.trunc(c.reconnectIntervalMs));
		return out;
	});
	merged.musicSignUrl = config.musicSignUrl ?? "";
	if (shouldSave) saveJson(perUinPath, merged);
	return config;
}
function saveOneBotConfig(uin, config) {
	ensureConfigDir();
	saveJson(path.join(CONFIG_DIR, `onebot_${uin}.json`), toJsonObject(config));
}
function ensureConfigDir() {
	fs.mkdirSync(CONFIG_DIR, { recursive: true });
}
function toJsonObject(config) {
	return {
		httpServers: config.httpServers.map((s) => {
			const out = {
				host: s.host,
				port: s.port,
				path: s.path ?? "/",
				accessToken: s.accessToken ?? ""
			};
			if (s.name) out.name = s.name;
			return out;
		}),
		httpPostEndpoints: config.httpPostEndpoints.map((e) => {
			const out = { url: e.url };
			if (e.name) out.name = e.name;
			if (e.accessToken) out.accessToken = e.accessToken;
			if (typeof e.timeoutMs === "number") out.timeoutMs = e.timeoutMs;
			return out;
		}),
		wsServers: config.wsServers.map((s) => {
			const out = {
				host: s.host,
				port: s.port,
				path: s.path ?? "/",
				role: s.role ?? "universal",
				accessToken: s.accessToken ?? ""
			};
			if (s.name) out.name = s.name;
			return out;
		}),
		wsClients: config.wsClients.map((c) => {
			const out = {
				url: c.url,
				role: c.role ?? "universal",
				accessToken: c.accessToken ?? ""
			};
			if (c.name) out.name = c.name;
			if (typeof c.reconnectIntervalMs === "number" && Number.isFinite(c.reconnectIntervalMs)) out.reconnectIntervalMs = Math.max(1e3, Math.trunc(c.reconnectIntervalMs));
			return out;
		}),
		musicSignUrl: config.musicSignUrl ?? ""
	};
}
function fromJson(json) {
	const httpServers = toHttpServers(json.httpServers);
	const httpPostEndpoints = toHttpPostEndpoints(json.httpPostEndpoints);
	const wsServers = toWsServers(json.wsServers);
	const wsClients = toWsClients(json.wsClients);
	return {
		httpServers: httpServers.length > 0 ? httpServers : [{
			host: "0.0.0.0",
			port: 3e3,
			path: "/"
		}],
		httpPostEndpoints,
		wsServers: wsServers.length > 0 ? wsServers : [{
			host: "0.0.0.0",
			port: 3001
		}],
		wsClients,
		musicSignUrl: typeof json.musicSignUrl === "string" ? json.musicSignUrl : ""
	};
}
function toHttpServers(value) {
	if (!Array.isArray(value)) return [];
	const result = [];
	for (const item of value) {
		if (!isObject(item)) continue;
		const endpoint = {
			host: asString(item.host, "0.0.0.0"),
			port: asNumber(item.port, 3e3),
			path: asString(item.path, "/")
		};
		const name = asString(item.name);
		if (name) endpoint.name = name;
		const token = asString(item.accessToken);
		if (token) endpoint.accessToken = token;
		result.push(endpoint);
	}
	return result;
}
function toHttpPostEndpoints(value) {
	if (!Array.isArray(value)) return [];
	const result = [];
	for (const item of value) {
		if (!isObject(item)) continue;
		const url = asString(item.url);
		if (!url) continue;
		const endpoint = { url };
		const name = asString(item.name);
		if (name) endpoint.name = name;
		const token = asString(item.accessToken);
		if (token) endpoint.accessToken = token;
		const timeout = asNumber(item.timeoutMs, 0);
		if (timeout > 0) endpoint.timeoutMs = timeout;
		result.push(endpoint);
	}
	return result;
}
function toWsServers(value) {
	if (!Array.isArray(value)) return [];
	const result = [];
	for (const item of value) {
		if (!isObject(item)) continue;
		const endpoint = {
			host: asString(item.host, "0.0.0.0"),
			port: asNumber(item.port, 3001),
			path: asString(item.path, "/"),
			role: asRole(item.role, "universal")
		};
		const name = asString(item.name);
		if (name) endpoint.name = name;
		const token = asString(item.accessToken);
		if (token) endpoint.accessToken = token;
		result.push(endpoint);
	}
	return result;
}
function toWsClients(value) {
	if (!Array.isArray(value)) return [];
	const result = [];
	for (const item of value) {
		if (!isObject(item)) continue;
		const url = asString(item.url);
		if (!url) continue;
		const endpoint = {
			url,
			role: asRole(item.role, "universal"),
			reconnectIntervalMs: asNumber(item.reconnectIntervalMs, 5e3)
		};
		const name = asString(item.name);
		if (name) endpoint.name = name;
		const token = asString(item.accessToken);
		if (token) endpoint.accessToken = token;
		result.push(endpoint);
	}
	return result;
}
function asRole(value, fallback) {
	const text = asString(value, fallback);
	return text === "api" || text === "event" || text === "universal" ? text : fallback;
}
function asString(value, fallback = "") {
	if (typeof value === "string") return value;
	if (typeof value === "number" || typeof value === "boolean") return String(value);
	return fallback;
}
function asNumber(value, fallback = 0) {
	if (typeof value === "number" && Number.isFinite(value)) return Math.max(0, Math.trunc(value));
	if (typeof value === "string" && value.trim()) {
		const n = Number(value);
		if (Number.isFinite(n)) return Math.max(0, Math.trunc(n));
	}
	return fallback;
}
function tryLoadJson(filePath) {
	if (!fs.existsSync(filePath)) return null;
	try {
		const raw = fs.readFileSync(filePath, "utf8");
		const parsed = JSON.parse(raw);
		return isObject(parsed) ? parsed : null;
	} catch {
		return null;
	}
}
function saveJson(filePath, json) {
	fs.mkdirSync(path.dirname(filePath), { recursive: true });
	fs.writeFileSync(filePath, JSON.stringify(json, null, 2), "utf8");
}
function deepClone(obj) {
	return JSON.parse(JSON.stringify(obj));
}
function deepMerge(base, override) {
	for (const [key, value] of Object.entries(override)) if (isObject(base[key]) && isObject(value)) deepMerge(base[key], value);
	else base[key] = value;
}
function isObject(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
export { saveOneBotConfig as n, loadOneBotConfig as t };
