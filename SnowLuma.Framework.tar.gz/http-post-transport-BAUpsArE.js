import { t as createLogger } from "./logger-eam4arGv.js";
//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
//#endregion
//#region src/onebot/http-post-transport.ts
var http_post_transport_exports = /* @__PURE__ */ __exportAll({
	HttpPostTransport: () => HttpPostTransport,
	executeQuickOperation: () => executeQuickOperation
});
var log = createLogger("OneBot.POST");
var DEFAULT_TIMEOUT_MS = 5e3;
var HttpPostTransport = class {
	context;
	endpoints = [];
	stopped = false;
	constructor(config, context) {
		this.endpoints = [...config.httpPostEndpoints];
		this.context = context;
	}
	start() {
		this.stopped = false;
		const count = this.endpoints.length;
		if (count > 0) log.info("configured %d HTTP POST endpoint(s)", count);
	}
	reloadConfig(config) {
		this.endpoints = [...config.httpPostEndpoints];
		log.info("reloaded %d HTTP POST endpoint(s)", this.endpoints.length);
	}
	stop() {
		this.stopped = true;
	}
	publishEvent(event) {
		const endpoints = this.endpoints;
		if (!endpoints || endpoints.length === 0) return;
		const payload = JSON.stringify(event);
		for (const endpoint of endpoints) this.postEvent(endpoint, payload, event);
	}
	async postEvent(endpoint, payload, event) {
		if (this.stopped) return;
		const headers = {
			"Content-Type": "application/json",
			"User-Agent": "OneBot",
			"X-Self-ID": this.context.uin
		};
		if (endpoint.accessToken) headers["X-Signature"] = await computeHmacSha1(endpoint.accessToken, payload);
		const timeoutMs = endpoint.timeoutMs ?? DEFAULT_TIMEOUT_MS;
		try {
			const response = await fetch(endpoint.url, {
				method: "POST",
				headers,
				body: payload,
				signal: AbortSignal.timeout(timeoutMs)
			});
			if (response.ok) {
				if ((response.headers.get("content-type") ?? "").includes("application/json")) {
					const body = await response.text();
					if (body.trim()) await this.handleQuickOperation(event, body);
				}
			} else log.warn("POST %s returned %d", endpoint.url, response.status);
		} catch (error) {
			if (!this.stopped) log.warn("POST %s failed: %s", endpoint.url, error instanceof Error ? error.message : String(error));
		}
	}
	async handleQuickOperation(event, responseBody) {
		try {
			const operation = JSON.parse(responseBody);
			if (!operation || typeof operation !== "object") return;
			await executeQuickOperation(event, operation, this.context.api);
		} catch (error) {
			log.warn("quick operation failed: %s", error instanceof Error ? error.message : String(error));
		}
	}
};
async function computeHmacSha1(secret, payload) {
	const { createHmac } = await import("crypto");
	return "sha1=" + createHmac("sha1", secret).update(payload).digest("hex");
}
/**
* Execute a quick operation based on the event type and the response body.
* This implements the .handle_quick_operation hidden API behavior.
* See: https://github.com/botuniverse/onebot-11/blob/master/api/hidden.md
*/
async function executeQuickOperation(event, operation, api) {
	const postType = event.post_type;
	if (postType === "message") {
		if (operation.reply !== void 0 && operation.reply !== null && operation.reply !== "") {
			const messageType = event.message_type;
			const autoEscape = !!operation.auto_escape;
			if (messageType === "group") {
				const params = {
					group_id: event.group_id,
					message: operation.reply,
					auto_escape: autoEscape
				};
				if (operation.at_sender !== false && event.user_id) {
					const atSegment = {
						type: "at",
						data: { qq: String(event.user_id) }
					};
					if (typeof operation.reply === "string") {
						params.message = [atSegment, {
							type: "text",
							data: { text: operation.reply }
						}];
						params.auto_escape = false;
					} else if (Array.isArray(operation.reply)) params.message = [atSegment, ...operation.reply];
				}
				await api.handle("send_group_msg", params);
			} else if (messageType === "private") await api.handle("send_private_msg", {
				user_id: event.user_id,
				message: operation.reply,
				auto_escape: autoEscape
			});
		}
		if (operation.delete) await api.handle("delete_msg", { message_id: event.message_id });
		if (operation.ban && event.message_type === "group") {
			const duration = typeof operation.ban_duration === "number" ? operation.ban_duration : 1800;
			await api.handle("set_group_ban", {
				group_id: event.group_id,
				user_id: event.user_id,
				duration
			});
		}
		if (operation.kick && event.message_type === "group") await api.handle("set_group_kick", {
			group_id: event.group_id,
			user_id: event.user_id,
			reject_add_request: !!operation.reject_add_request
		});
	}
	if (postType === "request") {
		if (operation.approve !== void 0) {
			const requestType = event.request_type;
			if (requestType === "friend") await api.handle("set_friend_add_request", {
				flag: event.flag,
				approve: operation.approve,
				remark: operation.remark ?? ""
			});
			else if (requestType === "group") await api.handle("set_group_add_request", {
				flag: event.flag,
				sub_type: event.sub_type,
				approve: operation.approve,
				reason: operation.reason ?? ""
			});
		}
	}
}
//#endregion
export { http_post_transport_exports as n, HttpPostTransport as t };
